﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormOOP2_L_
{
    public partial class Form1 : Form
    {
        bool isChange = false;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //MessageBox.Show("You have clicked!");
            Button btn = new Button();
            this.Controls.Add(btn);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.BackColor = Color.Azure;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            btnClick.Text = "Clicked";
            btnClick.BackColor = Color.Aqua;
            
        }

        private void btnClick_MouseEnter(object sender, EventArgs e)
        {
            btnClick.BackColor = Color.Gray;
        }

        private void btnClick_MouseLeave(object sender, EventArgs e)
        {
            btnClick.BackColor = Color.Orange;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            //if (txtName.Text.Equals(""))
            if (txtName.Text == "" && isChange == false)
            {
                txtName.Text = "Name";
                //isChange = true;
            }
            else
                isChange = false;

        }

        private void textBox1_Click(object sender, EventArgs e)
        {
            if (txtName.Text.Equals("Name"))
            {
                isChange = true;
                txtName.Text = "";
            }

        }
    }
}
