﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormOOP2_L_
{
    public partial class Department : Form
    {
        public Department()
        {
            InitializeComponent();
        }

        private void Department_Load(object sender, EventArgs e)
        {
            this.Initialize();
        }
        private void Initialize()
        {
            txtCredit.Text = txtID.Text = txtName.Text = txtSearch.Text = "";
            this.LoadDepartments();
        }
        private void LoadDepartments()
        {
            try
            {
                string query = "Select * from Department";
                if (string.IsNullOrEmpty(txtSearch.Text)==false)
                    query += " where Name like '%" + txtSearch.Text + "%'";
                DataTable dt = DataAccess.Data(query);
                dataGridView1.AutoGenerateColumns = false;
                dataGridView1.DataSource = dt;
                dataGridView1.Refresh();
                dataGridView1.ClearSelection();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            this.LoadDepartments();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            this.Initialize();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //MessageBox.Show(e.RowIndex.ToString());
            string id = dataGridView1.Rows[e.RowIndex].Cells["dgvID"].Value.ToString();
            this.LoadDepartment(id);
        }
        private void LoadDepartment(string id)
        {
            string query = "select * from Department where id=" + id;
            DataTable dt = DataAccess.Data(query);
            txtID.Text = dt.Rows[0]["ID"].ToString();
            txtName.Text = dt.Rows[0]["Name"].ToString();
            txtCredit.Text = dt.Rows[0]["Credit"].ToString();
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            this.Initialize();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string id = txtID.Text;
            if(id!="")
            {
                string query = "delete from Department where id=" + id;
                DataAccess.Execute(query);
                //MessageBox.Show(id);
                this.Initialize();
            }
            else
            {
                MessageBox.Show("Please select a row fisrt");
            }
              
        }
    }
}
