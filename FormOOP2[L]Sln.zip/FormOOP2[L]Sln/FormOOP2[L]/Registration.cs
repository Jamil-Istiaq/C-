﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FormOOP2_L_
{
    public partial class Registration : Form
    {
        SqlConnection conn = null;
        public Registration()
        {
            InitializeComponent();
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {
            if (txtCPassword.Text != txtPassword.Text)
            {
                lblError.Visible = true;
                //MessageBox.Show("Password and Confirm password does not match");
                return;
            }
            else
            {
                lblError.Visible = false;
            }
                
        }

        private void lblPassword_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if(txtPassword.Text!=null)
            {
                string uname = txtUName.Text;
                string password = txtPassword.Text;
                DateTime dob = Convert.ToDateTime(dateTimePicker1.Text);
                string gender = "";
                if (rbtnMale.Checked)
                    gender = "Male";
                else if (rbtnFemale.Checked)
                    gender = "Female";
                string type = "";
                if (rbtnFT.Checked)
                    type = "Full time";
                else if (rbtnPT.Checked)
                    type = "Part time";
                string skills = "";
                if (checkBoxCSharp.Checked)
                    skills = "C#";
                if (checkBoxPython.Checked)
                    skills += string.IsNullOrEmpty(skills)?"Python":",Python";
                if (checkBoxRuby.Checked)
                    skills += string.IsNullOrEmpty(skills) ? "Ruby" : ",Ruby";
                string dept = comboBox1.SelectedItem.ToString();
                string address = txtAddress.Text;
                
                try
                {
                    conn = new SqlConnection(@"Data Source=DESKTOP-NJBKCUM\SQLEXPRESS;Initial Catalog=OOP2LDB;Integrated Security=True");
                    conn.Open();
                    string query = "insert into UserInfo(UserName,[Password],DOB,Department) "
                        +"VALUES('" + uname + "','" + password + "','" + dob + "','" + dept + "')";
                    //string s = "Username is" + uname+".";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }
            else
            {
                return;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtAddress_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
       
            try
            {
                conn = new SqlConnection(@"Data Source=DESKTOP-NJBKCUM\SQLEXPRESS;Initial Catalog=OOP2LDB;Integrated Security=True");
                conn.Open();
                string query = "select * from UserInfo";
                //string s = "Username is" + uname+".";
                SqlCommand cmd = new SqlCommand(query, conn);
                DataSet ds = new DataSet();
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                adp.Fill(ds);
                DataTable dt = ds.Tables[0];
                dgvUserInfo.DataSource = dt;
                dgvUserInfo.Refresh();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }
    }
}
