﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace FormOOP2_L_
{
    public static class DataAccess
    {
        public static DataTable Data(string query)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-NJBKCUM\SQLEXPRESS;Initial Catalog=OOP2LDB;Integrated Security=True");
            conn.Open();
            //string query = "select * from Department";
            //string s = "Username is" + uname+".";
            SqlCommand cmd = new SqlCommand(query, conn);
            DataSet ds = new DataSet();
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            adp.Fill(ds);
            return ds.Tables[0];
         }
        public static void Execute(string query)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-NJBKCUM\SQLEXPRESS;Initial Catalog=OOP2LDB;Integrated Security=True");
            conn.Open();
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.ExecuteNonQuery();
        }
    }
}
