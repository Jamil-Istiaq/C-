﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FinalProject
{
    public partial class UpdateInfoEx : Form
    {
        SqlConnection conn = null;
        public UpdateInfoEx()
        {
            InitializeComponent();
        }
        private void Initialize()
        {
            enametextbox.Text = textBox1.Text = textBox2.Text = textBox3.Text = textBox4.Text = "";
        }
        private void Backbutton_Click(object sender, EventArgs e)
        {
            ExecutivePanel ex5 = new ExecutivePanel();
            ex5.Show();
            this.Hide();
        }

        private void Updatebutton_Click(object sender, EventArgs e)
        {
            if (enametextbox.Text != null)
            {
                string ename = enametextbox.Text;
                string phn = textBox1.Text;
                string email =textBox2.Text;
                string nw = textBox4.Text;
                


                try
                {
                    conn = new SqlConnection(@"Data Source=DESKTOP-Q6H0SBH;Initial Catalog=CMSdbd;Integrated Security=True");
                    conn.Open();

                    string query = "update  Add_executive set Mobile='"+phn+"',Email='"+email+"',pass='"+nw+"' where Name='"+ename+"'";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Update Data");
                    this.Initialize();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }
            else
            {
                return;
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            if (textBox3.Text != textBox4.Text)
            {
                changePass.Visible = true;
                return;
            }
            else
            {
                changePass.Visible = false;
            }
        }

        private void UpdateInfoEx_Load(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Data Source=DESKTOP-Q6H0SBH;Initial Catalog=CMSdbd;Integrated Security=True";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandText = "select * from Add_executive";
            DataTable dt = new DataTable();
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            adp.Fill(dt);
            UpdatedataGridView.DataSource = dt;
        }
    }
}
