﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FinalProject
{
    
    public partial class AddExecutive : Form
    {
        SqlConnection conn = null;
        public AddExecutive()
        {
            InitializeComponent();
        }
        private void Initialize()
        {
            textBox1.Text = textBox3.Text = textBox4.Text = textBox5.Text = "";
        }

        private void Backbutton_Click(object sender, EventArgs e)
        {
            AdminForm ad6 = new AdminForm();
            ad6.Show();
            this.Hide();
        }

        private void AddExecutive_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'cMSdbdDataSet4.Add_executive' table. You can move, or remove it, as needed.
            //this.add_executiveTableAdapter.Fill(this.cMSdbdDataSet4.Add_executive);


        }

        private void Submitbutton_Click_1(object sender, EventArgs e)
        {
            if (textBox1.Text != null)
            {
                string name = textBox1.Text;
                string dept = comboBox3.SelectedItem.ToString();
                DateTime cyr1 = Convert.ToDateTime(dateTimePicker1.Text);
                DateTime cyr2 = Convert.ToDateTime(dateTimePicker2.Text);
                string pos = comboBox2.SelectedItem.ToString();
                string mob = textBox3.Text;
                string email = textBox4.Text;
                string gender = "";
                if (MaleRadioButton.Checked)
                    gender = "Male";
                else if (FemaleRadioButton.Checked)
                    gender = "Female";
                string pass = passtextBox.Text;
                string url = textBox5.Text;
                


                try
                {
                    conn = new SqlConnection(@"Data Source=DESKTOP-Q6H0SBH;Initial Catalog=CMSdbd;Integrated Security=True");
                    conn.Open();
                    string query = "insert into Add_executive ([Name],[Dept],[Com_yr1],[Com_yr2],[Position],[Mobile],[Email],[Gender],[Fb_link],[pass]) values('"+name+"', '"+dept+"', '"+cyr1+"', '"+cyr2+"', '"+pos+"', '"+mob+"', '"+email+"', '"+gender+"', '"+url+"','"+pass+"')";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Data Added");
                    this.Initialize();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }
            else
            {
                return;
            }
        }

        
        private void button1_Click(object sender, EventArgs e)
        {
            AdminForm ad7 = new AdminForm();
            ad7.Show();
            this.Hide();
        }

        private void AddExecutive_Load_1(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Data Source=DESKTOP-Q6H0SBH;Initial Catalog=CMSdbd;Integrated Security=True";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandText = "select * from Add_executive";
            DataTable dt = new DataTable();
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            adp.Fill(dt);
            dataGridView1.DataSource = dt;
        }
    }
}
