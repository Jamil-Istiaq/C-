﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FinalProject
{
    public partial class AddAdvisor : Form
    {
        SqlConnection conn = null;
        int indexRow;

        public AddAdvisor()
        {
            InitializeComponent();
        }

        private void Initialize()
        {
            NametextBox.Text = PhonetextBox.Text = EmailtextBox.Text = DeptcomboBox.Text = PositioncomboBox.Text = "";
            this.LoadAdvisor();
        }
        
        private void LoadAdvisor()
        {
            try
            {
                string query = "Select * from Add_advisor";

                DataTable dt = DataAccess.Data(query);
                AddadvisordataGridView.AutoGenerateColumns = false;
                AddadvisordataGridView.DataSource = dt;
                AddadvisordataGridView.Refresh();
                AddadvisordataGridView.ClearSelection();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void AddAdvisor_Load(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Data Source=DESKTOP-Q6H0SBH;Initial Catalog=CMSdbd;Integrated Security=True";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandText = "select * from Add_advisor";
            DataTable dt = new DataTable();
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            adp.Fill(dt);
            AddadvisordataGridView.DataSource = dt;
            
        }
       
 
        private void Backbutton_Click(object sender, EventArgs e)
        {
            AdminForm ad7 = new AdminForm();
            ad7.Show();
            this.Hide();
        }

        

        private void Addbutton_Click(object sender, EventArgs e)
        {
            if (NametextBox.Text != null)
            {
                string name = NametextBox.Text;
                string dept = DeptcomboBox.SelectedItem.ToString();
                string pos = PositioncomboBox.SelectedItem.ToString();
                string mob = PhonetextBox.Text;
                string email = EmailtextBox.Text;

                try
                {
                    conn = new SqlConnection(@"Data Source=DESKTOP-Q6H0SBH;Initial Catalog=CMSdbd;Integrated Security=True");
                    conn.Open();
                    string query = "insert into Add_advisor ([Name],[Dept],[Position],[Phone],[Email]) values('" + name + "', '" + dept + "','" + pos + "', '" + mob + "', '" + email + "')";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Data Added");
                    this.Initialize();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }
            else
            {
                return;
            }
        }

       
        private void Updatebutton_Click(object sender, EventArgs e)
        {
            
            DataGridViewRow newRow = AddadvisordataGridView.Rows[indexRow];
            newRow.Cells[0].Value = NametextBox.Text;
            newRow.Cells[2].Value = DeptcomboBox.SelectedItem.ToString();
            newRow.Cells[3].Value = PositioncomboBox.SelectedItem.ToString();
            newRow.Cells[4].Value = PhonetextBox.Text;
            newRow.Cells[5].Value = EmailtextBox.Text;
            MessageBox.Show("Update Successfully");
            this.Initialize();


        }

        private void AddadvisordataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            
            indexRow = e.RowIndex;
            DataGridViewRow row = AddadvisordataGridView.Rows[indexRow];
            NametextBox.Text = row.Cells[0].Value.ToString();
            IdtextBox.Text= row.Cells[1].Value.ToString();
            DeptcomboBox.Text= row.Cells[2].Value.ToString();
            PositioncomboBox.Text= row.Cells[3].Value.ToString();
            PhonetextBox.Text= row.Cells[4].Value.ToString();
            EmailtextBox.Text= row.Cells[5].Value.ToString();
        }
    }
}
