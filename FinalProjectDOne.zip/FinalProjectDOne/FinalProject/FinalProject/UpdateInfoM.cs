﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FinalProject
{
    public partial class UpdateInfoM : Form
    {
        SqlConnection conn = null;
        public UpdateInfoM()
        {
            InitializeComponent();
        }
        private void Initialize()
        {
            NtextBox.Text=PhonetextBox.Text=EmailtextBox.Text=OldtextBox.Text=newtextBox.Text=InterstedcomboBox.Text= "";

        }

        private void Backbutton_Click(object sender, EventArgs e)
        {
            MemberFrom mf5 = new MemberFrom();
            mf5.Show();
            this.Hide();
        }

        
        private void Submitbutton_Click(object sender, EventArgs e)
        {
            if (NtextBox.Text != null)
            {
                string name = NtextBox.Text;
                string phn = PhonetextBox.Text;
                string mail = EmailtextBox.Text;
                string nw = newtextBox.Text;
                string field = InterstedcomboBox.SelectedItem.ToString();
                

                try
                {
                    conn = new SqlConnection(@"Data Source=DESKTOP-Q6H0SBH;Initial Catalog=CMSdbd;Integrated Security=True");
                    conn.Open();

                    string query = "update  Add_member set Phone='"+phn+"',Email='"+mail+"',TempPass='"+nw+"',IntFields='"+field+"' where Name='"+name+"'";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Added Data");
                    this.Initialize();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }
            else
            {
                return;
            }
        }

        private void OldtextBox_TextChanged(object sender, EventArgs e)
        {
             SqlConnection sqlcon = new SqlConnection(@"Data Source=DESKTOP-Q6H0SBH;Initial Catalog=CMSdbd;Integrated Security=True");

            string query = "select TempPass  from Add_member where TempPass like '" +OldtextBox.Text+ "'";
            SqlDataAdapter sda = new SqlDataAdapter(query, sqlcon);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            if (dt.Rows.Count == 1)
            {
                changePass.Visible = false;
            }
            else
            {
                changePass.Visible = true;
                return;
            }
        }
    }
}
