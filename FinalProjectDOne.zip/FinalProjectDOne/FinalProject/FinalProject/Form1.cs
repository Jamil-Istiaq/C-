﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int t1 = 37;
        private void LoginButtonHover(object sender, EventArgs e)
        {
            this.DropDownPanel.Size = new Size(this.DropDownPanel.Size.Width, t1);
            timer1.Start();
        }

        private void LogInMouseLEave(object sender, EventArgs e)
        {
            timer1.Stop();
            t1 = 37;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if(t1>148)
            { timer1.Stop(); }
            else
            {
                this.DropDownPanel.Size = new Size(this.DropDownPanel.Size.Width, t1);
                t1 += 5;
            }
        }

        private void adminControlPanel1_Load(object sender, EventArgs e)
        {

        }

        private void Adminbutton_Click(object sender, EventArgs e)
        {
            adminControlPanel1.Show();
            executiveControlPanel1.Hide();
            member1.Hide();

        }

        private void Executivebutton_Click(object sender, EventArgs e)
        {
            adminControlPanel1.Hide();
            executiveControlPanel1.Show();
            member1.Hide();
        }

        private void Memberbutton_Click(object sender, EventArgs e)
        {
            adminControlPanel1.Hide();
            executiveControlPanel1.Hide();
            member1.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            adminControlPanel1.Hide();
            executiveControlPanel1.Hide();
            member1.Hide();
        }

        private void HomeButton_Click(object sender, EventArgs e)
        {
            adminControlPanel1.Hide();
            executiveControlPanel1.Hide();
            member1.Hide();
        }
        private void hide()
        {
            this.Hide();
        }

        private void executiveControlPanel1_Load(object sender, EventArgs e)
        {

        }

        private void member1_Load(object sender, EventArgs e)
        {

        }

        private void exit_button_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure?", "Exit", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                Application.Exit();
            }
        }
    }
}
