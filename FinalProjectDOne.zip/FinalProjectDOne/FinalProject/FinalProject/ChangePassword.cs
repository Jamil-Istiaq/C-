﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FinalProject
{
    public partial class ChangePassword : Form
    {
        SqlConnection conn = null;
        public ChangePassword()
        {
            InitializeComponent();
        }

        private void Initialize()
        {
            changeUnametext.Text=OldtextBox.Text=NewtextBox.Text=ConfirmtextBox.Text = "";

        }
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Backbutton_Click(object sender, EventArgs e)
        {
            AdminForm ad4 = new AdminForm();
            ad4.Show();
            this.Hide();
        }

        private void Submitbutton_Click(object sender, EventArgs e)
        {
            if (OldtextBox.Text != null)
            {
                string uname = changeUnametext.Text;
                string conpass = ConfirmtextBox.Text;

                try
                {
                    conn = new SqlConnection(@"Data Source=DESKTOP-Q6H0SBH;Initial Catalog=CMSdbd;Integrated Security=True");
                    conn.Open();
                    string query = "update Add_admin set Temp_pass='"+conpass+"' where UserName='"+uname+"'";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Change Successfully");
                    this.Initialize();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }

            else
            {
                return;
            }
        }
    

        private void ConfirmtextBox_TextChanged(object sender, EventArgs e)
        {
            if (NewtextBox.Text != ConfirmtextBox.Text)
            {
                changePass.Visible = true;
                return;
            }
            else
            {
                changePass.Visible = false;
            }
        }
    }
}
