﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class AdminForm : Form
    {
        private bool iscollapsed;
        private bool iscollapsed2;
        private bool iscollapsed3;
        public AdminForm()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if(iscollapsed)
            {
                
                FilePanel.Height += 10;
                if (FilePanel.Size == FilePanel.MaximumSize)
                { timer1.Stop(); iscollapsed = false; }
            }
            else
            {
                FilePanel.Height -= 10;
                if (FilePanel.Size == FilePanel.MinimumSize)
                { timer1.Stop(); iscollapsed = true; }
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            if (iscollapsed2)
            {

                executiveDropdownPanel.Height += 10;
                if (executiveDropdownPanel.Size == executiveDropdownPanel.MaximumSize)
                { timer2.Stop(); iscollapsed2 = false; }
            }
            else
            {
                executiveDropdownPanel.Height -= 10;
                if (executiveDropdownPanel.Size == executiveDropdownPanel.MinimumSize)
                { timer2.Stop(); iscollapsed2 = true; }
            }
        }

        private void EPanelbutton_Click(object sender, EventArgs e)
        {
            timer2.Start();
        }

        private void Advisorsbutton_Click(object sender, EventArgs e)
        {
            timer3.Start();
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            if (iscollapsed3)
            {

               AdvisorDropDownpanel.Height += 10;
                if (AdvisorDropDownpanel.Size == AdvisorDropDownpanel.MaximumSize)
                { timer3.Stop(); iscollapsed3 = false; }
            }
            else
            {
                AdvisorDropDownpanel.Height -= 10;
                if (AdvisorDropDownpanel.Size == AdvisorDropDownpanel.MinimumSize)
                { timer3.Stop(); iscollapsed3 = true; }
            }
        }

        private void AddAdminbutton_Click(object sender, EventArgs e)
        {
            Addadmin addadmin = new Addadmin();
            addadmin.Show();
            this.Hide();
        }

        private void AddSocietybutton_Click(object sender, EventArgs e)
        {
            AddSociety addSociety = new AddSociety();
            addSociety.Show();
            this.Hide();

        }

        private void Changebutton_Click(object sender, EventArgs e)
        {
            ChangePassword c1 = new ChangePassword();
            c1.Show();
            this.Hide();
        }

        private void ExecutiveListButton_Click(object sender, EventArgs e)
        {
            ExecutiveList ed = new ExecutiveList();
            ed.Show();
            this.Hide();
        }

        private void AddExecutivebutton_Click(object sender, EventArgs e)
        {
            AddExecutive ex = new AddExecutive();
            ex.Show();
            this.Hide();
        }

        private void AddNewbutton_Click(object sender, EventArgs e)
        {
            AddAdvisor adv = new AddAdvisor();
            adv.Show();
            this.Hide();
        }

        private void AdvisorListbutton_Click(object sender, EventArgs e)
        {
            AdvisorList adl = new AdvisorList();
            adl.Show();
            this.Hide();
        }

        private void Eventbutton_Click(object sender, EventArgs e)
        {
            Events ev = new Events();
            ev.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MemberManagement mm = new MemberManagement();
            mm.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
            this.Hide();
        }

        private void AdminForm_Load(object sender, EventArgs e)
        {

        }
    }
}
