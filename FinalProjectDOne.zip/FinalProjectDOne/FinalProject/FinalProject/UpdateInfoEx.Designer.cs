﻿namespace FinalProject
{
    partial class UpdateInfoEx
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UpdateInfoEx));
            this.ConfirmLabel = new System.Windows.Forms.Label();
            this.NewPasswordLabel = new System.Windows.Forms.Label();
            this.EmailIabel = new System.Windows.Forms.Label();
            this.PhoneLabel = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.Updatebutton = new System.Windows.Forms.Button();
            this.UpdatedataGridView = new System.Windows.Forms.DataGridView();
            this.Backbutton = new System.Windows.Forms.Button();
            this.enametextbox = new System.Windows.Forms.TextBox();
            this.Enamelbl = new System.Windows.Forms.Label();
            this.changePass = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.UpdatedataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // ConfirmLabel
            // 
            this.ConfirmLabel.AutoSize = true;
            this.ConfirmLabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ConfirmLabel.ForeColor = System.Drawing.Color.White;
            this.ConfirmLabel.Location = new System.Drawing.Point(68, 289);
            this.ConfirmLabel.Name = "ConfirmLabel";
            this.ConfirmLabel.Size = new System.Drawing.Size(104, 15);
            this.ConfirmLabel.TabIndex = 9;
            this.ConfirmLabel.Text = "ConfirmPassword";
            // 
            // NewPasswordLabel
            // 
            this.NewPasswordLabel.AutoSize = true;
            this.NewPasswordLabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NewPasswordLabel.ForeColor = System.Drawing.Color.White;
            this.NewPasswordLabel.Location = new System.Drawing.Point(68, 252);
            this.NewPasswordLabel.Name = "NewPasswordLabel";
            this.NewPasswordLabel.Size = new System.Drawing.Size(88, 15);
            this.NewPasswordLabel.TabIndex = 8;
            this.NewPasswordLabel.Text = "New Password";
            // 
            // EmailIabel
            // 
            this.EmailIabel.AutoSize = true;
            this.EmailIabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmailIabel.ForeColor = System.Drawing.Color.White;
            this.EmailIabel.Location = new System.Drawing.Point(68, 199);
            this.EmailIabel.Name = "EmailIabel";
            this.EmailIabel.Size = new System.Drawing.Size(36, 15);
            this.EmailIabel.TabIndex = 6;
            this.EmailIabel.Text = "Email";
            // 
            // PhoneLabel
            // 
            this.PhoneLabel.AutoSize = true;
            this.PhoneLabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PhoneLabel.ForeColor = System.Drawing.Color.White;
            this.PhoneLabel.Location = new System.Drawing.Point(68, 153);
            this.PhoneLabel.Name = "PhoneLabel";
            this.PhoneLabel.Size = new System.Drawing.Size(61, 15);
            this.PhoneLabel.TabIndex = 5;
            this.PhoneLabel.Text = "Phone No";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(214, 153);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(167, 20);
            this.textBox1.TabIndex = 10;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(214, 200);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(167, 20);
            this.textBox2.TabIndex = 11;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(214, 253);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(167, 20);
            this.textBox3.TabIndex = 12;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(214, 290);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(167, 20);
            this.textBox4.TabIndex = 13;
            this.textBox4.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // Updatebutton
            // 
            this.Updatebutton.BackColor = System.Drawing.Color.DarkSlateGray;
            this.Updatebutton.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Updatebutton.ForeColor = System.Drawing.Color.White;
            this.Updatebutton.Location = new System.Drawing.Point(229, 362);
            this.Updatebutton.Name = "Updatebutton";
            this.Updatebutton.Size = new System.Drawing.Size(106, 30);
            this.Updatebutton.TabIndex = 25;
            this.Updatebutton.Text = "Update";
            this.Updatebutton.UseVisualStyleBackColor = false;
            this.Updatebutton.Click += new System.EventHandler(this.Updatebutton_Click);
            // 
            // UpdatedataGridView
            // 
            this.UpdatedataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.UpdatedataGridView.Location = new System.Drawing.Point(442, 69);
            this.UpdatedataGridView.Name = "UpdatedataGridView";
            this.UpdatedataGridView.Size = new System.Drawing.Size(296, 303);
            this.UpdatedataGridView.TabIndex = 26;
            // 
            // Backbutton
            // 
            this.Backbutton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Backbutton.BackgroundImage")));
            this.Backbutton.Location = new System.Drawing.Point(738, 6);
            this.Backbutton.Name = "Backbutton";
            this.Backbutton.Size = new System.Drawing.Size(50, 50);
            this.Backbutton.TabIndex = 27;
            this.Backbutton.UseVisualStyleBackColor = true;
            this.Backbutton.Click += new System.EventHandler(this.Backbutton_Click);
            // 
            // enametextbox
            // 
            this.enametextbox.Location = new System.Drawing.Point(214, 110);
            this.enametextbox.Name = "enametextbox";
            this.enametextbox.Size = new System.Drawing.Size(167, 20);
            this.enametextbox.TabIndex = 29;
            // 
            // Enamelbl
            // 
            this.Enamelbl.AutoSize = true;
            this.Enamelbl.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Enamelbl.ForeColor = System.Drawing.Color.White;
            this.Enamelbl.Location = new System.Drawing.Point(68, 110);
            this.Enamelbl.Name = "Enamelbl";
            this.Enamelbl.Size = new System.Drawing.Size(98, 15);
            this.Enamelbl.TabIndex = 28;
            this.Enamelbl.Text = "Executive Name";
            // 
            // changePass
            // 
            this.changePass.AutoSize = true;
            this.changePass.ForeColor = System.Drawing.Color.LightCoral;
            this.changePass.Location = new System.Drawing.Point(226, 313);
            this.changePass.Name = "changePass";
            this.changePass.Size = new System.Drawing.Size(132, 13);
            this.changePass.TabIndex = 30;
            this.changePass.Text = "Password dose not match ";
            // 
            // UpdateInfoEx
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.changePass);
            this.Controls.Add(this.enametextbox);
            this.Controls.Add(this.Enamelbl);
            this.Controls.Add(this.Backbutton);
            this.Controls.Add(this.UpdatedataGridView);
            this.Controls.Add(this.Updatebutton);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.ConfirmLabel);
            this.Controls.Add(this.NewPasswordLabel);
            this.Controls.Add(this.EmailIabel);
            this.Controls.Add(this.PhoneLabel);
            this.Name = "UpdateInfoEx";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "UpdateInfoEx";
            this.Load += new System.EventHandler(this.UpdateInfoEx_Load);
            ((System.ComponentModel.ISupportInitialize)(this.UpdatedataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label ConfirmLabel;
        private System.Windows.Forms.Label NewPasswordLabel;
        private System.Windows.Forms.Label EmailIabel;
        private System.Windows.Forms.Label PhoneLabel;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Button Updatebutton;
        private System.Windows.Forms.DataGridView UpdatedataGridView;
        private System.Windows.Forms.Button Backbutton;
        private System.Windows.Forms.TextBox enametextbox;
        private System.Windows.Forms.Label Enamelbl;
        private System.Windows.Forms.Label changePass;
    }
}