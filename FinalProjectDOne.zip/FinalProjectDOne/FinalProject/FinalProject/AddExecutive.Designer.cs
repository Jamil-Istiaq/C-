﻿namespace FinalProject
{
    partial class AddExecutive
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddExecutive));
            this.panel1 = new System.Windows.Forms.Panel();
            this.passtextBox = new System.Windows.Forms.TextBox();
            this.passlebel = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.Submitbutton = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.tolabel = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.FemaleRadioButton = new System.Windows.Forms.RadioButton();
            this.MaleRadioButton = new System.Windows.Forms.RadioButton();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.Genderlabel = new System.Windows.Forms.Label();
            this.EmailLabel = new System.Windows.Forms.Label();
            this.FacebookLabel = new System.Windows.Forms.Label();
            this.Mobilelabel = new System.Windows.Forms.Label();
            this.PositionLabel = new System.Windows.Forms.Label();
            this.CommitteeYearLabel = new System.Windows.Forms.Label();
            this.Departmentlabel = new System.Windows.Forms.Label();
            this.Idlabel = new System.Windows.Forms.Label();
            this.NameLabel = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel1.Controls.Add(this.passtextBox);
            this.panel1.Controls.Add(this.passlebel);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.Submitbutton);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.dateTimePicker2);
            this.panel1.Controls.Add(this.tolabel);
            this.panel1.Controls.Add(this.dateTimePicker1);
            this.panel1.Controls.Add(this.comboBox3);
            this.panel1.Controls.Add(this.comboBox2);
            this.panel1.Controls.Add(this.FemaleRadioButton);
            this.panel1.Controls.Add(this.MaleRadioButton);
            this.panel1.Controls.Add(this.textBox5);
            this.panel1.Controls.Add(this.textBox4);
            this.panel1.Controls.Add(this.textBox3);
            this.panel1.Controls.Add(this.textBox2);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.Genderlabel);
            this.panel1.Controls.Add(this.EmailLabel);
            this.panel1.Controls.Add(this.FacebookLabel);
            this.panel1.Controls.Add(this.Mobilelabel);
            this.panel1.Controls.Add(this.PositionLabel);
            this.panel1.Controls.Add(this.CommitteeYearLabel);
            this.panel1.Controls.Add(this.Departmentlabel);
            this.panel1.Controls.Add(this.Idlabel);
            this.panel1.Controls.Add(this.NameLabel);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(970, 490);
            this.panel1.TabIndex = 0;
            // 
            // passtextBox
            // 
            this.passtextBox.Location = new System.Drawing.Point(209, 414);
            this.passtextBox.Name = "passtextBox";
            this.passtextBox.Size = new System.Drawing.Size(197, 20);
            this.passtextBox.TabIndex = 28;
            // 
            // passlebel
            // 
            this.passlebel.AutoSize = true;
            this.passlebel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passlebel.ForeColor = System.Drawing.Color.White;
            this.passlebel.Location = new System.Drawing.Point(24, 419);
            this.passlebel.Name = "passlebel";
            this.passlebel.Size = new System.Drawing.Size(67, 15);
            this.passlebel.TabIndex = 27;
            this.passlebel.Text = "Temp. Pass";
            // 
            // button1
            // 
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(807, 6);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(50, 40);
            this.button1.TabIndex = 26;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Submitbutton
            // 
            this.Submitbutton.BackColor = System.Drawing.Color.DarkSlateGray;
            this.Submitbutton.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Submitbutton.ForeColor = System.Drawing.Color.White;
            this.Submitbutton.Location = new System.Drawing.Point(258, 448);
            this.Submitbutton.Name = "Submitbutton";
            this.Submitbutton.Size = new System.Drawing.Size(106, 30);
            this.Submitbutton.TabIndex = 24;
            this.Submitbutton.Text = "Submit";
            this.Submitbutton.UseVisualStyleBackColor = false;
            this.Submitbutton.Click += new System.EventHandler(this.Submitbutton_Click_1);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(466, 52);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(441, 404);
            this.dataGridView1.TabIndex = 23;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(337, 179);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(72, 20);
            this.dateTimePicker2.TabIndex = 22;
            // 
            // tolabel
            // 
            this.tolabel.AutoSize = true;
            this.tolabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tolabel.ForeColor = System.Drawing.Color.White;
            this.tolabel.Location = new System.Drawing.Point(308, 184);
            this.tolabel.Name = "tolabel";
            this.tolabel.Size = new System.Drawing.Size(19, 15);
            this.tolabel.TabIndex = 21;
            this.tolabel.Text = "to";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(211, 179);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(72, 20);
            this.dateTimePicker1.TabIndex = 20;
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "CSE",
            "EEE",
            "COE",
            "CSSE",
            "SE"});
            this.comboBox3.Location = new System.Drawing.Point(210, 134);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(197, 21);
            this.comboBox3.TabIndex = 19;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "President",
            "Vice President",
            "Public Relationship",
            "Research and Develeopment",
            "Treasurer",
            "Event Manager",
            "Photographer"});
            this.comboBox2.Location = new System.Drawing.Point(211, 221);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(197, 21);
            this.comboBox2.TabIndex = 18;
            // 
            // FemaleRadioButton
            // 
            this.FemaleRadioButton.AutoSize = true;
            this.FemaleRadioButton.Location = new System.Drawing.Point(337, 345);
            this.FemaleRadioButton.Name = "FemaleRadioButton";
            this.FemaleRadioButton.Size = new System.Drawing.Size(59, 17);
            this.FemaleRadioButton.TabIndex = 16;
            this.FemaleRadioButton.TabStop = true;
            this.FemaleRadioButton.Text = "Female";
            this.FemaleRadioButton.UseVisualStyleBackColor = true;
            // 
            // MaleRadioButton
            // 
            this.MaleRadioButton.AutoSize = true;
            this.MaleRadioButton.Location = new System.Drawing.Point(213, 345);
            this.MaleRadioButton.Name = "MaleRadioButton";
            this.MaleRadioButton.Size = new System.Drawing.Size(48, 17);
            this.MaleRadioButton.TabIndex = 15;
            this.MaleRadioButton.TabStop = true;
            this.MaleRadioButton.Text = "Male";
            this.MaleRadioButton.UseVisualStyleBackColor = true;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(209, 380);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(197, 20);
            this.textBox5.TabIndex = 14;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(210, 308);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(197, 20);
            this.textBox4.TabIndex = 13;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(210, 262);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(197, 20);
            this.textBox3.TabIndex = 12;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(210, 93);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(197, 20);
            this.textBox2.TabIndex = 11;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(209, 52);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(197, 20);
            this.textBox1.TabIndex = 10;
            // 
            // Genderlabel
            // 
            this.Genderlabel.AutoSize = true;
            this.Genderlabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Genderlabel.ForeColor = System.Drawing.Color.White;
            this.Genderlabel.Location = new System.Drawing.Point(24, 346);
            this.Genderlabel.Name = "Genderlabel";
            this.Genderlabel.Size = new System.Drawing.Size(49, 15);
            this.Genderlabel.TabIndex = 9;
            this.Genderlabel.Text = "Gender";
            // 
            // EmailLabel
            // 
            this.EmailLabel.AutoSize = true;
            this.EmailLabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmailLabel.ForeColor = System.Drawing.Color.White;
            this.EmailLabel.Location = new System.Drawing.Point(24, 308);
            this.EmailLabel.Name = "EmailLabel";
            this.EmailLabel.Size = new System.Drawing.Size(36, 15);
            this.EmailLabel.TabIndex = 8;
            this.EmailLabel.Text = "Email";
            // 
            // FacebookLabel
            // 
            this.FacebookLabel.AutoSize = true;
            this.FacebookLabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FacebookLabel.ForeColor = System.Drawing.Color.White;
            this.FacebookLabel.Location = new System.Drawing.Point(24, 385);
            this.FacebookLabel.Name = "FacebookLabel";
            this.FacebookLabel.Size = new System.Drawing.Size(86, 15);
            this.FacebookLabel.TabIndex = 7;
            this.FacebookLabel.Text = "Facebook URL";
            // 
            // Mobilelabel
            // 
            this.Mobilelabel.AutoSize = true;
            this.Mobilelabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Mobilelabel.ForeColor = System.Drawing.Color.White;
            this.Mobilelabel.Location = new System.Drawing.Point(24, 262);
            this.Mobilelabel.Name = "Mobilelabel";
            this.Mobilelabel.Size = new System.Drawing.Size(64, 15);
            this.Mobilelabel.TabIndex = 6;
            this.Mobilelabel.Text = "Mobile No";
            // 
            // PositionLabel
            // 
            this.PositionLabel.AutoSize = true;
            this.PositionLabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PositionLabel.ForeColor = System.Drawing.Color.White;
            this.PositionLabel.Location = new System.Drawing.Point(24, 221);
            this.PositionLabel.Name = "PositionLabel";
            this.PositionLabel.Size = new System.Drawing.Size(51, 15);
            this.PositionLabel.TabIndex = 4;
            this.PositionLabel.Text = "Position";
            // 
            // CommitteeYearLabel
            // 
            this.CommitteeYearLabel.AutoSize = true;
            this.CommitteeYearLabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CommitteeYearLabel.ForeColor = System.Drawing.Color.White;
            this.CommitteeYearLabel.Location = new System.Drawing.Point(24, 184);
            this.CommitteeYearLabel.Name = "CommitteeYearLabel";
            this.CommitteeYearLabel.Size = new System.Drawing.Size(97, 15);
            this.CommitteeYearLabel.TabIndex = 3;
            this.CommitteeYearLabel.Text = "Committee Year";
            // 
            // Departmentlabel
            // 
            this.Departmentlabel.AutoSize = true;
            this.Departmentlabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Departmentlabel.ForeColor = System.Drawing.Color.White;
            this.Departmentlabel.Location = new System.Drawing.Point(24, 139);
            this.Departmentlabel.Name = "Departmentlabel";
            this.Departmentlabel.Size = new System.Drawing.Size(76, 15);
            this.Departmentlabel.TabIndex = 2;
            this.Departmentlabel.Text = "Department";
            // 
            // Idlabel
            // 
            this.Idlabel.AutoSize = true;
            this.Idlabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Idlabel.ForeColor = System.Drawing.Color.White;
            this.Idlabel.Location = new System.Drawing.Point(24, 98);
            this.Idlabel.Name = "Idlabel";
            this.Idlabel.Size = new System.Drawing.Size(18, 15);
            this.Idlabel.TabIndex = 1;
            this.Idlabel.Text = "Id";
            // 
            // NameLabel
            // 
            this.NameLabel.AutoSize = true;
            this.NameLabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NameLabel.ForeColor = System.Drawing.Color.White;
            this.NameLabel.Location = new System.Drawing.Point(24, 52);
            this.NameLabel.Name = "NameLabel";
            this.NameLabel.Size = new System.Drawing.Size(40, 15);
            this.NameLabel.TabIndex = 0;
            this.NameLabel.Text = "Name";
            // 
            // AddExecutive
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(970, 490);
            this.Controls.Add(this.panel1);
            this.Name = "AddExecutive";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AddExecutive";
            this.Load += new System.EventHandler(this.AddExecutive_Load_1);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label Genderlabel;
        private System.Windows.Forms.Label EmailLabel;
        private System.Windows.Forms.Label FacebookLabel;
        private System.Windows.Forms.Label Mobilelabel;
        private System.Windows.Forms.Label PositionLabel;
        private System.Windows.Forms.Label CommitteeYearLabel;
        private System.Windows.Forms.Label Departmentlabel;
        private System.Windows.Forms.Label Idlabel;
        private System.Windows.Forms.Label NameLabel;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Label tolabel;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.RadioButton FemaleRadioButton;
        private System.Windows.Forms.RadioButton MaleRadioButton;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button Submitbutton;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label passlebel;
        private System.Windows.Forms.TextBox passtextBox;
    }
}