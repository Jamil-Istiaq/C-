﻿namespace FinalProject
{
    partial class UpdateInfoM
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UpdateInfoM));
            this.panel1 = new System.Windows.Forms.Panel();
            this.NtextBox = new System.Windows.Forms.TextBox();
            this.nlabel = new System.Windows.Forms.Label();
            this.Backbutton = new System.Windows.Forms.Button();
            this.Submitbutton = new System.Windows.Forms.Button();
            this.InterstedcomboBox = new System.Windows.Forms.ComboBox();
            this.newtextBox = new System.Windows.Forms.TextBox();
            this.OldtextBox = new System.Windows.Forms.TextBox();
            this.EmailtextBox = new System.Windows.Forms.TextBox();
            this.PhonetextBox = new System.Windows.Forms.TextBox();
            this.Interstedlabel = new System.Windows.Forms.Label();
            this.Newlabel = new System.Windows.Forms.Label();
            this.OldLabel = new System.Windows.Forms.Label();
            this.Emaillabel = new System.Windows.Forms.Label();
            this.PhoneLabel = new System.Windows.Forms.Label();
            this.changePass = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.Controls.Add(this.changePass);
            this.panel1.Controls.Add(this.NtextBox);
            this.panel1.Controls.Add(this.nlabel);
            this.panel1.Controls.Add(this.Backbutton);
            this.panel1.Controls.Add(this.Submitbutton);
            this.panel1.Controls.Add(this.InterstedcomboBox);
            this.panel1.Controls.Add(this.newtextBox);
            this.panel1.Controls.Add(this.OldtextBox);
            this.panel1.Controls.Add(this.EmailtextBox);
            this.panel1.Controls.Add(this.PhonetextBox);
            this.panel1.Controls.Add(this.Interstedlabel);
            this.panel1.Controls.Add(this.Newlabel);
            this.panel1.Controls.Add(this.OldLabel);
            this.panel1.Controls.Add(this.Emaillabel);
            this.panel1.Controls.Add(this.PhoneLabel);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(857, 491);
            this.panel1.TabIndex = 0;
            // 
            // NtextBox
            // 
            this.NtextBox.Location = new System.Drawing.Point(371, 98);
            this.NtextBox.Name = "NtextBox";
            this.NtextBox.Size = new System.Drawing.Size(196, 20);
            this.NtextBox.TabIndex = 46;
            // 
            // nlabel
            // 
            this.nlabel.AutoSize = true;
            this.nlabel.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.nlabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.nlabel.ForeColor = System.Drawing.Color.Transparent;
            this.nlabel.Location = new System.Drawing.Point(181, 98);
            this.nlabel.Name = "nlabel";
            this.nlabel.Size = new System.Drawing.Size(44, 17);
            this.nlabel.TabIndex = 45;
            this.nlabel.Text = "Name";
            // 
            // Backbutton
            // 
            this.Backbutton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Backbutton.BackgroundImage")));
            this.Backbutton.Location = new System.Drawing.Point(775, 12);
            this.Backbutton.Name = "Backbutton";
            this.Backbutton.Size = new System.Drawing.Size(50, 50);
            this.Backbutton.TabIndex = 44;
            this.Backbutton.UseVisualStyleBackColor = true;
            this.Backbutton.Click += new System.EventHandler(this.Backbutton_Click);
            // 
            // Submitbutton
            // 
            this.Submitbutton.BackColor = System.Drawing.Color.DarkSlateGray;
            this.Submitbutton.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Submitbutton.ForeColor = System.Drawing.Color.White;
            this.Submitbutton.Location = new System.Drawing.Point(388, 423);
            this.Submitbutton.Name = "Submitbutton";
            this.Submitbutton.Size = new System.Drawing.Size(155, 41);
            this.Submitbutton.TabIndex = 43;
            this.Submitbutton.Text = "Update";
            this.Submitbutton.UseVisualStyleBackColor = false;
            this.Submitbutton.Click += new System.EventHandler(this.Submitbutton_Click);
            // 
            // InterstedcomboBox
            // 
            this.InterstedcomboBox.FormattingEnabled = true;
            this.InterstedcomboBox.Items.AddRange(new object[] {
            "Graphics Design",
            "Web Development",
            "Event Management",
            "Research and methodology",
            "Media",
            "Photography"});
            this.InterstedcomboBox.Location = new System.Drawing.Point(371, 357);
            this.InterstedcomboBox.Name = "InterstedcomboBox";
            this.InterstedcomboBox.Size = new System.Drawing.Size(196, 21);
            this.InterstedcomboBox.TabIndex = 42;
            // 
            // newtextBox
            // 
            this.newtextBox.Location = new System.Drawing.Point(371, 316);
            this.newtextBox.Name = "newtextBox";
            this.newtextBox.Size = new System.Drawing.Size(196, 20);
            this.newtextBox.TabIndex = 41;
            // 
            // OldtextBox
            // 
            this.OldtextBox.Location = new System.Drawing.Point(371, 256);
            this.OldtextBox.Name = "OldtextBox";
            this.OldtextBox.Size = new System.Drawing.Size(196, 20);
            this.OldtextBox.TabIndex = 40;
            this.OldtextBox.TextChanged += new System.EventHandler(this.OldtextBox_TextChanged);
            // 
            // EmailtextBox
            // 
            this.EmailtextBox.Location = new System.Drawing.Point(371, 207);
            this.EmailtextBox.Name = "EmailtextBox";
            this.EmailtextBox.Size = new System.Drawing.Size(196, 20);
            this.EmailtextBox.TabIndex = 39;
            // 
            // PhonetextBox
            // 
            this.PhonetextBox.Location = new System.Drawing.Point(371, 155);
            this.PhonetextBox.Name = "PhonetextBox";
            this.PhonetextBox.Size = new System.Drawing.Size(196, 20);
            this.PhonetextBox.TabIndex = 38;
            // 
            // Interstedlabel
            // 
            this.Interstedlabel.AutoSize = true;
            this.Interstedlabel.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Interstedlabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.Interstedlabel.ForeColor = System.Drawing.Color.Transparent;
            this.Interstedlabel.Location = new System.Drawing.Point(181, 357);
            this.Interstedlabel.Name = "Interstedlabel";
            this.Interstedlabel.Size = new System.Drawing.Size(97, 17);
            this.Interstedlabel.TabIndex = 37;
            this.Interstedlabel.Text = "Intersted Field";
            // 
            // Newlabel
            // 
            this.Newlabel.AutoSize = true;
            this.Newlabel.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Newlabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.Newlabel.ForeColor = System.Drawing.Color.Transparent;
            this.Newlabel.Location = new System.Drawing.Point(181, 319);
            this.Newlabel.Name = "Newlabel";
            this.Newlabel.Size = new System.Drawing.Size(97, 17);
            this.Newlabel.TabIndex = 36;
            this.Newlabel.Text = "New Password";
            // 
            // OldLabel
            // 
            this.OldLabel.AutoSize = true;
            this.OldLabel.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.OldLabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.OldLabel.ForeColor = System.Drawing.Color.Transparent;
            this.OldLabel.Location = new System.Drawing.Point(181, 256);
            this.OldLabel.Name = "OldLabel";
            this.OldLabel.Size = new System.Drawing.Size(92, 17);
            this.OldLabel.TabIndex = 35;
            this.OldLabel.Text = "Old Password";
            // 
            // Emaillabel
            // 
            this.Emaillabel.AutoSize = true;
            this.Emaillabel.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Emaillabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.Emaillabel.ForeColor = System.Drawing.Color.Transparent;
            this.Emaillabel.Location = new System.Drawing.Point(181, 210);
            this.Emaillabel.Name = "Emaillabel";
            this.Emaillabel.Size = new System.Drawing.Size(42, 17);
            this.Emaillabel.TabIndex = 34;
            this.Emaillabel.Text = "Email";
            // 
            // PhoneLabel
            // 
            this.PhoneLabel.AutoSize = true;
            this.PhoneLabel.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.PhoneLabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.PhoneLabel.ForeColor = System.Drawing.Color.Transparent;
            this.PhoneLabel.Location = new System.Drawing.Point(181, 158);
            this.PhoneLabel.Name = "PhoneLabel";
            this.PhoneLabel.Size = new System.Drawing.Size(69, 17);
            this.PhoneLabel.TabIndex = 33;
            this.PhoneLabel.Text = "Phone No";
            // 
            // changePass
            // 
            this.changePass.AutoSize = true;
            this.changePass.ForeColor = System.Drawing.Color.LightCoral;
            this.changePass.Location = new System.Drawing.Point(399, 289);
            this.changePass.Name = "changePass";
            this.changePass.Size = new System.Drawing.Size(132, 13);
            this.changePass.TabIndex = 47;
            this.changePass.Text = "Password dose not match ";
            // 
            // UpdateInfoM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(857, 491);
            this.Controls.Add(this.panel1);
            this.Name = "UpdateInfoM";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "UpdateInfoM";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button Submitbutton;
        private System.Windows.Forms.ComboBox InterstedcomboBox;
        private System.Windows.Forms.TextBox newtextBox;
        private System.Windows.Forms.TextBox OldtextBox;
        private System.Windows.Forms.TextBox EmailtextBox;
        private System.Windows.Forms.TextBox PhonetextBox;
        private System.Windows.Forms.Label Interstedlabel;
        private System.Windows.Forms.Label Newlabel;
        private System.Windows.Forms.Label OldLabel;
        private System.Windows.Forms.Label Emaillabel;
        private System.Windows.Forms.Label PhoneLabel;
        private System.Windows.Forms.Button Backbutton;
        private System.Windows.Forms.TextBox NtextBox;
        private System.Windows.Forms.Label nlabel;
        private System.Windows.Forms.Label changePass;
    }
}