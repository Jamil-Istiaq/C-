﻿namespace FinalProject
{
    partial class AdvisorListE
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdvisorListE));
            this.panel1 = new System.Windows.Forms.Panel();
            this.Backbutton = new System.Windows.Forms.Button();
            this.AdvisordataGridView = new System.Windows.Forms.DataGridView();
            this.AdvisorsListLabel = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AdvisordataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel1.Controls.Add(this.Backbutton);
            this.panel1.Controls.Add(this.AdvisordataGridView);
            this.panel1.Controls.Add(this.AdvisorsListLabel);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 450);
            this.panel1.TabIndex = 0;
            // 
            // Backbutton
            // 
            this.Backbutton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Backbutton.BackgroundImage")));
            this.Backbutton.Location = new System.Drawing.Point(719, 19);
            this.Backbutton.Name = "Backbutton";
            this.Backbutton.Size = new System.Drawing.Size(50, 50);
            this.Backbutton.TabIndex = 28;
            this.Backbutton.UseVisualStyleBackColor = true;
            this.Backbutton.Click += new System.EventHandler(this.Backbutton_Click);
            // 
            // AdvisordataGridView
            // 
            this.AdvisordataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.AdvisordataGridView.Location = new System.Drawing.Point(73, 86);
            this.AdvisordataGridView.Name = "AdvisordataGridView";
            this.AdvisordataGridView.Size = new System.Drawing.Size(582, 294);
            this.AdvisordataGridView.TabIndex = 3;
            // 
            // AdvisorsListLabel
            // 
            this.AdvisorsListLabel.AutoSize = true;
            this.AdvisorsListLabel.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AdvisorsListLabel.ForeColor = System.Drawing.Color.White;
            this.AdvisorsListLabel.Location = new System.Drawing.Point(60, 33);
            this.AdvisorsListLabel.Name = "AdvisorsListLabel";
            this.AdvisorsListLabel.Size = new System.Drawing.Size(99, 20);
            this.AdvisorsListLabel.TabIndex = 2;
            this.AdvisorsListLabel.Text = "Advisors List";
            // 
            // AdvisorListE
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel1);
            this.Name = "AdvisorListE";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AdvisorListE";
            this.Load += new System.EventHandler(this.AdvisorListE_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AdvisordataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView AdvisordataGridView;
        private System.Windows.Forms.Label AdvisorsListLabel;
        private System.Windows.Forms.Button Backbutton;
    }
}