﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FinalProject
{
    public partial class Events : Form
    {
        SqlConnection conn = null;
        int indexRow;
        public Events()
        {
            InitializeComponent();
        }
        private void Initialize()
        {
            textBox1.Text = textBox2.Text = textBox3.Text=comboBox2.Text=comboBox1.Text = "";
         //   this.LoadEvent();
        }
        private void LoadEvent()
        {
            try
            {
                string query = "Select * from Add_event";

                DataTable dt = DataAccess.Data(query);
                dataGridView1.AutoGenerateColumns = false;
                dataGridView1.DataSource = dt;
                dataGridView1.Refresh();
                dataGridView1.ClearSelection();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Backbutton_Click(object sender, EventArgs e)
        {
            AdminForm ad9 = new AdminForm();
            ad9.Show();
            this.Hide();
        }

        private void Savebutton_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != null)
            {
                string name = textBox1.Text;
                string ctg = comboBox2.SelectedItem.ToString();
                DateTime ev1 = Convert.ToDateTime(dateTimePicker1.Text);
                DateTime ev2 = Convert.ToDateTime(dateTimePicker2.Text);
                string vanue = comboBox1.SelectedItem.ToString();
                string spname = textBox2.Text;
                string bgt = textBox3.Text;
                

                try
                {
                    conn = new SqlConnection(@"Data Source=DESKTOP-Q6H0SBH;Initial Catalog=CMSdbd;Integrated Security=True");
                    conn.Open();
                    string query = "insert into Add_event ([EventName],[Category],[EvntDate1],[EvntDate2],[Vanue],[SpeakerName],[Budget]) " +
                        "values('" +name + "', '" +ctg+ "', '" + ev1+ "', '" + ev2 + "', '" +vanue+ "', '" +spname+ "', '" +bgt+ "')";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Event Added");
                    this.Initialize();
                    this.LoadEvent();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }
            else
            {
                return;
            }
        }

        private void Events_Load_1(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Data Source=DESKTOP-Q6H0SBH;Initial Catalog=CMSdbd;Integrated Security=True";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandText = "select * from Add_event";
            DataTable dt = new DataTable();
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            adp.Fill(dt);
            dataGridView1.DataSource = dt;

        }

        private void Newbutton_Click(object sender, EventArgs e)
        {
            this.Initialize();
            this.LoadEvent();
        }

        private void Editbutton_Click(object sender, EventArgs e)
        {
            DataGridViewRow newRow = dataGridView1.Rows[indexRow];
            newRow.Cells[0].Value = textBox1.Text.ToString();
            newRow.Cells[1].Value = comboBox2.SelectedItem.ToString();
            newRow.Cells[2].Value = Convert.ToDateTime(dateTimePicker1.Text);
            newRow.Cells[3].Value = Convert.ToDateTime(dateTimePicker2.Text);
            newRow.Cells[4].Value = comboBox1.SelectedItem.ToString();
            newRow.Cells[5].Value = textBox2.Text.ToString();
            newRow.Cells[6].Value = textBox3.Text.ToString();

            MessageBox.Show("Update Successfully");
            this.Initialize();
            this.LoadEvent();
        }

        private void Searchbutton_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != null)
            {
                string name = textBox1.Text;
                try
                {
                    conn = new SqlConnection(@"Data Source=DESKTOP-Q6H0SBH;Initial Catalog=CMSdbd;Integrated Security=True");
                    conn.Open();
                    string query = "select * from Add_event where EventName like '"+name+"'";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Data Found");

                    DataTable dt = DataAccess.Data(query);
                    dataGridView1.AutoGenerateColumns = false;
                    dataGridView1.DataSource = dt;
                    dataGridView1.Refresh();
                    dataGridView1.ClearSelection();

                    this.Initialize();
                    //LoadEvent();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                return;
            }

        }

        private void Deletebutton_Click(object sender, EventArgs e)
        {
            
            string name = textBox1.Text;
            if (name != "")
            {
                string query = "delete from Add_event where EventName like '"+name+"'";
                DataAccess.Execute(query);
                MessageBox.Show("Data Deleted");
                this.Initialize();
                this.LoadEvent();
            }
            else
            {
                MessageBox.Show("Please Enter Name & Id");
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            indexRow = e.RowIndex;
            DataGridViewRow row = dataGridView1.Rows[indexRow];
            
            textBox1.Text = row.Cells[0].Value.ToString();
            comboBox2.Text = row.Cells[1].Value.ToString();
            dateTimePicker1.Text = row.Cells[2].Value.ToString();
            dateTimePicker2.Text = row.Cells[3].Value.ToString();
            comboBox1.Text = row.Cells[4].Value.ToString();
            textBox2.Text = row.Cells[5].Value.ToString();
            textBox3.Text = row.Cells[6].Value.ToString();

        }
    }
}
