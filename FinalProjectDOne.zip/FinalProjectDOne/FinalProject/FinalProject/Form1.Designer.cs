﻿namespace FinalProject
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.DropDownPanel = new System.Windows.Forms.Panel();
            this.Memberbutton = new System.Windows.Forms.Button();
            this.Executivebutton = new System.Windows.Forms.Button();
            this.Adminbutton = new System.Windows.Forms.Button();
            this.LogInbutton = new System.Windows.Forms.Button();
            this.HomeButton = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.member1 = new FinalProject.Member();
            this.executiveControlPanel1 = new FinalProject.ExecutiveControlPanel();
            this.adminControlPanel1 = new FinalProject.AdminControlPanel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.exit_button = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.DropDownPanel.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.ForeColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1158, 78);
            this.panel1.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.Location = new System.Drawing.Point(3, 3);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(153, 72);
            this.panel4.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Black;
            this.panel2.Controls.Add(this.exit_button);
            this.panel2.Controls.Add(this.DropDownPanel);
            this.panel2.Controls.Add(this.HomeButton);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 78);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(156, 583);
            this.panel2.TabIndex = 1;
            // 
            // DropDownPanel
            // 
            this.DropDownPanel.Controls.Add(this.Memberbutton);
            this.DropDownPanel.Controls.Add(this.Executivebutton);
            this.DropDownPanel.Controls.Add(this.Adminbutton);
            this.DropDownPanel.Controls.Add(this.LogInbutton);
            this.DropDownPanel.Location = new System.Drawing.Point(0, 43);
            this.DropDownPanel.MaximumSize = new System.Drawing.Size(156, 155);
            this.DropDownPanel.MinimumSize = new System.Drawing.Size(156, 37);
            this.DropDownPanel.Name = "DropDownPanel";
            this.DropDownPanel.Size = new System.Drawing.Size(156, 37);
            this.DropDownPanel.TabIndex = 0;
            // 
            // Memberbutton
            // 
            this.Memberbutton.Dock = System.Windows.Forms.DockStyle.Top;
            this.Memberbutton.ForeColor = System.Drawing.Color.Black;
            this.Memberbutton.Location = new System.Drawing.Point(0, 113);
            this.Memberbutton.Name = "Memberbutton";
            this.Memberbutton.Size = new System.Drawing.Size(156, 37);
            this.Memberbutton.TabIndex = 4;
            this.Memberbutton.Text = "Member";
            this.Memberbutton.UseVisualStyleBackColor = true;
            this.Memberbutton.Click += new System.EventHandler(this.Memberbutton_Click);
            // 
            // Executivebutton
            // 
            this.Executivebutton.Dock = System.Windows.Forms.DockStyle.Top;
            this.Executivebutton.ForeColor = System.Drawing.Color.Black;
            this.Executivebutton.Location = new System.Drawing.Point(0, 76);
            this.Executivebutton.Name = "Executivebutton";
            this.Executivebutton.Size = new System.Drawing.Size(156, 37);
            this.Executivebutton.TabIndex = 3;
            this.Executivebutton.Text = "Executive Panel";
            this.Executivebutton.UseVisualStyleBackColor = true;
            this.Executivebutton.Click += new System.EventHandler(this.Executivebutton_Click);
            // 
            // Adminbutton
            // 
            this.Adminbutton.Dock = System.Windows.Forms.DockStyle.Top;
            this.Adminbutton.ForeColor = System.Drawing.Color.Black;
            this.Adminbutton.Location = new System.Drawing.Point(0, 39);
            this.Adminbutton.Name = "Adminbutton";
            this.Adminbutton.Size = new System.Drawing.Size(156, 37);
            this.Adminbutton.TabIndex = 2;
            this.Adminbutton.Text = "Admin";
            this.Adminbutton.UseVisualStyleBackColor = true;
            this.Adminbutton.Click += new System.EventHandler(this.Adminbutton_Click);
            // 
            // LogInbutton
            // 
            this.LogInbutton.Dock = System.Windows.Forms.DockStyle.Top;
            this.LogInbutton.ForeColor = System.Drawing.Color.Black;
            this.LogInbutton.Location = new System.Drawing.Point(0, 0);
            this.LogInbutton.Name = "LogInbutton";
            this.LogInbutton.Size = new System.Drawing.Size(156, 39);
            this.LogInbutton.TabIndex = 1;
            this.LogInbutton.Text = "Log In";
            this.LogInbutton.UseVisualStyleBackColor = true;
            this.LogInbutton.MouseLeave += new System.EventHandler(this.LogInMouseLEave);
            this.LogInbutton.MouseHover += new System.EventHandler(this.LoginButtonHover);
            // 
            // HomeButton
            // 
            this.HomeButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.HomeButton.ForeColor = System.Drawing.Color.Black;
            this.HomeButton.Location = new System.Drawing.Point(0, 0);
            this.HomeButton.Name = "HomeButton";
            this.HomeButton.Size = new System.Drawing.Size(156, 37);
            this.HomeButton.TabIndex = 0;
            this.HomeButton.Text = "Home";
            this.HomeButton.UseVisualStyleBackColor = true;
            this.HomeButton.Click += new System.EventHandler(this.HomeButton_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.member1);
            this.panel3.Controls.Add(this.executiveControlPanel1);
            this.panel3.Controls.Add(this.adminControlPanel1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(156, 78);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1002, 583);
            this.panel3.TabIndex = 2;
            // 
            // member1
            // 
            this.member1.Location = new System.Drawing.Point(3, 0);
            this.member1.Name = "member1";
            this.member1.Size = new System.Drawing.Size(1002, 580);
            this.member1.TabIndex = 2;
            this.member1.Load += new System.EventHandler(this.member1_Load);
            // 
            // executiveControlPanel1
            // 
            this.executiveControlPanel1.Location = new System.Drawing.Point(3, 0);
            this.executiveControlPanel1.Name = "executiveControlPanel1";
            this.executiveControlPanel1.Size = new System.Drawing.Size(1002, 583);
            this.executiveControlPanel1.TabIndex = 1;
            this.executiveControlPanel1.Load += new System.EventHandler(this.executiveControlPanel1_Load);
            // 
            // adminControlPanel1
            // 
            this.adminControlPanel1.Location = new System.Drawing.Point(0, 0);
            this.adminControlPanel1.Name = "adminControlPanel1";
            this.adminControlPanel1.Size = new System.Drawing.Size(1002, 580);
            this.adminControlPanel1.TabIndex = 0;
            this.adminControlPanel1.Load += new System.EventHandler(this.adminControlPanel1_Load);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // exit_button
            // 
            this.exit_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exit_button.Location = new System.Drawing.Point(3, 521);
            this.exit_button.Name = "exit_button";
            this.exit_button.Size = new System.Drawing.Size(150, 35);
            this.exit_button.TabIndex = 1;
            this.exit_button.Text = "Exit";
            this.exit_button.UseVisualStyleBackColor = true;
            this.exit_button.Click += new System.EventHandler(this.exit_button_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1158, 661);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.DropDownPanel.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button HomeButton;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel DropDownPanel;
        private System.Windows.Forms.Button Memberbutton;
        private System.Windows.Forms.Button Executivebutton;
        private System.Windows.Forms.Button Adminbutton;
        private System.Windows.Forms.Button LogInbutton;
        private System.Windows.Forms.Timer timer1;
        private AdminControlPanel adminControlPanel1;
        private Member member1;
        private ExecutiveControlPanel executiveControlPanel1;
        private System.Windows.Forms.Button exit_button;
    }
}

