﻿namespace FinalProject
{
    partial class ExecutivePanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ExecutivePanel));
            this.panel1 = new System.Windows.Forms.Panel();
            this.Backbutton = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.VoteButton = new System.Windows.Forms.Button();
            this.volunbutton = new System.Windows.Forms.Button();
            this.Updatebutton = new System.Windows.Forms.Button();
            this.Advisorbutton = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.Controls.Add(this.Backbutton);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.VoteButton);
            this.panel1.Controls.Add(this.volunbutton);
            this.panel1.Controls.Add(this.Updatebutton);
            this.panel1.Controls.Add(this.Advisorbutton);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(857, 491);
            this.panel1.TabIndex = 0;
            // 
            // Backbutton
            // 
            this.Backbutton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Backbutton.BackgroundImage")));
            this.Backbutton.Location = new System.Drawing.Point(820, 3);
            this.Backbutton.Name = "Backbutton";
            this.Backbutton.Size = new System.Drawing.Size(25, 25);
            this.Backbutton.TabIndex = 5;
            this.Backbutton.UseVisualStyleBackColor = true;
            this.Backbutton.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button1.Location = new System.Drawing.Point(35, 42);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(122, 53);
            this.button1.TabIndex = 4;
            this.button1.Text = "Feedback and Suggestions";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // VoteButton
            // 
            this.VoteButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.VoteButton.FlatAppearance.BorderSize = 0;
            this.VoteButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.VoteButton.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VoteButton.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.VoteButton.Location = new System.Drawing.Point(532, 42);
            this.VoteButton.Name = "VoteButton";
            this.VoteButton.Size = new System.Drawing.Size(122, 53);
            this.VoteButton.TabIndex = 3;
            this.VoteButton.Text = "Given Votes";
            this.VoteButton.UseVisualStyleBackColor = false;
            this.VoteButton.Click += new System.EventHandler(this.VoteButton_Click);
            // 
            // volunbutton
            // 
            this.volunbutton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.volunbutton.FlatAppearance.BorderSize = 0;
            this.volunbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.volunbutton.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.volunbutton.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.volunbutton.Location = new System.Drawing.Point(694, 42);
            this.volunbutton.Name = "volunbutton";
            this.volunbutton.Size = new System.Drawing.Size(122, 53);
            this.volunbutton.TabIndex = 2;
            this.volunbutton.Text = "Applied Volunteer";
            this.volunbutton.UseVisualStyleBackColor = false;
            this.volunbutton.Click += new System.EventHandler(this.volunbutton_Click);
            // 
            // Updatebutton
            // 
            this.Updatebutton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.Updatebutton.FlatAppearance.BorderSize = 0;
            this.Updatebutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Updatebutton.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Updatebutton.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Updatebutton.Location = new System.Drawing.Point(372, 217);
            this.Updatebutton.Name = "Updatebutton";
            this.Updatebutton.Size = new System.Drawing.Size(122, 53);
            this.Updatebutton.TabIndex = 1;
            this.Updatebutton.Text = "Update Information";
            this.Updatebutton.UseVisualStyleBackColor = false;
            this.Updatebutton.Click += new System.EventHandler(this.Updatebutton_Click);
            // 
            // Advisorbutton
            // 
            this.Advisorbutton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.Advisorbutton.FlatAppearance.BorderSize = 0;
            this.Advisorbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Advisorbutton.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Advisorbutton.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Advisorbutton.Location = new System.Drawing.Point(193, 42);
            this.Advisorbutton.Name = "Advisorbutton";
            this.Advisorbutton.Size = new System.Drawing.Size(122, 53);
            this.Advisorbutton.TabIndex = 0;
            this.Advisorbutton.Text = "Advisors";
            this.Advisorbutton.UseVisualStyleBackColor = false;
            this.Advisorbutton.Click += new System.EventHandler(this.Advisorbutton_Click);
            // 
            // ExecutivePanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(857, 491);
            this.Controls.Add(this.panel1);
            this.Name = "ExecutivePanel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ExecutivePanel";
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button Backbutton;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button VoteButton;
        private System.Windows.Forms.Button volunbutton;
        private System.Windows.Forms.Button Updatebutton;
        private System.Windows.Forms.Button Advisorbutton;
    }
}