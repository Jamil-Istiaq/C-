﻿namespace FinalProject
{
    partial class MemberFrom
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MemberFrom));
            this.panel1 = new System.Windows.Forms.Panel();
            this.Backbutton = new System.Windows.Forms.Button();
            this.VotesButton = new System.Windows.Forms.Button();
            this.Eventsbutton = new System.Windows.Forms.Button();
            this.UpdateInfobutton = new System.Windows.Forms.Button();
            this.Advisorsbutton = new System.Windows.Forms.Button();
            this.Executivebutton = new System.Windows.Forms.Button();
            this.FeedbackButton = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.Controls.Add(this.Backbutton);
            this.panel1.Controls.Add(this.VotesButton);
            this.panel1.Controls.Add(this.Eventsbutton);
            this.panel1.Controls.Add(this.UpdateInfobutton);
            this.panel1.Controls.Add(this.Advisorsbutton);
            this.panel1.Controls.Add(this.Executivebutton);
            this.panel1.Controls.Add(this.FeedbackButton);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(857, 491);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // Backbutton
            // 
            this.Backbutton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Backbutton.BackgroundImage")));
            this.Backbutton.Location = new System.Drawing.Point(774, 23);
            this.Backbutton.Name = "Backbutton";
            this.Backbutton.Size = new System.Drawing.Size(50, 50);
            this.Backbutton.TabIndex = 11;
            this.Backbutton.UseVisualStyleBackColor = true;
            this.Backbutton.Click += new System.EventHandler(this.Backbutton_Click);
            // 
            // VotesButton
            // 
            this.VotesButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(14)))), ((int)(((byte)(60)))));
            this.VotesButton.FlatAppearance.BorderSize = 0;
            this.VotesButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.VotesButton.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VotesButton.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.VotesButton.Location = new System.Drawing.Point(629, 239);
            this.VotesButton.Name = "VotesButton";
            this.VotesButton.Size = new System.Drawing.Size(122, 53);
            this.VotesButton.TabIndex = 10;
            this.VotesButton.Text = "Votes";
            this.VotesButton.UseVisualStyleBackColor = false;
            this.VotesButton.Click += new System.EventHandler(this.VotesButton_Click);
            // 
            // Eventsbutton
            // 
            this.Eventsbutton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(14)))), ((int)(((byte)(60)))));
            this.Eventsbutton.FlatAppearance.BorderSize = 0;
            this.Eventsbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Eventsbutton.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Eventsbutton.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Eventsbutton.Location = new System.Drawing.Point(61, 249);
            this.Eventsbutton.Name = "Eventsbutton";
            this.Eventsbutton.Size = new System.Drawing.Size(122, 53);
            this.Eventsbutton.TabIndex = 9;
            this.Eventsbutton.Text = "Events";
            this.Eventsbutton.UseVisualStyleBackColor = false;
            this.Eventsbutton.Click += new System.EventHandler(this.Eventsbutton_Click);
            // 
            // UpdateInfobutton
            // 
            this.UpdateInfobutton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(14)))), ((int)(((byte)(60)))));
            this.UpdateInfobutton.FlatAppearance.BorderSize = 0;
            this.UpdateInfobutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.UpdateInfobutton.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UpdateInfobutton.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.UpdateInfobutton.Location = new System.Drawing.Point(366, 239);
            this.UpdateInfobutton.Name = "UpdateInfobutton";
            this.UpdateInfobutton.Size = new System.Drawing.Size(122, 53);
            this.UpdateInfobutton.TabIndex = 8;
            this.UpdateInfobutton.Text = "Update Information";
            this.UpdateInfobutton.UseVisualStyleBackColor = false;
            this.UpdateInfobutton.Click += new System.EventHandler(this.UpdateInfobutton_Click);
            // 
            // Advisorsbutton
            // 
            this.Advisorsbutton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(14)))), ((int)(((byte)(60)))));
            this.Advisorsbutton.FlatAppearance.BorderSize = 0;
            this.Advisorsbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Advisorsbutton.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Advisorsbutton.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Advisorsbutton.Location = new System.Drawing.Point(629, 97);
            this.Advisorsbutton.Name = "Advisorsbutton";
            this.Advisorsbutton.Size = new System.Drawing.Size(122, 53);
            this.Advisorsbutton.TabIndex = 7;
            this.Advisorsbutton.Text = "Advisors";
            this.Advisorsbutton.UseVisualStyleBackColor = false;
            this.Advisorsbutton.Click += new System.EventHandler(this.Advisorsbutton_Click);
            // 
            // Executivebutton
            // 
            this.Executivebutton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(14)))), ((int)(((byte)(60)))));
            this.Executivebutton.FlatAppearance.BorderSize = 0;
            this.Executivebutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Executivebutton.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Executivebutton.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Executivebutton.Location = new System.Drawing.Point(366, 97);
            this.Executivebutton.Name = "Executivebutton";
            this.Executivebutton.Size = new System.Drawing.Size(122, 53);
            this.Executivebutton.TabIndex = 6;
            this.Executivebutton.Text = "Executive Panel";
            this.Executivebutton.UseVisualStyleBackColor = false;
            this.Executivebutton.Click += new System.EventHandler(this.Executivebutton_Click);
            // 
            // FeedbackButton
            // 
            this.FeedbackButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(14)))), ((int)(((byte)(60)))));
            this.FeedbackButton.FlatAppearance.BorderSize = 0;
            this.FeedbackButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.FeedbackButton.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FeedbackButton.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.FeedbackButton.Location = new System.Drawing.Point(61, 97);
            this.FeedbackButton.Name = "FeedbackButton";
            this.FeedbackButton.Size = new System.Drawing.Size(122, 53);
            this.FeedbackButton.TabIndex = 5;
            this.FeedbackButton.Text = "Feedback";
            this.FeedbackButton.UseVisualStyleBackColor = false;
            this.FeedbackButton.Click += new System.EventHandler(this.FeedbackButton_Click);
            // 
            // MemberFrom
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(857, 491);
            this.Controls.Add(this.panel1);
            this.Name = "MemberFrom";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MemberFrom";
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button Executivebutton;
        private System.Windows.Forms.Button FeedbackButton;
        private System.Windows.Forms.Button Backbutton;
        private System.Windows.Forms.Button VotesButton;
        private System.Windows.Forms.Button Eventsbutton;
        private System.Windows.Forms.Button UpdateInfobutton;
        private System.Windows.Forms.Button Advisorsbutton;
    }
}