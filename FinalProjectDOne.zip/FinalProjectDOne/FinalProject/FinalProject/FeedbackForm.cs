﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FinalProject
{
    public partial class FeedbackForm : Form
    {
        SqlConnection conn = null;
        public FeedbackForm()
        {
            InitializeComponent();
        }
        private void Initialize()
        {
            textBox1.Text = richTextBox1.Text = "";
        }

        private void Backbutton_Click(object sender, EventArgs e)
        {
            MemberFrom m1 = new MemberFrom();
            m1.Show();
            this.Hide();
        }

        private void FeedbackForm_Load(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Data Source=DESKTOP-Q6H0SBH;Initial Catalog=CMSdbd;Integrated Security=True";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandText = "select EventName,Category,Vanue from Add_event";
            DataTable dt = new DataTable();
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            adp.Fill(dt);
            SuggestiondataGridView.DataSource = dt;
        }

        private void Suggestionlabel_Click(object sender, EventArgs e)
        {

        }

        private void Submitbutton_Click(object sender, EventArgs e)
        {
            if ((richTextBox1.Text!=null)&&(textBox1.Text != null))
            {
                string ename = textBox1.Text;
                string fdbk = richTextBox1.Text;
                
                try
                {
                    conn = new SqlConnection(@"Data Source=DESKTOP-Q6H0SBH;Initial Catalog=CMSdbd;Integrated Security=True");
                    conn.Open();

                    string query = "insert into Feedbacks ([Ename],[Feedbacks]) values('"+ename+"','"+fdbk+"')";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Feedback Submited");
                    this.Initialize();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }
            else
            {
                return;
            }
        }
    }
}
