﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FinalProject
{
    public partial class Member : UserControl
    {
        
        public Member()
        {
            InitializeComponent();
        }
        private void Initialize()
        {
            MusertextBox.Text = MPasstextBox.Text = "";

        }

        private void MloginButton_Click(object sender, EventArgs e)
        {
            
            SqlConnection sqlcon = new SqlConnection(@"Data Source=DESKTOP-Q6H0SBH;Initial Catalog=CMSdbd;Integrated Security=True");

            string query = "select Name, TempPass  from Add_member where Name = '"+MusertextBox.Text+"' and TempPass like '"+MPasstextBox.Text+"'";
            SqlDataAdapter sda = new SqlDataAdapter(query, sqlcon);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            if (dt.Rows.Count == 1)
            {
                MemberFrom mf = new MemberFrom();
                this.Hide();
                mf.Show();
                this.Initialize();

            }
            else
            {
                MessageBox.Show("Please try again");
            }

        }
    }
}
