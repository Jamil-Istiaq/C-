﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class MemberFrom : Form
    {
        public MemberFrom()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Backbutton_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void FeedbackButton_Click(object sender, EventArgs e)
        {
            FeedbackForm Feed = new FeedbackForm();
            Feed.Show();
            this.Hide();
        }

        private void Executivebutton_Click(object sender, EventArgs e)
        {
            ExecutiveListM Elm = new ExecutiveListM();
            Elm.Show();
            this.Hide();
        }

        private void Advisorsbutton_Click(object sender, EventArgs e)
        {
            AdvisorListM adv = new AdvisorListM();
            adv.Show();
            this.Hide();
        }

        private void Eventsbutton_Click(object sender, EventArgs e)
        {
            EventsAV ev = new EventsAV();
            ev.Show();
            this.Hide();
        }

        private void UpdateInfobutton_Click(object sender, EventArgs e)
        {
            UpdateInfoM Uim = new UpdateInfoM();
            Uim.Show();
            this.Hide();
        }

        private void VotesButton_Click(object sender, EventArgs e)
        {
            Votes v = new Votes();
            v.Show();
            this.Hide();
        }
    }
}
