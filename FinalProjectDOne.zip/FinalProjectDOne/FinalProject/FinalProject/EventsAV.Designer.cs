﻿namespace FinalProject
{
    partial class EventsAV
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EventsAV));
            this.panel1 = new System.Windows.Forms.Panel();
            this.Backbutton = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Applybutton = new System.Windows.Forms.Button();
            this.ExperiencerichTextBox = new System.Windows.Forms.RichTextBox();
            this.InterstedcomboBox = new System.Windows.Forms.ComboBox();
            this.EventNametextBox = new System.Windows.Forms.TextBox();
            this.Experiencelabel = new System.Windows.Forms.Label();
            this.Interstedlabel = new System.Windows.Forms.Label();
            this.EventNamelabel = new System.Windows.Forms.Label();
            this.Applylabel = new System.Windows.Forms.Label();
            this.EventsdataGridView = new System.Windows.Forms.DataGridView();
            this.EventsLabel = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.EventsdataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.Controls.Add(this.Backbutton);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.EventsdataGridView);
            this.panel1.Controls.Add(this.EventsLabel);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(857, 491);
            this.panel1.TabIndex = 0;
            // 
            // Backbutton
            // 
            this.Backbutton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Backbutton.BackgroundImage")));
            this.Backbutton.Location = new System.Drawing.Point(777, 10);
            this.Backbutton.Name = "Backbutton";
            this.Backbutton.Size = new System.Drawing.Size(50, 50);
            this.Backbutton.TabIndex = 13;
            this.Backbutton.UseVisualStyleBackColor = true;
            this.Backbutton.Click += new System.EventHandler(this.Backbutton_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.panel2.Controls.Add(this.textBox1);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.Applybutton);
            this.panel2.Controls.Add(this.ExperiencerichTextBox);
            this.panel2.Controls.Add(this.InterstedcomboBox);
            this.panel2.Controls.Add(this.EventNametextBox);
            this.panel2.Controls.Add(this.Experiencelabel);
            this.panel2.Controls.Add(this.Interstedlabel);
            this.panel2.Controls.Add(this.EventNamelabel);
            this.panel2.Controls.Add(this.Applylabel);
            this.panel2.Location = new System.Drawing.Point(435, 113);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(410, 339);
            this.panel2.TabIndex = 2;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(169, 51);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(188, 20);
            this.textBox1.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(24, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 17);
            this.label1.TabIndex = 8;
            this.label1.Text = "Member Name";
            // 
            // Applybutton
            // 
            this.Applybutton.BackColor = System.Drawing.Color.DarkSlateGray;
            this.Applybutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Applybutton.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Applybutton.Location = new System.Drawing.Point(169, 298);
            this.Applybutton.Name = "Applybutton";
            this.Applybutton.Size = new System.Drawing.Size(137, 25);
            this.Applybutton.TabIndex = 7;
            this.Applybutton.Text = "Apply";
            this.Applybutton.UseVisualStyleBackColor = false;
            this.Applybutton.Click += new System.EventHandler(this.Applybutton_Click);
            // 
            // ExperiencerichTextBox
            // 
            this.ExperiencerichTextBox.Location = new System.Drawing.Point(169, 172);
            this.ExperiencerichTextBox.Name = "ExperiencerichTextBox";
            this.ExperiencerichTextBox.Size = new System.Drawing.Size(188, 120);
            this.ExperiencerichTextBox.TabIndex = 6;
            this.ExperiencerichTextBox.Text = "";
            // 
            // InterstedcomboBox
            // 
            this.InterstedcomboBox.FormattingEnabled = true;
            this.InterstedcomboBox.Items.AddRange(new object[] {
            "Graphics Design",
            "Web Development",
            "Event Management",
            "Research and methodology",
            "Media",
            "Photography"});
            this.InterstedcomboBox.Location = new System.Drawing.Point(169, 123);
            this.InterstedcomboBox.Name = "InterstedcomboBox";
            this.InterstedcomboBox.Size = new System.Drawing.Size(188, 21);
            this.InterstedcomboBox.TabIndex = 5;
            // 
            // EventNametextBox
            // 
            this.EventNametextBox.Location = new System.Drawing.Point(169, 88);
            this.EventNametextBox.Name = "EventNametextBox";
            this.EventNametextBox.Size = new System.Drawing.Size(188, 20);
            this.EventNametextBox.TabIndex = 4;
            // 
            // Experiencelabel
            // 
            this.Experiencelabel.AutoSize = true;
            this.Experiencelabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.Experiencelabel.Location = new System.Drawing.Point(24, 172);
            this.Experiencelabel.Name = "Experiencelabel";
            this.Experiencelabel.Size = new System.Drawing.Size(74, 17);
            this.Experiencelabel.TabIndex = 3;
            this.Experiencelabel.Text = "Experience";
            // 
            // Interstedlabel
            // 
            this.Interstedlabel.AutoSize = true;
            this.Interstedlabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Interstedlabel.Location = new System.Drawing.Point(24, 123);
            this.Interstedlabel.Name = "Interstedlabel";
            this.Interstedlabel.Size = new System.Drawing.Size(112, 17);
            this.Interstedlabel.TabIndex = 2;
            this.Interstedlabel.Text = "Interested Sector";
            // 
            // EventNamelabel
            // 
            this.EventNamelabel.AutoSize = true;
            this.EventNamelabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.EventNamelabel.Location = new System.Drawing.Point(24, 88);
            this.EventNamelabel.Name = "EventNamelabel";
            this.EventNamelabel.Size = new System.Drawing.Size(82, 17);
            this.EventNamelabel.TabIndex = 1;
            this.EventNamelabel.Text = "Event Name";
            // 
            // Applylabel
            // 
            this.Applylabel.AutoSize = true;
            this.Applylabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Applylabel.ForeColor = System.Drawing.Color.Maroon;
            this.Applylabel.Location = new System.Drawing.Point(130, 9);
            this.Applylabel.Name = "Applylabel";
            this.Applylabel.Size = new System.Drawing.Size(168, 20);
            this.Applylabel.TabIndex = 0;
            this.Applylabel.Text = "Apply For Volunteer";
            // 
            // EventsdataGridView
            // 
            this.EventsdataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.EventsdataGridView.Location = new System.Drawing.Point(26, 113);
            this.EventsdataGridView.Name = "EventsdataGridView";
            this.EventsdataGridView.Size = new System.Drawing.Size(325, 339);
            this.EventsdataGridView.TabIndex = 1;
            // 
            // EventsLabel
            // 
            this.EventsLabel.AutoSize = true;
            this.EventsLabel.BackColor = System.Drawing.SystemColors.ControlText;
            this.EventsLabel.Font = new System.Drawing.Font("Segoe UI Emoji", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EventsLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.EventsLabel.Location = new System.Drawing.Point(39, 51);
            this.EventsLabel.Name = "EventsLabel";
            this.EventsLabel.Size = new System.Drawing.Size(61, 21);
            this.EventsLabel.TabIndex = 0;
            this.EventsLabel.Text = "Events";
            // 
            // EventsAV
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(857, 491);
            this.Controls.Add(this.panel1);
            this.Name = "EventsAV";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "EventsAV";
            this.Load += new System.EventHandler(this.EventsAV_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.EventsdataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView EventsdataGridView;
        private System.Windows.Forms.Label EventsLabel;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RichTextBox ExperiencerichTextBox;
        private System.Windows.Forms.ComboBox InterstedcomboBox;
        private System.Windows.Forms.TextBox EventNametextBox;
        private System.Windows.Forms.Label Experiencelabel;
        private System.Windows.Forms.Label Interstedlabel;
        private System.Windows.Forms.Label EventNamelabel;
        private System.Windows.Forms.Label Applylabel;
        private System.Windows.Forms.Button Applybutton;
        private System.Windows.Forms.Button Backbutton;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
    }
}