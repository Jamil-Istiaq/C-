﻿namespace FinalProject
{
    partial class Events
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Events));
            this.panel1 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Savebutton = new System.Windows.Forms.Button();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.Tolabel = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.Speakerlabel = new System.Windows.Forms.Label();
            this.VenueLabel = new System.Windows.Forms.Label();
            this.Budgetlabel = new System.Windows.Forms.Label();
            this.EventDatelabel = new System.Windows.Forms.Label();
            this.CatagoryLabel = new System.Windows.Forms.Label();
            this.EventNamelabel = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Backbutton = new System.Windows.Forms.Button();
            this.Deletebutton = new System.Windows.Forms.Button();
            this.Searchbutton = new System.Windows.Forms.Button();
            this.Editbutton = new System.Windows.Forms.Button();
            this.Newbutton = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.Savebutton);
            this.panel1.Controls.Add(this.dateTimePicker2);
            this.panel1.Controls.Add(this.Tolabel);
            this.panel1.Controls.Add(this.dateTimePicker1);
            this.panel1.Controls.Add(this.comboBox2);
            this.panel1.Controls.Add(this.comboBox1);
            this.panel1.Controls.Add(this.textBox3);
            this.panel1.Controls.Add(this.textBox2);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.Speakerlabel);
            this.panel1.Controls.Add(this.VenueLabel);
            this.panel1.Controls.Add(this.Budgetlabel);
            this.panel1.Controls.Add(this.EventDatelabel);
            this.panel1.Controls.Add(this.CatagoryLabel);
            this.panel1.Controls.Add(this.EventNamelabel);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1071, 508);
            this.panel1.TabIndex = 0;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(529, 95);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dataGridView1.Size = new System.Drawing.Size(486, 377);
            this.dataGridView1.TabIndex = 20;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // Savebutton
            // 
            this.Savebutton.BackColor = System.Drawing.Color.DarkSlateGray;
            this.Savebutton.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Savebutton.ForeColor = System.Drawing.Color.White;
            this.Savebutton.Location = new System.Drawing.Point(260, 431);
            this.Savebutton.Name = "Savebutton";
            this.Savebutton.Size = new System.Drawing.Size(106, 30);
            this.Savebutton.TabIndex = 19;
            this.Savebutton.Text = "Save";
            this.Savebutton.UseVisualStyleBackColor = false;
            this.Savebutton.Click += new System.EventHandler(this.Savebutton_Click);
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(384, 237);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(66, 20);
            this.dateTimePicker2.TabIndex = 14;
            // 
            // Tolabel
            // 
            this.Tolabel.AutoSize = true;
            this.Tolabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.Tolabel.ForeColor = System.Drawing.Color.Transparent;
            this.Tolabel.Location = new System.Drawing.Point(343, 237);
            this.Tolabel.Name = "Tolabel";
            this.Tolabel.Size = new System.Drawing.Size(23, 17);
            this.Tolabel.TabIndex = 13;
            this.Tolabel.Text = "To";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(258, 237);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(66, 20);
            this.dateTimePicker1.TabIndex = 12;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "Fest",
            "Seminar",
            "Workshop",
            "Event",
            "Meeting",
            "Quiz",
            "Other",
            "N/A"});
            this.comboBox2.Location = new System.Drawing.Point(258, 181);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(192, 21);
            this.comboBox2.TabIndex = 11;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Annex 1",
            "Annex 2",
            "Annex 3",
            "Annex 4",
            "Annex 5",
            "Annex 6",
            "Annex 7",
            "Annex 8",
            "Multi.",
            "Audi."});
            this.comboBox1.Location = new System.Drawing.Point(258, 277);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(192, 21);
            this.comboBox1.TabIndex = 10;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(258, 388);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(192, 20);
            this.textBox3.TabIndex = 9;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(258, 334);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(192, 20);
            this.textBox2.TabIndex = 8;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(258, 134);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(192, 20);
            this.textBox1.TabIndex = 7;
            // 
            // Speakerlabel
            // 
            this.Speakerlabel.AutoSize = true;
            this.Speakerlabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.Speakerlabel.ForeColor = System.Drawing.Color.Transparent;
            this.Speakerlabel.Location = new System.Drawing.Point(46, 337);
            this.Speakerlabel.Name = "Speakerlabel";
            this.Speakerlabel.Size = new System.Drawing.Size(96, 17);
            this.Speakerlabel.TabIndex = 6;
            this.Speakerlabel.Text = "Speaker Name";
            // 
            // VenueLabel
            // 
            this.VenueLabel.AutoSize = true;
            this.VenueLabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.VenueLabel.ForeColor = System.Drawing.Color.Transparent;
            this.VenueLabel.Location = new System.Drawing.Point(46, 286);
            this.VenueLabel.Name = "VenueLabel";
            this.VenueLabel.Size = new System.Drawing.Size(46, 17);
            this.VenueLabel.TabIndex = 5;
            this.VenueLabel.Text = "Venue";
            // 
            // Budgetlabel
            // 
            this.Budgetlabel.AutoSize = true;
            this.Budgetlabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.Budgetlabel.ForeColor = System.Drawing.Color.Transparent;
            this.Budgetlabel.Location = new System.Drawing.Point(46, 391);
            this.Budgetlabel.Name = "Budgetlabel";
            this.Budgetlabel.Size = new System.Drawing.Size(52, 17);
            this.Budgetlabel.TabIndex = 4;
            this.Budgetlabel.Text = "Budget";
            // 
            // EventDatelabel
            // 
            this.EventDatelabel.AutoSize = true;
            this.EventDatelabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.EventDatelabel.ForeColor = System.Drawing.Color.Transparent;
            this.EventDatelabel.Location = new System.Drawing.Point(46, 234);
            this.EventDatelabel.Name = "EventDatelabel";
            this.EventDatelabel.Size = new System.Drawing.Size(75, 17);
            this.EventDatelabel.TabIndex = 3;
            this.EventDatelabel.Text = "Event Date";
            // 
            // CatagoryLabel
            // 
            this.CatagoryLabel.AutoSize = true;
            this.CatagoryLabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.CatagoryLabel.ForeColor = System.Drawing.Color.Transparent;
            this.CatagoryLabel.Location = new System.Drawing.Point(46, 181);
            this.CatagoryLabel.Name = "CatagoryLabel";
            this.CatagoryLabel.Size = new System.Drawing.Size(64, 17);
            this.CatagoryLabel.TabIndex = 2;
            this.CatagoryLabel.Text = "Catagory";
            // 
            // EventNamelabel
            // 
            this.EventNamelabel.AutoSize = true;
            this.EventNamelabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.EventNamelabel.ForeColor = System.Drawing.Color.Transparent;
            this.EventNamelabel.Location = new System.Drawing.Point(46, 134);
            this.EventNamelabel.Name = "EventNamelabel";
            this.EventNamelabel.Size = new System.Drawing.Size(82, 17);
            this.EventNamelabel.TabIndex = 1;
            this.EventNamelabel.Text = "Event Name";
            // 
            // panel2
            // 
            this.panel2.AutoScroll = true;
            this.panel2.Controls.Add(this.Backbutton);
            this.panel2.Controls.Add(this.Deletebutton);
            this.panel2.Controls.Add(this.Searchbutton);
            this.panel2.Controls.Add(this.Editbutton);
            this.panel2.Controls.Add(this.Newbutton);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1071, 65);
            this.panel2.TabIndex = 0;
            // 
            // Backbutton
            // 
            this.Backbutton.Image = ((System.Drawing.Image)(resources.GetObject("Backbutton.Image")));
            this.Backbutton.Location = new System.Drawing.Point(651, 17);
            this.Backbutton.Name = "Backbutton";
            this.Backbutton.Size = new System.Drawing.Size(50, 40);
            this.Backbutton.TabIndex = 24;
            this.Backbutton.UseVisualStyleBackColor = true;
            this.Backbutton.Click += new System.EventHandler(this.Backbutton_Click);
            // 
            // Deletebutton
            // 
            this.Deletebutton.BackColor = System.Drawing.Color.DarkSlateGray;
            this.Deletebutton.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Deletebutton.ForeColor = System.Drawing.Color.White;
            this.Deletebutton.Location = new System.Drawing.Point(464, 17);
            this.Deletebutton.Name = "Deletebutton";
            this.Deletebutton.Size = new System.Drawing.Size(106, 30);
            this.Deletebutton.TabIndex = 23;
            this.Deletebutton.Text = "Delete";
            this.Deletebutton.UseVisualStyleBackColor = false;
            this.Deletebutton.Click += new System.EventHandler(this.Deletebutton_Click);
            // 
            // Searchbutton
            // 
            this.Searchbutton.BackColor = System.Drawing.Color.DarkSlateGray;
            this.Searchbutton.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Searchbutton.ForeColor = System.Drawing.Color.White;
            this.Searchbutton.Location = new System.Drawing.Point(312, 17);
            this.Searchbutton.Name = "Searchbutton";
            this.Searchbutton.Size = new System.Drawing.Size(106, 30);
            this.Searchbutton.TabIndex = 22;
            this.Searchbutton.Text = "Search";
            this.Searchbutton.UseVisualStyleBackColor = false;
            this.Searchbutton.Click += new System.EventHandler(this.Searchbutton_Click);
            // 
            // Editbutton
            // 
            this.Editbutton.BackColor = System.Drawing.Color.DarkSlateGray;
            this.Editbutton.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Editbutton.ForeColor = System.Drawing.Color.White;
            this.Editbutton.Location = new System.Drawing.Point(160, 17);
            this.Editbutton.Name = "Editbutton";
            this.Editbutton.Size = new System.Drawing.Size(106, 30);
            this.Editbutton.TabIndex = 21;
            this.Editbutton.Text = "Edit";
            this.Editbutton.UseVisualStyleBackColor = false;
            this.Editbutton.Click += new System.EventHandler(this.Editbutton_Click);
            // 
            // Newbutton
            // 
            this.Newbutton.BackColor = System.Drawing.Color.DarkSlateGray;
            this.Newbutton.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Newbutton.ForeColor = System.Drawing.Color.White;
            this.Newbutton.Location = new System.Drawing.Point(22, 17);
            this.Newbutton.Name = "Newbutton";
            this.Newbutton.Size = new System.Drawing.Size(106, 30);
            this.Newbutton.TabIndex = 20;
            this.Newbutton.Text = "New";
            this.Newbutton.UseVisualStyleBackColor = false;
            this.Newbutton.Click += new System.EventHandler(this.Newbutton_Click);
            // 
            // Events
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1071, 508);
            this.Controls.Add(this.panel1);
            this.Name = "Events";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Events";
            this.Load += new System.EventHandler(this.Events_Load_1);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label EventNamelabel;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Label Tolabel;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label Speakerlabel;
        private System.Windows.Forms.Label VenueLabel;
        private System.Windows.Forms.Label Budgetlabel;
        private System.Windows.Forms.Label EventDatelabel;
        private System.Windows.Forms.Label CatagoryLabel;
        private System.Windows.Forms.Button Savebutton;
        private System.Windows.Forms.Button Deletebutton;
        private System.Windows.Forms.Button Searchbutton;
        private System.Windows.Forms.Button Editbutton;
        private System.Windows.Forms.Button Newbutton;
        private System.Windows.Forms.Button Backbutton;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}