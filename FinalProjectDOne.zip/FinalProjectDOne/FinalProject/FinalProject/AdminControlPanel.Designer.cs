﻿namespace FinalProject
{
    partial class AdminControlPanel
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminControlPanel));
            this.Adminpanel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.AloginButton = new System.Windows.Forms.Button();
            this.APasstextBox = new System.Windows.Forms.TextBox();
            this.AusertextBox = new System.Windows.Forms.TextBox();
            this.APass = new System.Windows.Forms.PictureBox();
            this.AUser1 = new System.Windows.Forms.PictureBox();
            this.Adminpanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.APass)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AUser1)).BeginInit();
            this.SuspendLayout();
            // 
            // Adminpanel1
            // 
            this.Adminpanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Adminpanel1.BackgroundImage")));
            this.Adminpanel1.Controls.Add(this.label1);
            this.Adminpanel1.Controls.Add(this.pictureBox4);
            this.Adminpanel1.Controls.Add(this.panel1);
            this.Adminpanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Adminpanel1.Location = new System.Drawing.Point(0, 0);
            this.Adminpanel1.Name = "Adminpanel1";
            this.Adminpanel1.Size = new System.Drawing.Size(981, 561);
            this.Adminpanel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Ravie", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkRed;
            this.label1.Location = new System.Drawing.Point(95, 202);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 17);
            this.label1.TabIndex = 4;
            this.label1.Text = "Admin";
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(89, 222);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(123, 108);
            this.pictureBox4.TabIndex = 1;
            this.pictureBox4.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.panel1.Controls.Add(this.AloginButton);
            this.panel1.Controls.Add(this.APasstextBox);
            this.panel1.Controls.Add(this.AusertextBox);
            this.panel1.Controls.Add(this.APass);
            this.panel1.Controls.Add(this.AUser1);
            this.panel1.Location = new System.Drawing.Point(330, 183);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(451, 227);
            this.panel1.TabIndex = 0;
            // 
            // AloginButton
            // 
            this.AloginButton.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.AloginButton.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AloginButton.Location = new System.Drawing.Point(208, 161);
            this.AloginButton.Name = "AloginButton";
            this.AloginButton.Size = new System.Drawing.Size(116, 31);
            this.AloginButton.TabIndex = 4;
            this.AloginButton.Text = "Log In";
            this.AloginButton.UseVisualStyleBackColor = false;
            this.AloginButton.Click += new System.EventHandler(this.AloginButton_Click);
            // 
            // APasstextBox
            // 
            this.APasstextBox.Location = new System.Drawing.Point(171, 114);
            this.APasstextBox.Name = "APasstextBox";
            this.APasstextBox.PasswordChar = '*';
            this.APasstextBox.Size = new System.Drawing.Size(188, 20);
            this.APasstextBox.TabIndex = 3;
            // 
            // AusertextBox
            // 
            this.AusertextBox.Location = new System.Drawing.Point(171, 59);
            this.AusertextBox.Name = "AusertextBox";
            this.AusertextBox.Size = new System.Drawing.Size(188, 20);
            this.AusertextBox.TabIndex = 2;
            // 
            // APass
            // 
            this.APass.Image = ((System.Drawing.Image)(resources.GetObject("APass.Image")));
            this.APass.Location = new System.Drawing.Point(87, 114);
            this.APass.Name = "APass";
            this.APass.Size = new System.Drawing.Size(41, 33);
            this.APass.TabIndex = 1;
            this.APass.TabStop = false;
            // 
            // AUser1
            // 
            this.AUser1.Image = ((System.Drawing.Image)(resources.GetObject("AUser1.Image")));
            this.AUser1.Location = new System.Drawing.Point(87, 59);
            this.AUser1.Name = "AUser1";
            this.AUser1.Size = new System.Drawing.Size(41, 33);
            this.AUser1.TabIndex = 0;
            this.AUser1.TabStop = false;
            // 
            // AdminControlPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.Adminpanel1);
            this.Name = "AdminControlPanel";
            this.Size = new System.Drawing.Size(981, 561);
            this.Adminpanel1.ResumeLayout(false);
            this.Adminpanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.APass)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AUser1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel Adminpanel1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Button AloginButton;
        private System.Windows.Forms.TextBox APasstextBox;
        private System.Windows.Forms.TextBox AusertextBox;
        private System.Windows.Forms.PictureBox APass;
        private System.Windows.Forms.PictureBox AUser1;
        private System.Windows.Forms.Label label1;
    }
}
