﻿namespace FinalProject
{
    partial class Member
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Member));
            this.Executivepanel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.MloginButton = new System.Windows.Forms.Button();
            this.MPasstextBox = new System.Windows.Forms.TextBox();
            this.MusertextBox = new System.Windows.Forms.TextBox();
            this.EPass = new System.Windows.Forms.PictureBox();
            this.EUser1 = new System.Windows.Forms.PictureBox();
            this.Executivepanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.EPass)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EUser1)).BeginInit();
            this.SuspendLayout();
            // 
            // Executivepanel1
            // 
            this.Executivepanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Executivepanel1.BackgroundImage")));
            this.Executivepanel1.Controls.Add(this.label1);
            this.Executivepanel1.Controls.Add(this.pictureBox1);
            this.Executivepanel1.Controls.Add(this.panel1);
            this.Executivepanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Executivepanel1.Location = new System.Drawing.Point(0, 0);
            this.Executivepanel1.Name = "Executivepanel1";
            this.Executivepanel1.Size = new System.Drawing.Size(981, 561);
            this.Executivepanel1.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Ravie", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkRed;
            this.label1.Location = new System.Drawing.Point(109, 234);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "Member";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.Location = new System.Drawing.Point(103, 254);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(123, 108);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.panel1.Controls.Add(this.MloginButton);
            this.panel1.Controls.Add(this.MPasstextBox);
            this.panel1.Controls.Add(this.MusertextBox);
            this.panel1.Controls.Add(this.EPass);
            this.panel1.Controls.Add(this.EUser1);
            this.panel1.Location = new System.Drawing.Point(346, 195);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(451, 227);
            this.panel1.TabIndex = 1;
            // 
            // MloginButton
            // 
            this.MloginButton.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.MloginButton.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MloginButton.Location = new System.Drawing.Point(208, 161);
            this.MloginButton.Name = "MloginButton";
            this.MloginButton.Size = new System.Drawing.Size(116, 31);
            this.MloginButton.TabIndex = 4;
            this.MloginButton.Text = "Log In";
            this.MloginButton.UseVisualStyleBackColor = false;
            this.MloginButton.Click += new System.EventHandler(this.MloginButton_Click);
            // 
            // MPasstextBox
            // 
            this.MPasstextBox.Location = new System.Drawing.Point(171, 114);
            this.MPasstextBox.Name = "MPasstextBox";
            this.MPasstextBox.PasswordChar = '#';
            this.MPasstextBox.Size = new System.Drawing.Size(188, 20);
            this.MPasstextBox.TabIndex = 3;
            // 
            // MusertextBox
            // 
            this.MusertextBox.Location = new System.Drawing.Point(171, 59);
            this.MusertextBox.Name = "MusertextBox";
            this.MusertextBox.Size = new System.Drawing.Size(188, 20);
            this.MusertextBox.TabIndex = 2;
            // 
            // EPass
            // 
            this.EPass.Image = ((System.Drawing.Image)(resources.GetObject("EPass.Image")));
            this.EPass.Location = new System.Drawing.Point(87, 114);
            this.EPass.Name = "EPass";
            this.EPass.Size = new System.Drawing.Size(41, 33);
            this.EPass.TabIndex = 1;
            this.EPass.TabStop = false;
            // 
            // EUser1
            // 
            this.EUser1.Image = ((System.Drawing.Image)(resources.GetObject("EUser1.Image")));
            this.EUser1.Location = new System.Drawing.Point(87, 59);
            this.EUser1.Name = "EUser1";
            this.EUser1.Size = new System.Drawing.Size(41, 33);
            this.EUser1.TabIndex = 0;
            this.EUser1.TabStop = false;
            // 
            // Member
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.Executivepanel1);
            this.Name = "Member";
            this.Size = new System.Drawing.Size(981, 561);
            this.Executivepanel1.ResumeLayout(false);
            this.Executivepanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.EPass)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EUser1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel Executivepanel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button MloginButton;
        private System.Windows.Forms.TextBox MPasstextBox;
        private System.Windows.Forms.TextBox MusertextBox;
        private System.Windows.Forms.PictureBox EPass;
        private System.Windows.Forms.PictureBox EUser1;
    }
}
