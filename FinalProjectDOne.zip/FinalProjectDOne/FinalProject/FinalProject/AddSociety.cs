﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FinalProject
{
    public partial class AddSociety : Form
    {
        SqlConnection conn = null;
        public AddSociety()
        {
            InitializeComponent();
        }
         private void Initialize()
        {
            SocietyNameTextBox.Text= MemberCapacitytextBox.Text =SocietyTypeComboBox.Text= "";
            this.LoadSociety();
        }
        private void LoadSociety()
        {
            try
            {
                string query = "Select * from Add_Society";
               
                DataTable dt = DataAccess.Data(query);
                societyGridView.AutoGenerateColumns = false;
                societyGridView.DataSource = dt;
                societyGridView.Refresh();
                societyGridView.ClearSelection();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void Backbutton_Click(object sender, EventArgs e)
        {
            AdminForm ad3 = new AdminForm();
            ad3.Show();
            this.Hide();
        }

        private void Submitbutton_Click(object sender, EventArgs e)
        {
            try
            {
                conn = new SqlConnection(@"Data Source=DESKTOP-Q6H0SBH;Initial Catalog=CMSdbd;Integrated Security=True");
                conn.Open();
                string SocietyType = SocietyTypeComboBox.SelectedItem.ToString();
                string query = "insert into Add_society([SocietyName],[MemberCap],[SocietyType]) VALUES('" + SocietyNameTextBox.Text + "','" + MemberCapacitytextBox.Text + "','" + SocietyType + "')";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Added Data");
                this.Initialize();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
              conn.Close();
            }


            
        }

       

        private void Deletebutton_Click(object sender, EventArgs e)
        {
            string name = SocietyNameTextBox.Text;
            if (name != "")
            {
                string query = "delete from Add_society where SocietyName like '"+name+"'";
                DataAccess.Execute(query);
                MessageBox.Show("Data Deleted");
                this.Initialize();
            }
            else
            {
                MessageBox.Show("Please Enter Name");
            }

        }

        private void AddSociety_Load(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Data Source=DESKTOP-Q6H0SBH;Initial Catalog=CMSdbd;Integrated Security=True";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandText = "select * from Add_society";
            DataTable dt = new DataTable();
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            adp.Fill(dt);
            societyGridView.DataSource = dt;
            conn.Close();
        }
    }
}
