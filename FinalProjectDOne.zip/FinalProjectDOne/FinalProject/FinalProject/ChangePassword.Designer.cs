﻿namespace FinalProject
{
    partial class ChangePassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ChangePassword));
            this.panel1 = new System.Windows.Forms.Panel();
            this.changePass = new System.Windows.Forms.Label();
            this.changeUnametext = new System.Windows.Forms.TextBox();
            this.changeUname = new System.Windows.Forms.Label();
            this.Backbutton = new System.Windows.Forms.Button();
            this.Submitbutton = new System.Windows.Forms.Button();
            this.ConfirmtextBox = new System.Windows.Forms.TextBox();
            this.NewtextBox = new System.Windows.Forms.TextBox();
            this.OldtextBox = new System.Windows.Forms.TextBox();
            this.ConfirmPasswordlabel = new System.Windows.Forms.Label();
            this.NewPasswordlabel = new System.Windows.Forms.Label();
            this.OldPasswordlabel = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel1.Controls.Add(this.changePass);
            this.panel1.Controls.Add(this.changeUnametext);
            this.panel1.Controls.Add(this.changeUname);
            this.panel1.Controls.Add(this.Backbutton);
            this.panel1.Controls.Add(this.Submitbutton);
            this.panel1.Controls.Add(this.ConfirmtextBox);
            this.panel1.Controls.Add(this.NewtextBox);
            this.panel1.Controls.Add(this.OldtextBox);
            this.panel1.Controls.Add(this.ConfirmPasswordlabel);
            this.panel1.Controls.Add(this.NewPasswordlabel);
            this.panel1.Controls.Add(this.OldPasswordlabel);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(841, 452);
            this.panel1.TabIndex = 0;
            // 
            // changePass
            // 
            this.changePass.AutoSize = true;
            this.changePass.ForeColor = System.Drawing.Color.LightCoral;
            this.changePass.Location = new System.Drawing.Point(427, 349);
            this.changePass.Name = "changePass";
            this.changePass.Size = new System.Drawing.Size(132, 13);
            this.changePass.TabIndex = 23;
            this.changePass.Text = "Password dose not match ";
            // 
            // changeUnametext
            // 
            this.changeUnametext.Location = new System.Drawing.Point(389, 98);
            this.changeUnametext.Name = "changeUnametext";
            this.changeUnametext.Size = new System.Drawing.Size(221, 20);
            this.changeUnametext.TabIndex = 22;
            // 
            // changeUname
            // 
            this.changeUname.AutoSize = true;
            this.changeUname.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.changeUname.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.changeUname.Location = new System.Drawing.Point(174, 101);
            this.changeUname.Name = "changeUname";
            this.changeUname.Size = new System.Drawing.Size(75, 17);
            this.changeUname.TabIndex = 21;
            this.changeUname.Text = "User Name";
            // 
            // Backbutton
            // 
            this.Backbutton.Image = ((System.Drawing.Image)(resources.GetObject("Backbutton.Image")));
            this.Backbutton.Location = new System.Drawing.Point(761, 12);
            this.Backbutton.Name = "Backbutton";
            this.Backbutton.Size = new System.Drawing.Size(50, 40);
            this.Backbutton.TabIndex = 20;
            this.Backbutton.UseVisualStyleBackColor = true;
            this.Backbutton.Click += new System.EventHandler(this.Backbutton_Click);
            // 
            // Submitbutton
            // 
            this.Submitbutton.BackColor = System.Drawing.Color.DarkSlateGray;
            this.Submitbutton.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Submitbutton.ForeColor = System.Drawing.Color.White;
            this.Submitbutton.Location = new System.Drawing.Point(417, 399);
            this.Submitbutton.Name = "Submitbutton";
            this.Submitbutton.Size = new System.Drawing.Size(142, 30);
            this.Submitbutton.TabIndex = 18;
            this.Submitbutton.Text = "Submit";
            this.Submitbutton.UseVisualStyleBackColor = false;
            this.Submitbutton.Click += new System.EventHandler(this.Submitbutton_Click);
            // 
            // ConfirmtextBox
            // 
            this.ConfirmtextBox.Location = new System.Drawing.Point(389, 312);
            this.ConfirmtextBox.Name = "ConfirmtextBox";
            this.ConfirmtextBox.Size = new System.Drawing.Size(221, 20);
            this.ConfirmtextBox.TabIndex = 5;
            this.ConfirmtextBox.TextChanged += new System.EventHandler(this.ConfirmtextBox_TextChanged);
            // 
            // NewtextBox
            // 
            this.NewtextBox.Location = new System.Drawing.Point(389, 240);
            this.NewtextBox.Name = "NewtextBox";
            this.NewtextBox.Size = new System.Drawing.Size(221, 20);
            this.NewtextBox.TabIndex = 4;
            // 
            // OldtextBox
            // 
            this.OldtextBox.Location = new System.Drawing.Point(389, 172);
            this.OldtextBox.Name = "OldtextBox";
            this.OldtextBox.Size = new System.Drawing.Size(221, 20);
            this.OldtextBox.TabIndex = 3;
            // 
            // ConfirmPasswordlabel
            // 
            this.ConfirmPasswordlabel.AutoSize = true;
            this.ConfirmPasswordlabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ConfirmPasswordlabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.ConfirmPasswordlabel.Location = new System.Drawing.Point(174, 315);
            this.ConfirmPasswordlabel.Name = "ConfirmPasswordlabel";
            this.ConfirmPasswordlabel.Size = new System.Drawing.Size(120, 17);
            this.ConfirmPasswordlabel.TabIndex = 2;
            this.ConfirmPasswordlabel.Text = "Confirm Password";
            this.ConfirmPasswordlabel.Click += new System.EventHandler(this.label2_Click);
            // 
            // NewPasswordlabel
            // 
            this.NewPasswordlabel.AutoSize = true;
            this.NewPasswordlabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NewPasswordlabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.NewPasswordlabel.Location = new System.Drawing.Point(174, 243);
            this.NewPasswordlabel.Name = "NewPasswordlabel";
            this.NewPasswordlabel.Size = new System.Drawing.Size(97, 17);
            this.NewPasswordlabel.TabIndex = 1;
            this.NewPasswordlabel.Text = "New Password";
            // 
            // OldPasswordlabel
            // 
            this.OldPasswordlabel.AutoSize = true;
            this.OldPasswordlabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OldPasswordlabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.OldPasswordlabel.Location = new System.Drawing.Point(174, 172);
            this.OldPasswordlabel.Name = "OldPasswordlabel";
            this.OldPasswordlabel.Size = new System.Drawing.Size(92, 17);
            this.OldPasswordlabel.TabIndex = 0;
            this.OldPasswordlabel.Text = "Old Password";
            // 
            // ChangePassword
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(841, 452);
            this.Controls.Add(this.panel1);
            this.Name = "ChangePassword";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ChangePassword";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label ConfirmPasswordlabel;
        private System.Windows.Forms.Label NewPasswordlabel;
        private System.Windows.Forms.Label OldPasswordlabel;
        private System.Windows.Forms.TextBox ConfirmtextBox;
        private System.Windows.Forms.TextBox NewtextBox;
        private System.Windows.Forms.TextBox OldtextBox;
        private System.Windows.Forms.Button Submitbutton;
        private System.Windows.Forms.Button Backbutton;
        private System.Windows.Forms.TextBox changeUnametext;
        private System.Windows.Forms.Label changeUname;
        private System.Windows.Forms.Label changePass;
    }
}