﻿namespace FinalProject
{
    partial class AddAdvisor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddAdvisor));
            this.panel1 = new System.Windows.Forms.Panel();
            this.Backbutton = new System.Windows.Forms.Button();
            this.AddadvisordataGridView = new System.Windows.Forms.DataGridView();
            this.Updatebutton = new System.Windows.Forms.Button();
            this.Addbutton = new System.Windows.Forms.Button();
            this.PositioncomboBox = new System.Windows.Forms.ComboBox();
            this.DeptcomboBox = new System.Windows.Forms.ComboBox();
            this.EmailtextBox = new System.Windows.Forms.TextBox();
            this.PhonetextBox = new System.Windows.Forms.TextBox();
            this.IdtextBox = new System.Windows.Forms.TextBox();
            this.NametextBox = new System.Windows.Forms.TextBox();
            this.EmailLabel = new System.Windows.Forms.Label();
            this.PhoneNolabel = new System.Windows.Forms.Label();
            this.Positionlabel = new System.Windows.Forms.Label();
            this.Departmentlabel = new System.Windows.Forms.Label();
            this.Idlabel = new System.Windows.Forms.Label();
            this.Namelabel = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AddadvisordataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel1.Controls.Add(this.Backbutton);
            this.panel1.Controls.Add(this.AddadvisordataGridView);
            this.panel1.Controls.Add(this.Updatebutton);
            this.panel1.Controls.Add(this.Addbutton);
            this.panel1.Controls.Add(this.PositioncomboBox);
            this.panel1.Controls.Add(this.DeptcomboBox);
            this.panel1.Controls.Add(this.EmailtextBox);
            this.panel1.Controls.Add(this.PhonetextBox);
            this.panel1.Controls.Add(this.IdtextBox);
            this.panel1.Controls.Add(this.NametextBox);
            this.panel1.Controls.Add(this.EmailLabel);
            this.panel1.Controls.Add(this.PhoneNolabel);
            this.panel1.Controls.Add(this.Positionlabel);
            this.panel1.Controls.Add(this.Departmentlabel);
            this.panel1.Controls.Add(this.Idlabel);
            this.panel1.Controls.Add(this.Namelabel);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(841, 452);
            this.panel1.TabIndex = 0;
            // 
            // Backbutton
            // 
            this.Backbutton.Image = ((System.Drawing.Image)(resources.GetObject("Backbutton.Image")));
            this.Backbutton.Location = new System.Drawing.Point(752, 12);
            this.Backbutton.Name = "Backbutton";
            this.Backbutton.Size = new System.Drawing.Size(50, 40);
            this.Backbutton.TabIndex = 21;
            this.Backbutton.UseVisualStyleBackColor = true;
            this.Backbutton.Click += new System.EventHandler(this.Backbutton_Click);
            // 
            // AddadvisordataGridView
            // 
            this.AddadvisordataGridView.AllowUserToAddRows = false;
            this.AddadvisordataGridView.AllowUserToDeleteRows = false;
            this.AddadvisordataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.AddadvisordataGridView.Location = new System.Drawing.Point(426, 58);
            this.AddadvisordataGridView.Name = "AddadvisordataGridView";
            this.AddadvisordataGridView.ReadOnly = true;
            this.AddadvisordataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.AddadvisordataGridView.Size = new System.Drawing.Size(390, 365);
            this.AddadvisordataGridView.TabIndex = 20;
            this.AddadvisordataGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.AddadvisordataGridView_CellClick);
            // 
            // Updatebutton
            // 
            this.Updatebutton.BackColor = System.Drawing.Color.DarkSlateGray;
            this.Updatebutton.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Updatebutton.ForeColor = System.Drawing.Color.White;
            this.Updatebutton.Location = new System.Drawing.Point(296, 389);
            this.Updatebutton.Name = "Updatebutton";
            this.Updatebutton.Size = new System.Drawing.Size(106, 30);
            this.Updatebutton.TabIndex = 19;
            this.Updatebutton.Text = "Update";
            this.Updatebutton.UseVisualStyleBackColor = false;
            this.Updatebutton.Click += new System.EventHandler(this.Updatebutton_Click);
            // 
            // Addbutton
            // 
            this.Addbutton.BackColor = System.Drawing.Color.DarkSlateGray;
            this.Addbutton.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addbutton.ForeColor = System.Drawing.Color.White;
            this.Addbutton.Location = new System.Drawing.Point(116, 389);
            this.Addbutton.Name = "Addbutton";
            this.Addbutton.Size = new System.Drawing.Size(106, 30);
            this.Addbutton.TabIndex = 18;
            this.Addbutton.Text = "Add";
            this.Addbutton.UseVisualStyleBackColor = false;
            this.Addbutton.Click += new System.EventHandler(this.Addbutton_Click);
            // 
            // PositioncomboBox
            // 
            this.PositioncomboBox.FormattingEnabled = true;
            this.PositioncomboBox.Items.AddRange(new object[] {
            "Dean",
            "Professor",
            "Assistant Professor",
            "Lecturer"});
            this.PositioncomboBox.Location = new System.Drawing.Point(178, 215);
            this.PositioncomboBox.Name = "PositioncomboBox";
            this.PositioncomboBox.Size = new System.Drawing.Size(206, 21);
            this.PositioncomboBox.TabIndex = 11;
            // 
            // DeptcomboBox
            // 
            this.DeptcomboBox.FormattingEnabled = true;
            this.DeptcomboBox.Items.AddRange(new object[] {
            "CSE",
            "CSSE",
            "COE",
            "SE",
            "EEE"});
            this.DeptcomboBox.Location = new System.Drawing.Point(178, 162);
            this.DeptcomboBox.Name = "DeptcomboBox";
            this.DeptcomboBox.Size = new System.Drawing.Size(206, 21);
            this.DeptcomboBox.TabIndex = 10;
            // 
            // EmailtextBox
            // 
            this.EmailtextBox.Location = new System.Drawing.Point(178, 323);
            this.EmailtextBox.Name = "EmailtextBox";
            this.EmailtextBox.Size = new System.Drawing.Size(206, 20);
            this.EmailtextBox.TabIndex = 9;
            // 
            // PhonetextBox
            // 
            this.PhonetextBox.Location = new System.Drawing.Point(178, 270);
            this.PhonetextBox.Name = "PhonetextBox";
            this.PhonetextBox.Size = new System.Drawing.Size(206, 20);
            this.PhonetextBox.TabIndex = 8;
            // 
            // IdtextBox
            // 
            this.IdtextBox.Location = new System.Drawing.Point(178, 115);
            this.IdtextBox.Name = "IdtextBox";
            this.IdtextBox.ReadOnly = true;
            this.IdtextBox.Size = new System.Drawing.Size(206, 20);
            this.IdtextBox.TabIndex = 7;
            // 
            // NametextBox
            // 
            this.NametextBox.Location = new System.Drawing.Point(178, 69);
            this.NametextBox.Name = "NametextBox";
            this.NametextBox.Size = new System.Drawing.Size(206, 20);
            this.NametextBox.TabIndex = 6;
            // 
            // EmailLabel
            // 
            this.EmailLabel.AutoSize = true;
            this.EmailLabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmailLabel.ForeColor = System.Drawing.Color.White;
            this.EmailLabel.Location = new System.Drawing.Point(25, 326);
            this.EmailLabel.Name = "EmailLabel";
            this.EmailLabel.Size = new System.Drawing.Size(42, 17);
            this.EmailLabel.TabIndex = 5;
            this.EmailLabel.Text = "Email";
            // 
            // PhoneNolabel
            // 
            this.PhoneNolabel.AutoSize = true;
            this.PhoneNolabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PhoneNolabel.ForeColor = System.Drawing.Color.White;
            this.PhoneNolabel.Location = new System.Drawing.Point(25, 273);
            this.PhoneNolabel.Name = "PhoneNolabel";
            this.PhoneNolabel.Size = new System.Drawing.Size(69, 17);
            this.PhoneNolabel.TabIndex = 4;
            this.PhoneNolabel.Text = "Phone No";
            // 
            // Positionlabel
            // 
            this.Positionlabel.AutoSize = true;
            this.Positionlabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Positionlabel.ForeColor = System.Drawing.Color.White;
            this.Positionlabel.Location = new System.Drawing.Point(25, 215);
            this.Positionlabel.Name = "Positionlabel";
            this.Positionlabel.Size = new System.Drawing.Size(59, 17);
            this.Positionlabel.TabIndex = 3;
            this.Positionlabel.Text = "Position";
            // 
            // Departmentlabel
            // 
            this.Departmentlabel.AutoSize = true;
            this.Departmentlabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Departmentlabel.ForeColor = System.Drawing.Color.White;
            this.Departmentlabel.Location = new System.Drawing.Point(25, 162);
            this.Departmentlabel.Name = "Departmentlabel";
            this.Departmentlabel.Size = new System.Drawing.Size(82, 17);
            this.Departmentlabel.TabIndex = 2;
            this.Departmentlabel.Text = "Department";
            // 
            // Idlabel
            // 
            this.Idlabel.AutoSize = true;
            this.Idlabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Idlabel.ForeColor = System.Drawing.Color.White;
            this.Idlabel.Location = new System.Drawing.Point(25, 115);
            this.Idlabel.Name = "Idlabel";
            this.Idlabel.Size = new System.Drawing.Size(20, 17);
            this.Idlabel.TabIndex = 1;
            this.Idlabel.Text = "Id";
            // 
            // Namelabel
            // 
            this.Namelabel.AutoSize = true;
            this.Namelabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Namelabel.ForeColor = System.Drawing.Color.White;
            this.Namelabel.Location = new System.Drawing.Point(25, 69);
            this.Namelabel.Name = "Namelabel";
            this.Namelabel.Size = new System.Drawing.Size(44, 17);
            this.Namelabel.TabIndex = 0;
            this.Namelabel.Text = "Name";
            // 
            // AddAdvisor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(841, 452);
            this.Controls.Add(this.panel1);
            this.Name = "AddAdvisor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AddAdvisor";
            this.Load += new System.EventHandler(this.AddAdvisor_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AddadvisordataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox PositioncomboBox;
        private System.Windows.Forms.ComboBox DeptcomboBox;
        private System.Windows.Forms.TextBox EmailtextBox;
        private System.Windows.Forms.TextBox PhonetextBox;
        private System.Windows.Forms.TextBox IdtextBox;
        private System.Windows.Forms.TextBox NametextBox;
        private System.Windows.Forms.Label EmailLabel;
        private System.Windows.Forms.Label PhoneNolabel;
        private System.Windows.Forms.Label Positionlabel;
        private System.Windows.Forms.Label Departmentlabel;
        private System.Windows.Forms.Label Idlabel;
        private System.Windows.Forms.Label Namelabel;
        private System.Windows.Forms.Button Updatebutton;
        private System.Windows.Forms.Button Addbutton;
        private System.Windows.Forms.DataGridView AddadvisordataGridView;
        private System.Windows.Forms.Button Backbutton;
    }
}