﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FinalProject
{
    public partial class MemberManagement : Form
    {
        SqlConnection conn = null;
        int indexRow;
        public MemberManagement()
        {
            InitializeComponent();
        }
        private void Initialize()
        {
            NametextBox.Text = DeptcomboBox.Text =IdtextBox.Text= MaleRadioButton.Text = UsertextBox.Text = "";
            FemaleRadioButton.Text = BloodcomboBox.Text = PhonetextBox.Text = EmailtextBox.Text = TemptextBox.Text = InterstedcomboBox.Text = "";
            //this.LoadMember();
        }
        private void LoadMember()
        {
            try
            {
                string query = "Select * from Add_member";

                DataTable dt = DataAccess.Data(query);
                MemberdataGridView.AutoGenerateColumns = false;
                MemberdataGridView.DataSource = dt;
                MemberdataGridView.Refresh();
                MemberdataGridView.ClearSelection();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void Backbutton_Click(object sender, EventArgs e)
        {
            AdminForm ad10 = new AdminForm();
            ad10.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (NametextBox.Text != null)
            {
                string name = NametextBox.Text;
                string dept = DeptcomboBox.SelectedItem.ToString();
                string gender = "";
                if (MaleRadioButton.Checked)
                    gender = "Male";
                else if (FemaleRadioButton.Checked)
                    gender = "Female";
                DateTime dob = Convert.ToDateTime(PredateTimePicker.Text);
                DateTime join = Convert.ToDateTime(dateTimePicker1.Text);
                string bgrp = BloodcomboBox.SelectedItem.ToString();
                string mob = PhonetextBox.Text;
                string email = EmailtextBox.Text;
                string uname = UsertextBox.Text;
                string pass = TemptextBox.Text;
                string ifield = InterstedcomboBox.SelectedItem.ToString();



                try
                {
                    conn = new SqlConnection(@"Data Source=DESKTOP-Q6H0SBH;Initial Catalog=CMSdbd;Integrated Security=True");
                    conn.Open();
                    string query = "insert into Add_member ([Name],[Dept],[Gender],[DOB],[JoinDate],[BloodGroup],[Phone],[Email],[UserName],[TempPass],[IntFields])" +
                                    "values('" + name + "', '" + dept + "', '" + gender + "', '" + dob + "', '" + join + "', '" + bgrp + "', '" + mob + "', '" + email + "', '" + uname + "', '" + pass + "', '" + ifield + "'); ";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Data Added");
                    this.Initialize();
                    this.LoadMember();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }
            else
            {
                return;
            }
        }

        private void Searchbutton_Click(object sender, EventArgs e)
        {
            if (NametextBox.Text != null)
            {
                string name = NametextBox.Text;
                try
                {
                    conn = new SqlConnection(@"Data Source=DESKTOP-Q6H0SBH;Initial Catalog=CMSdbd;Integrated Security=True");
                    conn.Open();
                    string query = "Select * from Add_member where name='"+name+"'";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Data Found");

                    DataTable dt = DataAccess.Data(query);
                    MemberdataGridView.AutoGenerateColumns = false;
                    MemberdataGridView.DataSource = dt;
                    MemberdataGridView.Refresh();
                    MemberdataGridView.ClearSelection();
                    //this.LoadMember();
                    this.Initialize();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                return;
            }
        }

        private void MemberManagement_Load(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Data Source=DESKTOP-Q6H0SBH;Initial Catalog=CMSdbd;Integrated Security=True";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandText = "select * from Add_member";
            DataTable dt = new DataTable();
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            adp.Fill(dt);
            MemberdataGridView.DataSource = dt;
        }

        private void Newbutton_Click(object sender, EventArgs e)
        {
            this.Initialize();
            this.LoadMember();
        }

        private void Deletebutton_Click(object sender, EventArgs e)
        {
            string id= IdtextBox.Text;
            string name = NametextBox.Text;
            if ((id != "")&&(name != ""))
            {
                string query = "delete from Add_member where (Name='"+name+"' and Id='"+id+"') ";
                DataAccess.Execute(query);
                MessageBox.Show("Data Deleted");
                this.LoadMember();
            }
            else
            {
                MessageBox.Show("Please Enter Name & Id");
            }
        }

        private void Editbutton_Click(object sender, EventArgs e)
        {
            DataGridViewRow newRow = MemberdataGridView.Rows[indexRow];
            newRow.Cells[0].Value = NametextBox.Text.ToString();
            newRow.Cells[2].Value = DeptcomboBox.SelectedItem.ToString();
            //newRow.Cells[3].Value = MaleRadioButton.Checked.ToString();
            //newRow.Cells[3].Value = FemaleRadioButton.Checked.ToString();
            newRow.Cells[4].Value = Convert.ToDateTime(PredateTimePicker.Text);
            newRow.Cells[5].Value = Convert.ToDateTime(dateTimePicker1.Text);
            newRow.Cells[6].Value = BloodcomboBox.SelectedItem.ToString();
            newRow.Cells[7].Value = PhonetextBox.Text.ToString();
            newRow.Cells[8].Value = EmailtextBox.Text.ToString();
            newRow.Cells[9].Value = UsertextBox.Text.ToString();
            newRow.Cells[10].Value = TemptextBox.Text.ToString();
            newRow.Cells[11].Value = InterstedcomboBox.SelectedItem.ToString();
            
            MessageBox.Show("Update Successfully");
            this.Initialize();
            this.LoadMember();
        }

        private void MemberdataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            indexRow = e.RowIndex;
            DataGridViewRow row = MemberdataGridView.Rows[indexRow];
            
            NametextBox.Text = row.Cells[0].Value.ToString();
            IdtextBox.Text= row.Cells[1].Value.ToString();
            DeptcomboBox.Text= row.Cells[2].Value.ToString();
            
            PredateTimePicker.Text= row.Cells[4].Value.ToString();
            dateTimePicker1.Text= row.Cells[5].Value.ToString();
            BloodcomboBox.Text= row.Cells[6].Value.ToString();
            PhonetextBox.Text= row.Cells[7].Value.ToString();
            EmailtextBox.Text= row.Cells[8].Value.ToString();
            UsertextBox.Text= row.Cells[9].Value.ToString();
            TemptextBox.Text= row.Cells[10].Value.ToString();
            InterstedcomboBox.Text= row.Cells[11].Value.ToString();


        }
    }
}