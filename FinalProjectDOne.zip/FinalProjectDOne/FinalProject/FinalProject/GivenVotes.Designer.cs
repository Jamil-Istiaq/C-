﻿namespace FinalProject
{
    partial class GivenVotes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GivenVotes));
            this.panel1 = new System.Windows.Forms.Panel();
            this.Backbutton = new System.Windows.Forms.Button();
            this.VotesLabel = new System.Windows.Forms.Label();
            this.VotesdataGridView = new System.Windows.Forms.DataGridView();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.VotesdataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel1.Controls.Add(this.Backbutton);
            this.panel1.Controls.Add(this.VotesLabel);
            this.panel1.Controls.Add(this.VotesdataGridView);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(841, 452);
            this.panel1.TabIndex = 0;
            // 
            // Backbutton
            // 
            this.Backbutton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Backbutton.BackgroundImage")));
            this.Backbutton.Location = new System.Drawing.Point(756, 12);
            this.Backbutton.Name = "Backbutton";
            this.Backbutton.Size = new System.Drawing.Size(50, 50);
            this.Backbutton.TabIndex = 5;
            this.Backbutton.UseVisualStyleBackColor = true;
            this.Backbutton.Click += new System.EventHandler(this.Backbutton_Click);
            // 
            // VotesLabel
            // 
            this.VotesLabel.AutoSize = true;
            this.VotesLabel.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VotesLabel.ForeColor = System.Drawing.Color.Transparent;
            this.VotesLabel.Location = new System.Drawing.Point(124, 57);
            this.VotesLabel.Name = "VotesLabel";
            this.VotesLabel.Size = new System.Drawing.Size(56, 22);
            this.VotesLabel.TabIndex = 4;
            this.VotesLabel.Text = "Votes";
            // 
            // VotesdataGridView
            // 
            this.VotesdataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.VotesdataGridView.Location = new System.Drawing.Point(128, 93);
            this.VotesdataGridView.Name = "VotesdataGridView";
            this.VotesdataGridView.Size = new System.Drawing.Size(430, 322);
            this.VotesdataGridView.TabIndex = 3;
            // 
            // GivenVotes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(841, 452);
            this.Controls.Add(this.panel1);
            this.Name = "GivenVotes";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GivenVotes";
            this.Load += new System.EventHandler(this.GivenVotes_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.VotesdataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label VotesLabel;
        private System.Windows.Forms.DataGridView VotesdataGridView;
        private System.Windows.Forms.Button Backbutton;
    }
}