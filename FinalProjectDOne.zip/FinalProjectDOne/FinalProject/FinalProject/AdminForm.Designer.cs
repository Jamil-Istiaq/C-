﻿namespace FinalProject
{
    partial class AdminForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminForm));
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.Eventbutton = new System.Windows.Forms.Button();
            this.AdvisorDropDownpanel = new System.Windows.Forms.Panel();
            this.AddNewbutton = new System.Windows.Forms.Button();
            this.AdvisorListbutton = new System.Windows.Forms.Button();
            this.Advisorsbutton = new System.Windows.Forms.Button();
            this.executiveDropdownPanel = new System.Windows.Forms.Panel();
            this.AddExecutivebutton = new System.Windows.Forms.Button();
            this.ExecutiveListButton = new System.Windows.Forms.Button();
            this.EPanelbutton = new System.Windows.Forms.Button();
            this.FilePanel = new System.Windows.Forms.Panel();
            this.Changebutton = new System.Windows.Forms.Button();
            this.AddSocietybutton = new System.Windows.Forms.Button();
            this.AddAdminbutton = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.AdvisorDropDownpanel.SuspendLayout();
            this.executiveDropdownPanel.SuspendLayout();
            this.FilePanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Interval = 15;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Interval = 15;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // timer3
            // 
            this.timer3.Interval = 15;
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.Eventbutton);
            this.panel1.Controls.Add(this.AdvisorDropDownpanel);
            this.panel1.Controls.Add(this.executiveDropdownPanel);
            this.panel1.Controls.Add(this.FilePanel);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(857, 491);
            this.panel1.TabIndex = 0;
            // 
            // button3
            // 
            this.button3.Image = ((System.Drawing.Image)(resources.GetObject("button3.Image")));
            this.button3.Location = new System.Drawing.Point(801, 8);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(50, 40);
            this.button3.TabIndex = 7;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.Location = new System.Drawing.Point(776, 54);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 56);
            this.button2.TabIndex = 6;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Eventbutton
            // 
            this.Eventbutton.Image = ((System.Drawing.Image)(resources.GetObject("Eventbutton.Image")));
            this.Eventbutton.Location = new System.Drawing.Point(667, 56);
            this.Eventbutton.Name = "Eventbutton";
            this.Eventbutton.Size = new System.Drawing.Size(75, 56);
            this.Eventbutton.TabIndex = 5;
            this.Eventbutton.UseVisualStyleBackColor = true;
            this.Eventbutton.Click += new System.EventHandler(this.Eventbutton_Click);
            // 
            // AdvisorDropDownpanel
            // 
            this.AdvisorDropDownpanel.Controls.Add(this.AddNewbutton);
            this.AdvisorDropDownpanel.Controls.Add(this.AdvisorListbutton);
            this.AdvisorDropDownpanel.Controls.Add(this.Advisorsbutton);
            this.AdvisorDropDownpanel.Location = new System.Drawing.Point(442, 56);
            this.AdvisorDropDownpanel.MaximumSize = new System.Drawing.Size(200, 160);
            this.AdvisorDropDownpanel.MinimumSize = new System.Drawing.Size(200, 56);
            this.AdvisorDropDownpanel.Name = "AdvisorDropDownpanel";
            this.AdvisorDropDownpanel.Size = new System.Drawing.Size(200, 56);
            this.AdvisorDropDownpanel.TabIndex = 4;
            // 
            // AddNewbutton
            // 
            this.AddNewbutton.BackColor = System.Drawing.Color.SlateBlue;
            this.AddNewbutton.Dock = System.Windows.Forms.DockStyle.Top;
            this.AddNewbutton.Font = new System.Drawing.Font("Segoe UI Black", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddNewbutton.ForeColor = System.Drawing.Color.Black;
            this.AddNewbutton.Location = new System.Drawing.Point(0, 108);
            this.AddNewbutton.Name = "AddNewbutton";
            this.AddNewbutton.Size = new System.Drawing.Size(200, 52);
            this.AddNewbutton.TabIndex = 2;
            this.AddNewbutton.Text = "Add New";
            this.AddNewbutton.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.AddNewbutton.UseVisualStyleBackColor = false;
            this.AddNewbutton.Click += new System.EventHandler(this.AddNewbutton_Click);
            // 
            // AdvisorListbutton
            // 
            this.AdvisorListbutton.BackColor = System.Drawing.Color.SlateBlue;
            this.AdvisorListbutton.Dock = System.Windows.Forms.DockStyle.Top;
            this.AdvisorListbutton.Font = new System.Drawing.Font("Segoe UI Black", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AdvisorListbutton.ForeColor = System.Drawing.Color.Black;
            this.AdvisorListbutton.Location = new System.Drawing.Point(0, 54);
            this.AdvisorListbutton.Name = "AdvisorListbutton";
            this.AdvisorListbutton.Size = new System.Drawing.Size(200, 54);
            this.AdvisorListbutton.TabIndex = 1;
            this.AdvisorListbutton.Text = "Advisors List";
            this.AdvisorListbutton.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.AdvisorListbutton.UseVisualStyleBackColor = false;
            this.AdvisorListbutton.Click += new System.EventHandler(this.AdvisorListbutton_Click);
            // 
            // Advisorsbutton
            // 
            this.Advisorsbutton.BackColor = System.Drawing.Color.SlateBlue;
            this.Advisorsbutton.Dock = System.Windows.Forms.DockStyle.Top;
            this.Advisorsbutton.Font = new System.Drawing.Font("Segoe UI Black", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Advisorsbutton.ForeColor = System.Drawing.Color.Black;
            this.Advisorsbutton.Image = ((System.Drawing.Image)(resources.GetObject("Advisorsbutton.Image")));
            this.Advisorsbutton.Location = new System.Drawing.Point(0, 0);
            this.Advisorsbutton.Name = "Advisorsbutton";
            this.Advisorsbutton.Size = new System.Drawing.Size(200, 54);
            this.Advisorsbutton.TabIndex = 0;
            this.Advisorsbutton.Text = "Advisors";
            this.Advisorsbutton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Advisorsbutton.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.Advisorsbutton.UseVisualStyleBackColor = false;
            this.Advisorsbutton.Click += new System.EventHandler(this.Advisorsbutton_Click);
            // 
            // executiveDropdownPanel
            // 
            this.executiveDropdownPanel.Controls.Add(this.AddExecutivebutton);
            this.executiveDropdownPanel.Controls.Add(this.ExecutiveListButton);
            this.executiveDropdownPanel.Controls.Add(this.EPanelbutton);
            this.executiveDropdownPanel.Location = new System.Drawing.Point(220, 56);
            this.executiveDropdownPanel.MaximumSize = new System.Drawing.Size(200, 162);
            this.executiveDropdownPanel.MinimumSize = new System.Drawing.Size(200, 56);
            this.executiveDropdownPanel.Name = "executiveDropdownPanel";
            this.executiveDropdownPanel.Size = new System.Drawing.Size(200, 56);
            this.executiveDropdownPanel.TabIndex = 1;
            // 
            // AddExecutivebutton
            // 
            this.AddExecutivebutton.BackColor = System.Drawing.Color.SlateBlue;
            this.AddExecutivebutton.Dock = System.Windows.Forms.DockStyle.Top;
            this.AddExecutivebutton.Font = new System.Drawing.Font("Segoe UI Black", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddExecutivebutton.ForeColor = System.Drawing.Color.Black;
            this.AddExecutivebutton.Location = new System.Drawing.Point(0, 108);
            this.AddExecutivebutton.Name = "AddExecutivebutton";
            this.AddExecutivebutton.Size = new System.Drawing.Size(200, 51);
            this.AddExecutivebutton.TabIndex = 2;
            this.AddExecutivebutton.Text = "Add Executive";
            this.AddExecutivebutton.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.AddExecutivebutton.UseVisualStyleBackColor = false;
            this.AddExecutivebutton.Click += new System.EventHandler(this.AddExecutivebutton_Click);
            // 
            // ExecutiveListButton
            // 
            this.ExecutiveListButton.BackColor = System.Drawing.Color.SlateBlue;
            this.ExecutiveListButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.ExecutiveListButton.Font = new System.Drawing.Font("Segoe UI Black", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExecutiveListButton.ForeColor = System.Drawing.Color.Black;
            this.ExecutiveListButton.Location = new System.Drawing.Point(0, 54);
            this.ExecutiveListButton.Name = "ExecutiveListButton";
            this.ExecutiveListButton.Size = new System.Drawing.Size(200, 54);
            this.ExecutiveListButton.TabIndex = 1;
            this.ExecutiveListButton.Text = "Executive List";
            this.ExecutiveListButton.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.ExecutiveListButton.UseVisualStyleBackColor = false;
            this.ExecutiveListButton.Click += new System.EventHandler(this.ExecutiveListButton_Click);
            // 
            // EPanelbutton
            // 
            this.EPanelbutton.BackColor = System.Drawing.Color.SlateBlue;
            this.EPanelbutton.Dock = System.Windows.Forms.DockStyle.Top;
            this.EPanelbutton.Font = new System.Drawing.Font("Segoe UI Black", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EPanelbutton.ForeColor = System.Drawing.Color.Black;
            this.EPanelbutton.Image = ((System.Drawing.Image)(resources.GetObject("EPanelbutton.Image")));
            this.EPanelbutton.Location = new System.Drawing.Point(0, 0);
            this.EPanelbutton.Name = "EPanelbutton";
            this.EPanelbutton.Size = new System.Drawing.Size(200, 54);
            this.EPanelbutton.TabIndex = 0;
            this.EPanelbutton.Text = "Executive Panel";
            this.EPanelbutton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.EPanelbutton.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.EPanelbutton.UseVisualStyleBackColor = false;
            this.EPanelbutton.Click += new System.EventHandler(this.EPanelbutton_Click);
            // 
            // FilePanel
            // 
            this.FilePanel.Controls.Add(this.Changebutton);
            this.FilePanel.Controls.Add(this.AddSocietybutton);
            this.FilePanel.Controls.Add(this.AddAdminbutton);
            this.FilePanel.Controls.Add(this.button1);
            this.FilePanel.Location = new System.Drawing.Point(3, 54);
            this.FilePanel.MaximumSize = new System.Drawing.Size(200, 220);
            this.FilePanel.MinimumSize = new System.Drawing.Size(200, 56);
            this.FilePanel.Name = "FilePanel";
            this.FilePanel.Size = new System.Drawing.Size(200, 56);
            this.FilePanel.TabIndex = 0;
            // 
            // Changebutton
            // 
            this.Changebutton.BackColor = System.Drawing.Color.SlateBlue;
            this.Changebutton.Dock = System.Windows.Forms.DockStyle.Top;
            this.Changebutton.Font = new System.Drawing.Font("Segoe UI Black", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Changebutton.ForeColor = System.Drawing.Color.Black;
            this.Changebutton.Location = new System.Drawing.Point(0, 162);
            this.Changebutton.Name = "Changebutton";
            this.Changebutton.Size = new System.Drawing.Size(200, 54);
            this.Changebutton.TabIndex = 3;
            this.Changebutton.Text = "Change Password";
            this.Changebutton.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.Changebutton.UseVisualStyleBackColor = false;
            this.Changebutton.Click += new System.EventHandler(this.Changebutton_Click);
            // 
            // AddSocietybutton
            // 
            this.AddSocietybutton.BackColor = System.Drawing.Color.SlateBlue;
            this.AddSocietybutton.Dock = System.Windows.Forms.DockStyle.Top;
            this.AddSocietybutton.Font = new System.Drawing.Font("Segoe UI Black", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddSocietybutton.ForeColor = System.Drawing.Color.Black;
            this.AddSocietybutton.Location = new System.Drawing.Point(0, 108);
            this.AddSocietybutton.Name = "AddSocietybutton";
            this.AddSocietybutton.Size = new System.Drawing.Size(200, 54);
            this.AddSocietybutton.TabIndex = 2;
            this.AddSocietybutton.Text = "Add Society";
            this.AddSocietybutton.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.AddSocietybutton.UseVisualStyleBackColor = false;
            this.AddSocietybutton.Click += new System.EventHandler(this.AddSocietybutton_Click);
            // 
            // AddAdminbutton
            // 
            this.AddAdminbutton.BackColor = System.Drawing.Color.SlateBlue;
            this.AddAdminbutton.Dock = System.Windows.Forms.DockStyle.Top;
            this.AddAdminbutton.Font = new System.Drawing.Font("Segoe UI Black", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddAdminbutton.ForeColor = System.Drawing.Color.Black;
            this.AddAdminbutton.Location = new System.Drawing.Point(0, 54);
            this.AddAdminbutton.Name = "AddAdminbutton";
            this.AddAdminbutton.Size = new System.Drawing.Size(200, 54);
            this.AddAdminbutton.TabIndex = 1;
            this.AddAdminbutton.Text = "Add Admin";
            this.AddAdminbutton.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.AddAdminbutton.UseVisualStyleBackColor = false;
            this.AddAdminbutton.Click += new System.EventHandler(this.AddAdminbutton_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.SlateBlue;
            this.button1.Dock = System.Windows.Forms.DockStyle.Top;
            this.button1.Font = new System.Drawing.Font("Segoe UI Black", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(0, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(200, 54);
            this.button1.TabIndex = 0;
            this.button1.Text = "File";
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // AdminForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(857, 491);
            this.Controls.Add(this.panel1);
            this.Name = "AdminForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AdminForm";
            this.Load += new System.EventHandler(this.AdminForm_Load);
            this.panel1.ResumeLayout(false);
            this.AdvisorDropDownpanel.ResumeLayout(false);
            this.executiveDropdownPanel.ResumeLayout(false);
            this.FilePanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel FilePanel;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Panel AdvisorDropDownpanel;
        private System.Windows.Forms.Button AddNewbutton;
        private System.Windows.Forms.Button AdvisorListbutton;
        private System.Windows.Forms.Button Advisorsbutton;
        private System.Windows.Forms.Panel executiveDropdownPanel;
        private System.Windows.Forms.Button AddExecutivebutton;
        private System.Windows.Forms.Button ExecutiveListButton;
        private System.Windows.Forms.Button EPanelbutton;
        private System.Windows.Forms.Button Changebutton;
        private System.Windows.Forms.Button AddSocietybutton;
        private System.Windows.Forms.Button AddAdminbutton;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button Eventbutton;
    }
}