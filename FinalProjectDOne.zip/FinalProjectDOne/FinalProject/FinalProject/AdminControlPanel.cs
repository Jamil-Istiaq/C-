﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FinalProject
{
    public partial class AdminControlPanel : UserControl
    {
        public AdminControlPanel()
        {
            InitializeComponent();
        }

        private void Initialize()
        {
            AusertextBox.Text=APasstextBox.Text = "";
            
        }
        private void AloginButton_Click(object sender, EventArgs e)
        {
            
            SqlConnection sqlcon = new SqlConnection(@"Data Source=DESKTOP-Q6H0SBH;Initial Catalog=CMSdbd;Integrated Security=True");

            string query = "select UserName, Temp_pass  from Add_admin where UserName = '" + AusertextBox.Text + "' and Temp_pass like '" + APasstextBox.Text + "'";
            SqlDataAdapter sda = new SqlDataAdapter(query, sqlcon);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            if (dt.Rows.Count == 1)
            {
                AdminForm admn = new AdminForm();
                this.Hide();
                admn.Show();
                this.Initialize();

            }
            else
            {
                MessageBox.Show("Please try again");
            }

        }
    }
}
