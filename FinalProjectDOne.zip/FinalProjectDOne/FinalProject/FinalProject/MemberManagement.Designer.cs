﻿namespace FinalProject
{
    partial class MemberManagement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MemberManagement));
            this.panel1 = new System.Windows.Forms.Panel();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.MemberdataGridView = new System.Windows.Forms.DataGridView();
            this.button4 = new System.Windows.Forms.Button();
            this.FemaleRadioButton = new System.Windows.Forms.RadioButton();
            this.MaleRadioButton = new System.Windows.Forms.RadioButton();
            this.PredateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.InterstedcomboBox = new System.Windows.Forms.ComboBox();
            this.BloodcomboBox = new System.Windows.Forms.ComboBox();
            this.DeptcomboBox = new System.Windows.Forms.ComboBox();
            this.TemptextBox = new System.Windows.Forms.TextBox();
            this.UsertextBox = new System.Windows.Forms.TextBox();
            this.EmailtextBox = new System.Windows.Forms.TextBox();
            this.PhonetextBox = new System.Windows.Forms.TextBox();
            this.IdtextBox = new System.Windows.Forms.TextBox();
            this.NametextBox = new System.Windows.Forms.TextBox();
            this.Interstedlabel = new System.Windows.Forms.Label();
            this.Templabel = new System.Windows.Forms.Label();
            this.UserNameLabel = new System.Windows.Forms.Label();
            this.Emaillabel = new System.Windows.Forms.Label();
            this.PhoneLabel = new System.Windows.Forms.Label();
            this.DOBlabel = new System.Windows.Forms.Label();
            this.GenderLabel = new System.Windows.Forms.Label();
            this.BloodGrouplabel = new System.Windows.Forms.Label();
            this.Departmentlabel = new System.Windows.Forms.Label();
            this.IdLabel = new System.Windows.Forms.Label();
            this.Namelabel = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Backbutton = new System.Windows.Forms.Button();
            this.Editbutton = new System.Windows.Forms.Button();
            this.Searchbutton = new System.Windows.Forms.Button();
            this.Deletebutton = new System.Windows.Forms.Button();
            this.Newbutton = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MemberdataGridView)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel1.Controls.Add(this.dateTimePicker1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.MemberdataGridView);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.FemaleRadioButton);
            this.panel1.Controls.Add(this.MaleRadioButton);
            this.panel1.Controls.Add(this.PredateTimePicker);
            this.panel1.Controls.Add(this.InterstedcomboBox);
            this.panel1.Controls.Add(this.BloodcomboBox);
            this.panel1.Controls.Add(this.DeptcomboBox);
            this.panel1.Controls.Add(this.TemptextBox);
            this.panel1.Controls.Add(this.UsertextBox);
            this.panel1.Controls.Add(this.EmailtextBox);
            this.panel1.Controls.Add(this.PhonetextBox);
            this.panel1.Controls.Add(this.IdtextBox);
            this.panel1.Controls.Add(this.NametextBox);
            this.panel1.Controls.Add(this.Interstedlabel);
            this.panel1.Controls.Add(this.Templabel);
            this.panel1.Controls.Add(this.UserNameLabel);
            this.panel1.Controls.Add(this.Emaillabel);
            this.panel1.Controls.Add(this.PhoneLabel);
            this.panel1.Controls.Add(this.DOBlabel);
            this.panel1.Controls.Add(this.GenderLabel);
            this.panel1.Controls.Add(this.BloodGrouplabel);
            this.panel1.Controls.Add(this.Departmentlabel);
            this.panel1.Controls.Add(this.IdLabel);
            this.panel1.Controls.Add(this.Namelabel);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1067, 576);
            this.panel1.TabIndex = 0;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(214, 257);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(196, 20);
            this.dateTimePicker1.TabIndex = 35;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(24, 260);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 17);
            this.label1.TabIndex = 34;
            this.label1.Text = "Join Date ";
            // 
            // MemberdataGridView
            // 
            this.MemberdataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.MemberdataGridView.Location = new System.Drawing.Point(510, 74);
            this.MemberdataGridView.Name = "MemberdataGridView";
            this.MemberdataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.MemberdataGridView.Size = new System.Drawing.Size(497, 453);
            this.MemberdataGridView.TabIndex = 33;
            this.MemberdataGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.MemberdataGridView_CellClick);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.DarkSlateGray;
            this.button4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(246, 523);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(106, 30);
            this.button4.TabIndex = 32;
            this.button4.Text = "Submit";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // FemaleRadioButton
            // 
            this.FemaleRadioButton.AutoSize = true;
            this.FemaleRadioButton.Location = new System.Drawing.Point(313, 189);
            this.FemaleRadioButton.Name = "FemaleRadioButton";
            this.FemaleRadioButton.Size = new System.Drawing.Size(59, 17);
            this.FemaleRadioButton.TabIndex = 31;
            this.FemaleRadioButton.TabStop = true;
            this.FemaleRadioButton.Text = "Female";
            this.FemaleRadioButton.UseVisualStyleBackColor = true;
            // 
            // MaleRadioButton
            // 
            this.MaleRadioButton.AutoSize = true;
            this.MaleRadioButton.Location = new System.Drawing.Point(214, 189);
            this.MaleRadioButton.Name = "MaleRadioButton";
            this.MaleRadioButton.Size = new System.Drawing.Size(48, 17);
            this.MaleRadioButton.TabIndex = 30;
            this.MaleRadioButton.TabStop = true;
            this.MaleRadioButton.Text = "Male";
            this.MaleRadioButton.UseVisualStyleBackColor = true;
            // 
            // PredateTimePicker
            // 
            this.PredateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.PredateTimePicker.Location = new System.Drawing.Point(214, 221);
            this.PredateTimePicker.Name = "PredateTimePicker";
            this.PredateTimePicker.Size = new System.Drawing.Size(196, 20);
            this.PredateTimePicker.TabIndex = 27;
            // 
            // InterstedcomboBox
            // 
            this.InterstedcomboBox.FormattingEnabled = true;
            this.InterstedcomboBox.Items.AddRange(new object[] {
            "Graphics Design",
            "Web Development",
            "Event Management",
            "Research and methodology",
            "Media",
            "Photography"});
            this.InterstedcomboBox.Location = new System.Drawing.Point(214, 478);
            this.InterstedcomboBox.Name = "InterstedcomboBox";
            this.InterstedcomboBox.Size = new System.Drawing.Size(196, 21);
            this.InterstedcomboBox.TabIndex = 26;
            // 
            // BloodcomboBox
            // 
            this.BloodcomboBox.FormattingEnabled = true;
            this.BloodcomboBox.Items.AddRange(new object[] {
            "A+",
            "B+",
            "AB+",
            "O+",
            "O-",
            "AB-",
            "B-",
            "A-"});
            this.BloodcomboBox.Location = new System.Drawing.Point(214, 292);
            this.BloodcomboBox.Name = "BloodcomboBox";
            this.BloodcomboBox.Size = new System.Drawing.Size(196, 21);
            this.BloodcomboBox.TabIndex = 25;
            // 
            // DeptcomboBox
            // 
            this.DeptcomboBox.FormattingEnabled = true;
            this.DeptcomboBox.Items.AddRange(new object[] {
            "CSE",
            "EEE",
            "CoE",
            "BBA",
            "LLB",
            "SE",
            "ENG",
            "LAW",
            "MMC",
            "IPE"});
            this.DeptcomboBox.Location = new System.Drawing.Point(214, 151);
            this.DeptcomboBox.Name = "DeptcomboBox";
            this.DeptcomboBox.Size = new System.Drawing.Size(196, 21);
            this.DeptcomboBox.TabIndex = 24;
            // 
            // TemptextBox
            // 
            this.TemptextBox.Location = new System.Drawing.Point(214, 439);
            this.TemptextBox.Name = "TemptextBox";
            this.TemptextBox.Size = new System.Drawing.Size(196, 20);
            this.TemptextBox.TabIndex = 23;
            // 
            // UsertextBox
            // 
            this.UsertextBox.Location = new System.Drawing.Point(214, 403);
            this.UsertextBox.Name = "UsertextBox";
            this.UsertextBox.Size = new System.Drawing.Size(196, 20);
            this.UsertextBox.TabIndex = 22;
            // 
            // EmailtextBox
            // 
            this.EmailtextBox.Location = new System.Drawing.Point(214, 367);
            this.EmailtextBox.Name = "EmailtextBox";
            this.EmailtextBox.Size = new System.Drawing.Size(196, 20);
            this.EmailtextBox.TabIndex = 21;
            // 
            // PhonetextBox
            // 
            this.PhonetextBox.Location = new System.Drawing.Point(214, 331);
            this.PhonetextBox.Name = "PhonetextBox";
            this.PhonetextBox.Size = new System.Drawing.Size(196, 20);
            this.PhonetextBox.TabIndex = 20;
            // 
            // IdtextBox
            // 
            this.IdtextBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.IdtextBox.Location = new System.Drawing.Point(214, 116);
            this.IdtextBox.Name = "IdtextBox";
            this.IdtextBox.Size = new System.Drawing.Size(196, 20);
            this.IdtextBox.TabIndex = 19;
            // 
            // NametextBox
            // 
            this.NametextBox.Location = new System.Drawing.Point(214, 80);
            this.NametextBox.Name = "NametextBox";
            this.NametextBox.Size = new System.Drawing.Size(196, 20);
            this.NametextBox.TabIndex = 18;
            // 
            // Interstedlabel
            // 
            this.Interstedlabel.AutoSize = true;
            this.Interstedlabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.Interstedlabel.ForeColor = System.Drawing.Color.Transparent;
            this.Interstedlabel.Location = new System.Drawing.Point(24, 478);
            this.Interstedlabel.Name = "Interstedlabel";
            this.Interstedlabel.Size = new System.Drawing.Size(97, 17);
            this.Interstedlabel.TabIndex = 17;
            this.Interstedlabel.Text = "Intersted Field";
            // 
            // Templabel
            // 
            this.Templabel.AutoSize = true;
            this.Templabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.Templabel.ForeColor = System.Drawing.Color.Transparent;
            this.Templabel.Location = new System.Drawing.Point(24, 442);
            this.Templabel.Name = "Templabel";
            this.Templabel.Size = new System.Drawing.Size(137, 17);
            this.Templabel.TabIndex = 16;
            this.Templabel.Text = "Temporary Password";
            // 
            // UserNameLabel
            // 
            this.UserNameLabel.AutoSize = true;
            this.UserNameLabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.UserNameLabel.ForeColor = System.Drawing.Color.Transparent;
            this.UserNameLabel.Location = new System.Drawing.Point(24, 403);
            this.UserNameLabel.Name = "UserNameLabel";
            this.UserNameLabel.Size = new System.Drawing.Size(75, 17);
            this.UserNameLabel.TabIndex = 15;
            this.UserNameLabel.Text = "User Name";
            // 
            // Emaillabel
            // 
            this.Emaillabel.AutoSize = true;
            this.Emaillabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.Emaillabel.ForeColor = System.Drawing.Color.Transparent;
            this.Emaillabel.Location = new System.Drawing.Point(24, 370);
            this.Emaillabel.Name = "Emaillabel";
            this.Emaillabel.Size = new System.Drawing.Size(42, 17);
            this.Emaillabel.TabIndex = 14;
            this.Emaillabel.Text = "Email";
            // 
            // PhoneLabel
            // 
            this.PhoneLabel.AutoSize = true;
            this.PhoneLabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.PhoneLabel.ForeColor = System.Drawing.Color.Transparent;
            this.PhoneLabel.Location = new System.Drawing.Point(24, 334);
            this.PhoneLabel.Name = "PhoneLabel";
            this.PhoneLabel.Size = new System.Drawing.Size(69, 17);
            this.PhoneLabel.TabIndex = 13;
            this.PhoneLabel.Text = "Phone No";
            // 
            // DOBlabel
            // 
            this.DOBlabel.AutoSize = true;
            this.DOBlabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.DOBlabel.ForeColor = System.Drawing.Color.Transparent;
            this.DOBlabel.Location = new System.Drawing.Point(24, 224);
            this.DOBlabel.Name = "DOBlabel";
            this.DOBlabel.Size = new System.Drawing.Size(88, 17);
            this.DOBlabel.TabIndex = 12;
            this.DOBlabel.Text = "Date of Birth";
            // 
            // GenderLabel
            // 
            this.GenderLabel.AutoSize = true;
            this.GenderLabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.GenderLabel.ForeColor = System.Drawing.Color.Transparent;
            this.GenderLabel.Location = new System.Drawing.Point(24, 189);
            this.GenderLabel.Name = "GenderLabel";
            this.GenderLabel.Size = new System.Drawing.Size(52, 17);
            this.GenderLabel.TabIndex = 11;
            this.GenderLabel.Text = "Gender";
            // 
            // BloodGrouplabel
            // 
            this.BloodGrouplabel.AutoSize = true;
            this.BloodGrouplabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.BloodGrouplabel.ForeColor = System.Drawing.Color.Transparent;
            this.BloodGrouplabel.Location = new System.Drawing.Point(24, 296);
            this.BloodGrouplabel.Name = "BloodGrouplabel";
            this.BloodGrouplabel.Size = new System.Drawing.Size(86, 17);
            this.BloodGrouplabel.TabIndex = 10;
            this.BloodGrouplabel.Text = "Blood Group";
            // 
            // Departmentlabel
            // 
            this.Departmentlabel.AutoSize = true;
            this.Departmentlabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.Departmentlabel.ForeColor = System.Drawing.Color.Transparent;
            this.Departmentlabel.Location = new System.Drawing.Point(24, 151);
            this.Departmentlabel.Name = "Departmentlabel";
            this.Departmentlabel.Size = new System.Drawing.Size(82, 17);
            this.Departmentlabel.TabIndex = 9;
            this.Departmentlabel.Text = "Department\r\n";
            // 
            // IdLabel
            // 
            this.IdLabel.AutoSize = true;
            this.IdLabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.IdLabel.ForeColor = System.Drawing.Color.Transparent;
            this.IdLabel.Location = new System.Drawing.Point(24, 116);
            this.IdLabel.Name = "IdLabel";
            this.IdLabel.Size = new System.Drawing.Size(20, 17);
            this.IdLabel.TabIndex = 8;
            this.IdLabel.Text = "Id";
            // 
            // Namelabel
            // 
            this.Namelabel.AutoSize = true;
            this.Namelabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.Namelabel.ForeColor = System.Drawing.Color.Transparent;
            this.Namelabel.Location = new System.Drawing.Point(24, 80);
            this.Namelabel.Name = "Namelabel";
            this.Namelabel.Size = new System.Drawing.Size(44, 17);
            this.Namelabel.TabIndex = 7;
            this.Namelabel.Text = "Name";
            // 
            // panel2
            // 
            this.panel2.AutoScroll = true;
            this.panel2.Controls.Add(this.Backbutton);
            this.panel2.Controls.Add(this.Editbutton);
            this.panel2.Controls.Add(this.Searchbutton);
            this.panel2.Controls.Add(this.Deletebutton);
            this.panel2.Controls.Add(this.Newbutton);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1067, 68);
            this.panel2.TabIndex = 0;
            // 
            // Backbutton
            // 
            this.Backbutton.Image = ((System.Drawing.Image)(resources.GetObject("Backbutton.Image")));
            this.Backbutton.Location = new System.Drawing.Point(957, 18);
            this.Backbutton.Name = "Backbutton";
            this.Backbutton.Size = new System.Drawing.Size(50, 40);
            this.Backbutton.TabIndex = 23;
            this.Backbutton.UseVisualStyleBackColor = true;
            this.Backbutton.Click += new System.EventHandler(this.Backbutton_Click);
            // 
            // Editbutton
            // 
            this.Editbutton.BackColor = System.Drawing.Color.DarkSlateGray;
            this.Editbutton.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Editbutton.ForeColor = System.Drawing.Color.White;
            this.Editbutton.Location = new System.Drawing.Point(216, 23);
            this.Editbutton.Name = "Editbutton";
            this.Editbutton.Size = new System.Drawing.Size(106, 30);
            this.Editbutton.TabIndex = 22;
            this.Editbutton.Text = "Edit";
            this.Editbutton.UseVisualStyleBackColor = false;
            this.Editbutton.Click += new System.EventHandler(this.Editbutton_Click);
            // 
            // Searchbutton
            // 
            this.Searchbutton.BackColor = System.Drawing.Color.DarkSlateGray;
            this.Searchbutton.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Searchbutton.ForeColor = System.Drawing.Color.White;
            this.Searchbutton.Location = new System.Drawing.Point(385, 23);
            this.Searchbutton.Name = "Searchbutton";
            this.Searchbutton.Size = new System.Drawing.Size(106, 30);
            this.Searchbutton.TabIndex = 21;
            this.Searchbutton.Text = "Search";
            this.Searchbutton.UseVisualStyleBackColor = false;
            this.Searchbutton.Click += new System.EventHandler(this.Searchbutton_Click);
            // 
            // Deletebutton
            // 
            this.Deletebutton.BackColor = System.Drawing.Color.DarkSlateGray;
            this.Deletebutton.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Deletebutton.ForeColor = System.Drawing.Color.White;
            this.Deletebutton.Location = new System.Drawing.Point(549, 23);
            this.Deletebutton.Name = "Deletebutton";
            this.Deletebutton.Size = new System.Drawing.Size(106, 30);
            this.Deletebutton.TabIndex = 20;
            this.Deletebutton.Text = "Delete";
            this.Deletebutton.UseVisualStyleBackColor = false;
            this.Deletebutton.Click += new System.EventHandler(this.Deletebutton_Click);
            // 
            // Newbutton
            // 
            this.Newbutton.BackColor = System.Drawing.Color.DarkSlateGray;
            this.Newbutton.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Newbutton.ForeColor = System.Drawing.Color.White;
            this.Newbutton.Location = new System.Drawing.Point(66, 23);
            this.Newbutton.Name = "Newbutton";
            this.Newbutton.Size = new System.Drawing.Size(106, 30);
            this.Newbutton.TabIndex = 19;
            this.Newbutton.Text = "New";
            this.Newbutton.UseVisualStyleBackColor = false;
            this.Newbutton.Click += new System.EventHandler(this.Newbutton_Click);
            // 
            // MemberManagement
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1067, 576);
            this.Controls.Add(this.panel1);
            this.Name = "MemberManagement";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MemberManagement";
            this.Load += new System.EventHandler(this.MemberManagement_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MemberdataGridView)).EndInit();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DateTimePicker PredateTimePicker;
        private System.Windows.Forms.ComboBox InterstedcomboBox;
        private System.Windows.Forms.ComboBox BloodcomboBox;
        private System.Windows.Forms.ComboBox DeptcomboBox;
        private System.Windows.Forms.TextBox TemptextBox;
        private System.Windows.Forms.TextBox UsertextBox;
        private System.Windows.Forms.TextBox EmailtextBox;
        private System.Windows.Forms.TextBox PhonetextBox;
        private System.Windows.Forms.TextBox IdtextBox;
        private System.Windows.Forms.TextBox NametextBox;
        private System.Windows.Forms.Label Interstedlabel;
        private System.Windows.Forms.Label Templabel;
        private System.Windows.Forms.Label UserNameLabel;
        private System.Windows.Forms.Label Emaillabel;
        private System.Windows.Forms.Label PhoneLabel;
        private System.Windows.Forms.Label DOBlabel;
        private System.Windows.Forms.Label GenderLabel;
        private System.Windows.Forms.Label BloodGrouplabel;
        private System.Windows.Forms.Label Departmentlabel;
        private System.Windows.Forms.Label IdLabel;
        private System.Windows.Forms.Label Namelabel;
        private System.Windows.Forms.RadioButton FemaleRadioButton;
        private System.Windows.Forms.RadioButton MaleRadioButton;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button Editbutton;
        private System.Windows.Forms.Button Searchbutton;
        private System.Windows.Forms.Button Deletebutton;
        private System.Windows.Forms.Button Newbutton;
        private System.Windows.Forms.DataGridView MemberdataGridView;
        private System.Windows.Forms.Button Backbutton;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label1;
    }
}