﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FinalProject
{
    public partial class EventsAV : Form
    {
        SqlConnection conn = null;
        public EventsAV()
        {
            InitializeComponent();
        }
       
        private void Initialize()
        {
            EventNametextBox.Text = InterstedcomboBox.Text = ExperiencerichTextBox.Text = "";
        }

        private void Backbutton_Click(object sender, EventArgs e)
        {
            MemberFrom mf4 = new MemberFrom();
            mf4.Show();
            this.Hide();
        }

        private void Applybutton_Click(object sender, EventArgs e)
        {
            if ((EventNametextBox.Text != null) && (ExperiencerichTextBox.Text != null))
            {
                string mname = textBox1.Text;
                string ename = EventNametextBox.Text;
                string fld = InterstedcomboBox.SelectedItem.ToString();
                string exp = ExperiencerichTextBox.Text;

                try
                {
                    conn = new SqlConnection(@"Data Source=DESKTOP-Q6H0SBH;Initial Catalog=CMSdbd;Integrated Security=True");
                    conn.Open();

                    string query = "insert into Apply_volunteer ([MbrName],[Ename],[Sector],[Exp]) values('"+mname+"','"+ename+"','"+fld+"','"+exp+"')";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Added Data");
                    this.Initialize();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }
            else
            {
                return;
            }
        }

        private void EventsAV_Load(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Data Source=DESKTOP-Q6H0SBH;Initial Catalog=CMSdbd;Integrated Security=True";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandText = "select EventName,Category,EvntDate1 from Add_event";
            DataTable dt = new DataTable();
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            adp.Fill(dt);
            EventsdataGridView.DataSource = dt;
        }
    }
}
