﻿namespace FinalProject
{
    partial class AddSociety
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddSociety));
            this.SocietyNamelabel = new System.Windows.Forms.Label();
            this.MemberCapacityLabel = new System.Windows.Forms.Label();
            this.SocietyTypeLabel = new System.Windows.Forms.Label();
            this.SocietyNameTextBox = new System.Windows.Forms.TextBox();
            this.MemberCapacitytextBox = new System.Windows.Forms.TextBox();
            this.SocietyTypeComboBox = new System.Windows.Forms.ComboBox();
            this.Submitbutton = new System.Windows.Forms.Button();
            this.Deletebutton = new System.Windows.Forms.Button();
            this.Backbutton = new System.Windows.Forms.Button();
            this.societyGridView = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.societyGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // SocietyNamelabel
            // 
            this.SocietyNamelabel.AutoSize = true;
            this.SocietyNamelabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SocietyNamelabel.ForeColor = System.Drawing.Color.White;
            this.SocietyNamelabel.Location = new System.Drawing.Point(22, 86);
            this.SocietyNamelabel.Name = "SocietyNamelabel";
            this.SocietyNamelabel.Size = new System.Drawing.Size(92, 17);
            this.SocietyNamelabel.TabIndex = 0;
            this.SocietyNamelabel.Text = "Society Name";
            // 
            // MemberCapacityLabel
            // 
            this.MemberCapacityLabel.AutoSize = true;
            this.MemberCapacityLabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MemberCapacityLabel.ForeColor = System.Drawing.Color.White;
            this.MemberCapacityLabel.Location = new System.Drawing.Point(22, 148);
            this.MemberCapacityLabel.Name = "MemberCapacityLabel";
            this.MemberCapacityLabel.Size = new System.Drawing.Size(115, 17);
            this.MemberCapacityLabel.TabIndex = 1;
            this.MemberCapacityLabel.Text = "Member Capacity";
            // 
            // SocietyTypeLabel
            // 
            this.SocietyTypeLabel.AutoSize = true;
            this.SocietyTypeLabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SocietyTypeLabel.ForeColor = System.Drawing.Color.White;
            this.SocietyTypeLabel.Location = new System.Drawing.Point(22, 210);
            this.SocietyTypeLabel.Name = "SocietyTypeLabel";
            this.SocietyTypeLabel.Size = new System.Drawing.Size(85, 17);
            this.SocietyTypeLabel.TabIndex = 2;
            this.SocietyTypeLabel.Text = "Society Type";
            // 
            // SocietyNameTextBox
            // 
            this.SocietyNameTextBox.Location = new System.Drawing.Point(221, 86);
            this.SocietyNameTextBox.Name = "SocietyNameTextBox";
            this.SocietyNameTextBox.Size = new System.Drawing.Size(171, 20);
            this.SocietyNameTextBox.TabIndex = 3;
            // 
            // MemberCapacitytextBox
            // 
            this.MemberCapacitytextBox.Location = new System.Drawing.Point(221, 145);
            this.MemberCapacitytextBox.Name = "MemberCapacitytextBox";
            this.MemberCapacitytextBox.Size = new System.Drawing.Size(171, 20);
            this.MemberCapacitytextBox.TabIndex = 4;
            // 
            // SocietyTypeComboBox
            // 
            this.SocietyTypeComboBox.FormattingEnabled = true;
            this.SocietyTypeComboBox.Items.AddRange(new object[] {
            "Firefox",
            "Gaming",
            "Art",
            "Graphics",
            "Robotic"});
            this.SocietyTypeComboBox.Location = new System.Drawing.Point(221, 210);
            this.SocietyTypeComboBox.Name = "SocietyTypeComboBox";
            this.SocietyTypeComboBox.Size = new System.Drawing.Size(171, 21);
            this.SocietyTypeComboBox.TabIndex = 5;
            // 
            // Submitbutton
            // 
            this.Submitbutton.BackColor = System.Drawing.Color.DarkSlateGray;
            this.Submitbutton.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Submitbutton.ForeColor = System.Drawing.Color.White;
            this.Submitbutton.Location = new System.Drawing.Point(62, 314);
            this.Submitbutton.Name = "Submitbutton";
            this.Submitbutton.Size = new System.Drawing.Size(98, 30);
            this.Submitbutton.TabIndex = 17;
            this.Submitbutton.Text = "Submit";
            this.Submitbutton.UseVisualStyleBackColor = false;
            this.Submitbutton.Click += new System.EventHandler(this.Submitbutton_Click);
            // 
            // Deletebutton
            // 
            this.Deletebutton.BackColor = System.Drawing.Color.DarkSlateGray;
            this.Deletebutton.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Deletebutton.ForeColor = System.Drawing.Color.White;
            this.Deletebutton.Location = new System.Drawing.Point(236, 314);
            this.Deletebutton.Name = "Deletebutton";
            this.Deletebutton.Size = new System.Drawing.Size(98, 30);
            this.Deletebutton.TabIndex = 18;
            this.Deletebutton.Text = "Delete";
            this.Deletebutton.UseVisualStyleBackColor = false;
            this.Deletebutton.Click += new System.EventHandler(this.Deletebutton_Click);
            // 
            // Backbutton
            // 
            this.Backbutton.Image = ((System.Drawing.Image)(resources.GetObject("Backbutton.Image")));
            this.Backbutton.Location = new System.Drawing.Point(741, 12);
            this.Backbutton.Name = "Backbutton";
            this.Backbutton.Size = new System.Drawing.Size(50, 40);
            this.Backbutton.TabIndex = 19;
            this.Backbutton.UseVisualStyleBackColor = true;
            this.Backbutton.Click += new System.EventHandler(this.Backbutton_Click);
            // 
            // societyGridView
            // 
            this.societyGridView.AllowUserToAddRows = false;
            this.societyGridView.AllowUserToDeleteRows = false;
            this.societyGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.societyGridView.Location = new System.Drawing.Point(456, 86);
            this.societyGridView.Name = "societyGridView";
            this.societyGridView.ReadOnly = true;
            this.societyGridView.Size = new System.Drawing.Size(345, 258);
            this.societyGridView.TabIndex = 20;
            // 
            // AddSociety
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(841, 452);
            this.Controls.Add(this.societyGridView);
            this.Controls.Add(this.Backbutton);
            this.Controls.Add(this.Deletebutton);
            this.Controls.Add(this.Submitbutton);
            this.Controls.Add(this.SocietyTypeComboBox);
            this.Controls.Add(this.MemberCapacitytextBox);
            this.Controls.Add(this.SocietyNameTextBox);
            this.Controls.Add(this.SocietyTypeLabel);
            this.Controls.Add(this.MemberCapacityLabel);
            this.Controls.Add(this.SocietyNamelabel);
            this.Name = "AddSociety";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AddSociety";
            this.Load += new System.EventHandler(this.AddSociety_Load);
            ((System.ComponentModel.ISupportInitialize)(this.societyGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label SocietyNamelabel;
        private System.Windows.Forms.Label MemberCapacityLabel;
        private System.Windows.Forms.Label SocietyTypeLabel;
        private System.Windows.Forms.TextBox SocietyNameTextBox;
        private System.Windows.Forms.TextBox MemberCapacitytextBox;
        private System.Windows.Forms.ComboBox SocietyTypeComboBox;
        private System.Windows.Forms.Button Submitbutton;
        private System.Windows.Forms.Button Deletebutton;
        private System.Windows.Forms.Button Backbutton;
        private System.Windows.Forms.DataGridView societyGridView;
    }
}