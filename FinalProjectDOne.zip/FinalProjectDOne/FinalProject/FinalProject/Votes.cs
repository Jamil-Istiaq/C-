﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FinalProject
{
    public partial class Votes : Form
    {
        SqlConnection conn = null;
        public Votes()
        {
            InitializeComponent();
        }
        private void Initialize()
        {
            CandidatetextBox.Text = CommentRichTextBox.Text =PositioncomboBox.Text = "";

        }

        private void Backbutton_Click(object sender, EventArgs e)
        {
            MemberFrom mf6 = new MemberFrom();
            mf6.Show();
            this.Hide();
        }

        private void Votebutton_Click(object sender, EventArgs e)
        {
            if ((CandidatetextBox.Text!=null) && (CommentRichTextBox.Text != null))
            {
                string name = CandidatetextBox.Text;
                string post = PositioncomboBox.SelectedItem.ToString();
                string cmnt= CommentRichTextBox.Text;


                try
                {
                    conn = new SqlConnection(@"Data Source=DESKTOP-Q6H0SBH;Initial Catalog=CMSdbd;Integrated Security=True");
                    conn.Open();
                    string query = "insert into Vote([Can_Name],[Position],[Comments]) VALUES('" + name + "','" + post + "','" + cmnt + "')";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Added Data");
                    this.Initialize();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }
            else
            {
                return;
            }
        }

        private void Votes_Load(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Data Source=DESKTOP-Q6H0SBH;Initial Catalog=CMSdbd;Integrated Security=True";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandText = "select Name,Position from Add_executive";
            DataTable dt = new DataTable();
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            adp.Fill(dt);
            CandidatedataGridView.DataSource = dt;
        }
    }
}
