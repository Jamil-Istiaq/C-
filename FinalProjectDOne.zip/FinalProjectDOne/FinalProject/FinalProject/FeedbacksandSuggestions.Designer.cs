﻿namespace FinalProject
{
    partial class FeedbacksandSuggestions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FeedbacksandSuggestions));
            this.FeedbackdataGridView = new System.Windows.Forms.DataGridView();
            this.FeedbackLabel = new System.Windows.Forms.Label();
            this.Backbutton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.FeedbackdataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // FeedbackdataGridView
            // 
            this.FeedbackdataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.FeedbackdataGridView.Location = new System.Drawing.Point(70, 91);
            this.FeedbackdataGridView.Name = "FeedbackdataGridView";
            this.FeedbackdataGridView.Size = new System.Drawing.Size(708, 303);
            this.FeedbackdataGridView.TabIndex = 0;
            // 
            // FeedbackLabel
            // 
            this.FeedbackLabel.AutoSize = true;
            this.FeedbackLabel.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FeedbackLabel.ForeColor = System.Drawing.Color.Transparent;
            this.FeedbackLabel.Location = new System.Drawing.Point(66, 55);
            this.FeedbackLabel.Name = "FeedbackLabel";
            this.FeedbackLabel.Size = new System.Drawing.Size(234, 22);
            this.FeedbackLabel.TabIndex = 2;
            this.FeedbackLabel.Text = "Feedbacks and Suggestions";
            // 
            // Backbutton
            // 
            this.Backbutton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Backbutton.BackgroundImage")));
            this.Backbutton.Location = new System.Drawing.Point(746, 13);
            this.Backbutton.Name = "Backbutton";
            this.Backbutton.Size = new System.Drawing.Size(50, 50);
            this.Backbutton.TabIndex = 4;
            this.Backbutton.UseVisualStyleBackColor = true;
            this.Backbutton.Click += new System.EventHandler(this.Backbutton_Click);
            // 
            // FeedbacksandSuggestions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(857, 491);
            this.Controls.Add(this.Backbutton);
            this.Controls.Add(this.FeedbackLabel);
            this.Controls.Add(this.FeedbackdataGridView);
            this.Name = "FeedbacksandSuggestions";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FeedbacksandSuggestions";
            this.Load += new System.EventHandler(this.FeedbacksandSuggestions_Load);
            ((System.ComponentModel.ISupportInitialize)(this.FeedbackdataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView FeedbackdataGridView;
        private System.Windows.Forms.Label FeedbackLabel;
        private System.Windows.Forms.Button Backbutton;
    }
}