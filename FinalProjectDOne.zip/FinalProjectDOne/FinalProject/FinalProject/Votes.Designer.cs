﻿namespace FinalProject
{
    partial class Votes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Votes));
            this.panel1 = new System.Windows.Forms.Panel();
            this.Backbutton = new System.Windows.Forms.Button();
            this.CandidatedataGridView = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Votebutton = new System.Windows.Forms.Button();
            this.CommentRichTextBox = new System.Windows.Forms.RichTextBox();
            this.PositioncomboBox = new System.Windows.Forms.ComboBox();
            this.CandidatetextBox = new System.Windows.Forms.TextBox();
            this.Commentlabel = new System.Windows.Forms.Label();
            this.Positionlabel = new System.Windows.Forms.Label();
            this.Candidatelabel = new System.Windows.Forms.Label();
            this.Votlabel = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CandidatedataGridView)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.Controls.Add(this.Backbutton);
            this.panel1.Controls.Add(this.CandidatedataGridView);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(857, 491);
            this.panel1.TabIndex = 0;
            // 
            // Backbutton
            // 
            this.Backbutton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Backbutton.BackgroundImage")));
            this.Backbutton.Location = new System.Drawing.Point(780, 12);
            this.Backbutton.Name = "Backbutton";
            this.Backbutton.Size = new System.Drawing.Size(50, 50);
            this.Backbutton.TabIndex = 14;
            this.Backbutton.UseVisualStyleBackColor = true;
            this.Backbutton.Click += new System.EventHandler(this.Backbutton_Click);
            // 
            // CandidatedataGridView
            // 
            this.CandidatedataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.CandidatedataGridView.Location = new System.Drawing.Point(532, 79);
            this.CandidatedataGridView.Name = "CandidatedataGridView";
            this.CandidatedataGridView.Size = new System.Drawing.Size(243, 349);
            this.CandidatedataGridView.TabIndex = 4;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.panel2.Controls.Add(this.Votebutton);
            this.panel2.Controls.Add(this.CommentRichTextBox);
            this.panel2.Controls.Add(this.PositioncomboBox);
            this.panel2.Controls.Add(this.CandidatetextBox);
            this.panel2.Controls.Add(this.Commentlabel);
            this.panel2.Controls.Add(this.Positionlabel);
            this.panel2.Controls.Add(this.Candidatelabel);
            this.panel2.Controls.Add(this.Votlabel);
            this.panel2.Location = new System.Drawing.Point(50, 79);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(410, 349);
            this.panel2.TabIndex = 3;
            // 
            // Votebutton
            // 
            this.Votebutton.BackColor = System.Drawing.Color.DarkSlateGray;
            this.Votebutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Votebutton.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Votebutton.Location = new System.Drawing.Point(169, 314);
            this.Votebutton.Name = "Votebutton";
            this.Votebutton.Size = new System.Drawing.Size(137, 25);
            this.Votebutton.TabIndex = 7;
            this.Votebutton.Text = "Vote";
            this.Votebutton.UseVisualStyleBackColor = false;
            this.Votebutton.Click += new System.EventHandler(this.Votebutton_Click);
            // 
            // CommentRichTextBox
            // 
            this.CommentRichTextBox.Location = new System.Drawing.Point(169, 172);
            this.CommentRichTextBox.Name = "CommentRichTextBox";
            this.CommentRichTextBox.Size = new System.Drawing.Size(188, 120);
            this.CommentRichTextBox.TabIndex = 6;
            this.CommentRichTextBox.Text = "";
            // 
            // PositioncomboBox
            // 
            this.PositioncomboBox.FormattingEnabled = true;
            this.PositioncomboBox.Items.AddRange(new object[] {
            "Graphics Design",
            "Web Development",
            "Event Management",
            "Research and methodology",
            "Media",
            "Photography",
            "Public Relations",
            "Publication",
            "President",
            "Vice-Preesident"});
            this.PositioncomboBox.Location = new System.Drawing.Point(169, 123);
            this.PositioncomboBox.Name = "PositioncomboBox";
            this.PositioncomboBox.Size = new System.Drawing.Size(188, 21);
            this.PositioncomboBox.TabIndex = 5;
            // 
            // CandidatetextBox
            // 
            this.CandidatetextBox.Location = new System.Drawing.Point(169, 76);
            this.CandidatetextBox.Name = "CandidatetextBox";
            this.CandidatetextBox.Size = new System.Drawing.Size(188, 20);
            this.CandidatetextBox.TabIndex = 4;
            // 
            // Commentlabel
            // 
            this.Commentlabel.AutoSize = true;
            this.Commentlabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.Commentlabel.Location = new System.Drawing.Point(24, 172);
            this.Commentlabel.Name = "Commentlabel";
            this.Commentlabel.Size = new System.Drawing.Size(68, 17);
            this.Commentlabel.TabIndex = 3;
            this.Commentlabel.Text = "Comment";
            // 
            // Positionlabel
            // 
            this.Positionlabel.AutoSize = true;
            this.Positionlabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Positionlabel.Location = new System.Drawing.Point(24, 123);
            this.Positionlabel.Name = "Positionlabel";
            this.Positionlabel.Size = new System.Drawing.Size(59, 17);
            this.Positionlabel.TabIndex = 2;
            this.Positionlabel.Text = "Position";
            // 
            // Candidatelabel
            // 
            this.Candidatelabel.AutoSize = true;
            this.Candidatelabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.Candidatelabel.Location = new System.Drawing.Point(24, 76);
            this.Candidatelabel.Name = "Candidatelabel";
            this.Candidatelabel.Size = new System.Drawing.Size(110, 17);
            this.Candidatelabel.TabIndex = 1;
            this.Candidatelabel.Text = "Candidate Name";
            // 
            // Votlabel
            // 
            this.Votlabel.AutoSize = true;
            this.Votlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Votlabel.ForeColor = System.Drawing.Color.Maroon;
            this.Votlabel.Location = new System.Drawing.Point(130, 9);
            this.Votlabel.Name = "Votlabel";
            this.Votlabel.Size = new System.Drawing.Size(161, 20);
            this.Votlabel.TabIndex = 0;
            this.Votlabel.Text = "Vote For Executive";
            // 
            // Votes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(857, 491);
            this.Controls.Add(this.panel1);
            this.Name = "Votes";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Votes";
            this.Load += new System.EventHandler(this.Votes_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.CandidatedataGridView)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView CandidatedataGridView;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button Votebutton;
        private System.Windows.Forms.RichTextBox CommentRichTextBox;
        private System.Windows.Forms.ComboBox PositioncomboBox;
        private System.Windows.Forms.TextBox CandidatetextBox;
        private System.Windows.Forms.Label Commentlabel;
        private System.Windows.Forms.Label Positionlabel;
        private System.Windows.Forms.Label Candidatelabel;
        private System.Windows.Forms.Label Votlabel;
        private System.Windows.Forms.Button Backbutton;
    }
}