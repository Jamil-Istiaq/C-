﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FinalProject
{
    public partial class Addadmin : Form
    {
        SqlConnection conn = null;
        public Addadmin()
        {
            InitializeComponent();
        }
        private void Initialize()
        {
            textBox1.Text=textBox2.Text=textBox3.Text=textBox4.Text= "";
            
        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Backbutton_Click(object sender, EventArgs e)
        {
            AdminForm ad2 = new AdminForm();
            ad2.Show();
            this.Hide();
        }

        private void Addbutton_Click(object sender, EventArgs e)
        {
            if (textBox3.Text != null)
            {
                string name = textBox1.Text;
                string dept = comboBox1.SelectedItem.ToString();
                string post = comboBox2.SelectedItem.ToString();
                string gender = "";
                if (MaleRadioButton.Checked)
                    gender = "Male";
                else if (FemaleRadioButton.Checked)
                    gender = "Female";
                string username = textBox3.Text;
                string tpass = textBox4.Text;
                
                
              try
                {
                    conn = new SqlConnection(@"Data Source=DESKTOP-Q6H0SBH;Initial Catalog=CMSdbd;Integrated Security=True");
                    conn.Open();
                    string query = "insert into Add_admin([Name],[Dept],[Post],[Gender],[UserName],[Temp_pass]) VALUES('" +name+"','" +dept+ "','" + post + "','" + gender + "','" +username+ "','" +tpass+ "')";
                    
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Added Data");
                    this.Initialize();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }
            else
            {
                return;
            }
        }
    }
}
