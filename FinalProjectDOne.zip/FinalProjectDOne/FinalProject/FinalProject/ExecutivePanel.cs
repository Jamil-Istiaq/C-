﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class ExecutivePanel : Form
    {
        public ExecutivePanel()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FeedbacksandSuggestions fs = new FeedbacksandSuggestions();
            fs.Show();
            this.Hide();
        }

        private void VoteButton_Click(object sender, EventArgs e)
        {
            GivenVotes gv = new GivenVotes();
            gv.Show();
            this.Hide();
        }

        private void volunbutton_Click(object sender, EventArgs e)
        {
            AppliedVolunteer Apv = new AppliedVolunteer();
            Apv.Show();
            this.Hide();
        }

        private void Updatebutton_Click(object sender, EventArgs e)
        {
            UpdateInfoEx uie = new UpdateInfoEx();
            uie.Show();
            this.Hide();
        }

        private void Advisorbutton_Click(object sender, EventArgs e)
        {
            AdvisorListE advE = new AdvisorListE();
            advE.Show();
            this.Hide();
        }
    }
}
