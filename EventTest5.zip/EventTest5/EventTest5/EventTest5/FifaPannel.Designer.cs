﻿namespace EventTest5
{
    partial class FifaPannel
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Namelabel1 = new System.Windows.Forms.Label();
            this.Emaillabel2 = new System.Windows.Forms.Label();
            this.Mobilelabel = new System.Windows.Forms.Label();
            this.SchoolLabel = new System.Windows.Forms.Label();
            this.TShirtlabel = new System.Windows.Forms.Label();
            this.userLabel = new System.Windows.Forms.Label();
            this.Passlabel = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.passwordtext = new System.Windows.Forms.TextBox();
            this.Submitbutton = new System.Windows.Forms.Button();
            this.ckPasswordText = new System.Windows.Forms.TextBox();
            this.ckpasswordLabel = new System.Windows.Forms.Label();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // Namelabel1
            // 
            this.Namelabel1.AutoSize = true;
            this.Namelabel1.Font = new System.Drawing.Font("Segoe UI Black", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Namelabel1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Namelabel1.Location = new System.Drawing.Point(65, 53);
            this.Namelabel1.Name = "Namelabel1";
            this.Namelabel1.Size = new System.Drawing.Size(38, 13);
            this.Namelabel1.TabIndex = 0;
            this.Namelabel1.Text = "Name";
            // 
            // Emaillabel2
            // 
            this.Emaillabel2.AutoSize = true;
            this.Emaillabel2.Font = new System.Drawing.Font("Segoe UI Black", 8.25F, System.Drawing.FontStyle.Bold);
            this.Emaillabel2.ForeColor = System.Drawing.Color.Black;
            this.Emaillabel2.Location = new System.Drawing.Point(65, 89);
            this.Emaillabel2.Name = "Emaillabel2";
            this.Emaillabel2.Size = new System.Drawing.Size(35, 13);
            this.Emaillabel2.TabIndex = 1;
            this.Emaillabel2.Text = "Email";
            // 
            // Mobilelabel
            // 
            this.Mobilelabel.AutoSize = true;
            this.Mobilelabel.Font = new System.Drawing.Font("Segoe UI Black", 8.25F, System.Drawing.FontStyle.Bold);
            this.Mobilelabel.ForeColor = System.Drawing.Color.Black;
            this.Mobilelabel.Location = new System.Drawing.Point(65, 137);
            this.Mobilelabel.Name = "Mobilelabel";
            this.Mobilelabel.Size = new System.Drawing.Size(67, 13);
            this.Mobilelabel.TabIndex = 2;
            this.Mobilelabel.Text = "Mobile No.";
            // 
            // SchoolLabel
            // 
            this.SchoolLabel.AutoSize = true;
            this.SchoolLabel.Font = new System.Drawing.Font("Segoe UI Black", 8.25F, System.Drawing.FontStyle.Bold);
            this.SchoolLabel.ForeColor = System.Drawing.Color.Black;
            this.SchoolLabel.Location = new System.Drawing.Point(65, 253);
            this.SchoolLabel.Name = "SchoolLabel";
            this.SchoolLabel.Size = new System.Drawing.Size(54, 13);
            this.SchoolLabel.TabIndex = 3;
            this.SchoolLabel.Text = "Institute";
            // 
            // TShirtlabel
            // 
            this.TShirtlabel.AutoSize = true;
            this.TShirtlabel.Font = new System.Drawing.Font("Segoe UI Black", 8.25F, System.Drawing.FontStyle.Bold);
            this.TShirtlabel.ForeColor = System.Drawing.Color.Black;
            this.TShirtlabel.Location = new System.Drawing.Point(65, 197);
            this.TShirtlabel.Name = "TShirtlabel";
            this.TShirtlabel.Size = new System.Drawing.Size(44, 13);
            this.TShirtlabel.TabIndex = 4;
            this.TShirtlabel.Text = "T-Shirt";
            // 
            // userLabel
            // 
            this.userLabel.AutoSize = true;
            this.userLabel.Font = new System.Drawing.Font("Segoe UI Black", 8.25F, System.Drawing.FontStyle.Bold);
            this.userLabel.ForeColor = System.Drawing.Color.Black;
            this.userLabel.Location = new System.Drawing.Point(351, 38);
            this.userLabel.Name = "userLabel";
            this.userLabel.Size = new System.Drawing.Size(65, 13);
            this.userLabel.TabIndex = 5;
            this.userLabel.Text = "User Name";
            // 
            // Passlabel
            // 
            this.Passlabel.AutoSize = true;
            this.Passlabel.Font = new System.Drawing.Font("Segoe UI Black", 8.25F, System.Drawing.FontStyle.Bold);
            this.Passlabel.ForeColor = System.Drawing.Color.Black;
            this.Passlabel.Location = new System.Drawing.Point(351, 96);
            this.Passlabel.Name = "Passlabel";
            this.Passlabel.Size = new System.Drawing.Size(58, 13);
            this.Passlabel.TabIndex = 6;
            this.Passlabel.Text = "Password";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(155, 53);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(144, 20);
            this.textBox1.TabIndex = 7;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(155, 89);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(144, 20);
            this.textBox2.TabIndex = 8;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(155, 130);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(144, 20);
            this.textBox3.TabIndex = 9;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(354, 54);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(144, 20);
            this.textBox6.TabIndex = 12;
            // 
            // passwordtext
            // 
            this.passwordtext.Location = new System.Drawing.Point(354, 112);
            this.passwordtext.Name = "passwordtext";
            this.passwordtext.Size = new System.Drawing.Size(144, 20);
            this.passwordtext.TabIndex = 13;
            // 
            // Submitbutton
            // 
            this.Submitbutton.BackColor = System.Drawing.Color.LightCoral;
            this.Submitbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Submitbutton.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Submitbutton.Location = new System.Drawing.Point(279, 348);
            this.Submitbutton.Name = "Submitbutton";
            this.Submitbutton.Size = new System.Drawing.Size(80, 34);
            this.Submitbutton.TabIndex = 14;
            this.Submitbutton.Text = "Submit";
            this.Submitbutton.UseVisualStyleBackColor = false;
            // 
            // ckPasswordText
            // 
            this.ckPasswordText.Location = new System.Drawing.Point(354, 175);
            this.ckPasswordText.Name = "ckPasswordText";
            this.ckPasswordText.Size = new System.Drawing.Size(144, 20);
            this.ckPasswordText.TabIndex = 15;
            // 
            // ckpasswordLabel
            // 
            this.ckpasswordLabel.AutoSize = true;
            this.ckpasswordLabel.Font = new System.Drawing.Font("Segoe UI Black", 8.25F, System.Drawing.FontStyle.Bold);
            this.ckpasswordLabel.ForeColor = System.Drawing.Color.Black;
            this.ckpasswordLabel.Location = new System.Drawing.Point(351, 159);
            this.ckpasswordLabel.Name = "ckpasswordLabel";
            this.ckpasswordLabel.Size = new System.Drawing.Size(105, 13);
            this.ckpasswordLabel.TabIndex = 16;
            this.ckpasswordLabel.Text = "Confirm Password";
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(68, 284);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(58, 17);
            this.radioButton1.TabIndex = 17;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "School";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(68, 307);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(60, 17);
            this.radioButton2.TabIndex = 18;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "College";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(68, 330);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(71, 17);
            this.radioButton3.TabIndex = 19;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "University";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "S",
            "M",
            "L",
            "X",
            "L",
            "XL",
            "XXL"});
            this.comboBox1.Location = new System.Drawing.Point(155, 196);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(144, 21);
            this.comboBox1.TabIndex = 21;
            // 
            // FifaPannel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.radioButton3);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.ckpasswordLabel);
            this.Controls.Add(this.ckPasswordText);
            this.Controls.Add(this.Submitbutton);
            this.Controls.Add(this.passwordtext);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.Passlabel);
            this.Controls.Add(this.userLabel);
            this.Controls.Add(this.TShirtlabel);
            this.Controls.Add(this.SchoolLabel);
            this.Controls.Add(this.Mobilelabel);
            this.Controls.Add(this.Emaillabel2);
            this.Controls.Add(this.Namelabel1);
            this.Name = "FifaPannel";
            this.Size = new System.Drawing.Size(658, 484);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Namelabel1;
        private System.Windows.Forms.Label Emaillabel2;
        private System.Windows.Forms.Label Mobilelabel;
        private System.Windows.Forms.Label SchoolLabel;
        private System.Windows.Forms.Label TShirtlabel;
        private System.Windows.Forms.Label userLabel;
        private System.Windows.Forms.Label Passlabel;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox passwordtext;
        private System.Windows.Forms.Button Submitbutton;
        private System.Windows.Forms.TextBox ckPasswordText;
        private System.Windows.Forms.Label ckpasswordLabel;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.ComboBox comboBox1;
    }
}
