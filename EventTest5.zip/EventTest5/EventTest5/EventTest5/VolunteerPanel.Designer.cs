﻿namespace EventTest5
{
    partial class VolunteerPanel
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(VolunteerPanel));
            this.VLogInbutton1 = new System.Windows.Forms.Button();
            this.Vdminlabel1 = new System.Windows.Forms.Label();
            this.VPasswordText = new System.Windows.Forms.TextBox();
            this.Vpasslabel = new System.Windows.Forms.Label();
            this.VusertextBox = new System.Windows.Forms.TextBox();
            this.VUserNamelabel = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // VLogInbutton1
            // 
            this.VLogInbutton1.BackColor = System.Drawing.Color.Gold;
            this.VLogInbutton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VLogInbutton1.ForeColor = System.Drawing.Color.DarkGreen;
            this.VLogInbutton1.Location = new System.Drawing.Point(222, 139);
            this.VLogInbutton1.Name = "VLogInbutton1";
            this.VLogInbutton1.Size = new System.Drawing.Size(81, 29);
            this.VLogInbutton1.TabIndex = 11;
            this.VLogInbutton1.Text = "Login";
            this.VLogInbutton1.UseVisualStyleBackColor = false;
            // 
            // Vdminlabel1
            // 
            this.Vdminlabel1.AutoSize = true;
            this.Vdminlabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Vdminlabel1.ForeColor = System.Drawing.Color.DarkBlue;
            this.Vdminlabel1.Location = new System.Drawing.Point(455, 24);
            this.Vdminlabel1.Name = "Vdminlabel1";
            this.Vdminlabel1.Size = new System.Drawing.Size(78, 17);
            this.Vdminlabel1.TabIndex = 10;
            this.Vdminlabel1.Text = "Volunteer";
            this.Vdminlabel1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // VPasswordText
            // 
            this.VPasswordText.Location = new System.Drawing.Point(163, 95);
            this.VPasswordText.Name = "VPasswordText";
            this.VPasswordText.Size = new System.Drawing.Size(140, 20);
            this.VPasswordText.TabIndex = 9;
            // 
            // Vpasslabel
            // 
            this.Vpasslabel.AutoSize = true;
            this.Vpasslabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Vpasslabel.Location = new System.Drawing.Point(65, 95);
            this.Vpasslabel.Name = "Vpasslabel";
            this.Vpasslabel.Size = new System.Drawing.Size(77, 17);
            this.Vpasslabel.TabIndex = 8;
            this.Vpasslabel.Text = "Password";
            // 
            // VusertextBox
            // 
            this.VusertextBox.Location = new System.Drawing.Point(163, 44);
            this.VusertextBox.Name = "VusertextBox";
            this.VusertextBox.Size = new System.Drawing.Size(140, 20);
            this.VusertextBox.TabIndex = 7;
            // 
            // VUserNamelabel
            // 
            this.VUserNamelabel.AutoSize = true;
            this.VUserNamelabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VUserNamelabel.Location = new System.Drawing.Point(55, 48);
            this.VUserNamelabel.Name = "VUserNamelabel";
            this.VUserNamelabel.Size = new System.Drawing.Size(88, 17);
            this.VUserNamelabel.TabIndex = 6;
            this.VUserNamelabel.Text = "User Name";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.VPasswordText);
            this.groupBox1.Controls.Add(this.VLogInbutton1);
            this.groupBox1.Controls.Add(this.Vpasslabel);
            this.groupBox1.Controls.Add(this.VusertextBox);
            this.groupBox1.Controls.Add(this.VUserNamelabel);
            this.groupBox1.Location = new System.Drawing.Point(244, 172);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(319, 178);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(40, 59);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(170, 178);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            // 
            // VolunteerPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.Vdminlabel1);
            this.Name = "VolunteerPanel";
            this.Size = new System.Drawing.Size(576, 424);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button VLogInbutton1;
        private System.Windows.Forms.Label Vdminlabel1;
        private System.Windows.Forms.TextBox VPasswordText;
        private System.Windows.Forms.Label Vpasslabel;
        private System.Windows.Forms.TextBox VusertextBox;
        private System.Windows.Forms.Label VUserNamelabel;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}
