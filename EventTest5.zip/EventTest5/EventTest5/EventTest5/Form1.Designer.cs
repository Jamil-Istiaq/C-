﻿namespace EventTest5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.Aboutbutton = new System.Windows.Forms.Button();
            this.RegPanel = new System.Windows.Forms.Panel();
            this.Csgobutton = new System.Windows.Forms.Button();
            this.Nfsbutton = new System.Windows.Forms.Button();
            this.Fifabutton = new System.Windows.Forms.Button();
            this.Registrationbutton = new System.Windows.Forms.Button();
            this.LogInpanel = new System.Windows.Forms.Panel();
            this.Userbutton = new System.Windows.Forms.Button();
            this.Volunteerbutton = new System.Windows.Forms.Button();
            this.Adminbutton = new System.Windows.Forms.Button();
            this.LogInButton = new System.Windows.Forms.Button();
            this.HomeButton = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.volunteerPanel1 = new EventTest5.VolunteerPanel();
            this.userPanel1 = new EventTest5.UserPanel();
            this.fifaPannel1 = new EventTest5.FifaPannel();
            this.adminControl1 = new EventTest5.AdminControl();
            this.panel1.SuspendLayout();
            this.RegPanel.SuspendLayout();
            this.LogInpanel.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(7)))), ((int)(((byte)(17)))));
            this.panel1.Controls.Add(this.Aboutbutton);
            this.panel1.Controls.Add(this.RegPanel);
            this.panel1.Controls.Add(this.Registrationbutton);
            this.panel1.Controls.Add(this.LogInpanel);
            this.panel1.Controls.Add(this.LogInButton);
            this.panel1.Controls.Add(this.HomeButton);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 460);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // Aboutbutton
            // 
            this.Aboutbutton.Dock = System.Windows.Forms.DockStyle.Top;
            this.Aboutbutton.FlatAppearance.BorderSize = 0;
            this.Aboutbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Aboutbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Aboutbutton.ForeColor = System.Drawing.Color.Gainsboro;
            this.Aboutbutton.Location = new System.Drawing.Point(0, 294);
            this.Aboutbutton.Name = "Aboutbutton";
            this.Aboutbutton.Size = new System.Drawing.Size(200, 23);
            this.Aboutbutton.TabIndex = 6;
            this.Aboutbutton.Text = "About Us";
            this.Aboutbutton.UseVisualStyleBackColor = true;
            this.Aboutbutton.Click += new System.EventHandler(this.Aboutbutton_Click);
            this.Aboutbutton.MouseHover += new System.EventHandler(this.Button_MouseEnter);
            // 
            // RegPanel
            // 
            this.RegPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            this.RegPanel.Controls.Add(this.Csgobutton);
            this.RegPanel.Controls.Add(this.Nfsbutton);
            this.RegPanel.Controls.Add(this.Fifabutton);
            this.RegPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.RegPanel.Location = new System.Drawing.Point(0, 216);
            this.RegPanel.Name = "RegPanel";
            this.RegPanel.Size = new System.Drawing.Size(200, 78);
            this.RegPanel.TabIndex = 5;
            // 
            // Csgobutton
            // 
            this.Csgobutton.Dock = System.Windows.Forms.DockStyle.Top;
            this.Csgobutton.FlatAppearance.BorderSize = 0;
            this.Csgobutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Csgobutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Csgobutton.ForeColor = System.Drawing.Color.Gainsboro;
            this.Csgobutton.Location = new System.Drawing.Point(0, 46);
            this.Csgobutton.Name = "Csgobutton";
            this.Csgobutton.Size = new System.Drawing.Size(200, 23);
            this.Csgobutton.TabIndex = 5;
            this.Csgobutton.Text = "CS GO";
            this.Csgobutton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Csgobutton.UseVisualStyleBackColor = true;
            this.Csgobutton.Click += new System.EventHandler(this.Csgobutton_Click);
            // 
            // Nfsbutton
            // 
            this.Nfsbutton.Dock = System.Windows.Forms.DockStyle.Top;
            this.Nfsbutton.FlatAppearance.BorderSize = 0;
            this.Nfsbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Nfsbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nfsbutton.ForeColor = System.Drawing.Color.Gainsboro;
            this.Nfsbutton.Location = new System.Drawing.Point(0, 23);
            this.Nfsbutton.Name = "Nfsbutton";
            this.Nfsbutton.Size = new System.Drawing.Size(200, 23);
            this.Nfsbutton.TabIndex = 4;
            this.Nfsbutton.Text = "NFS";
            this.Nfsbutton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Nfsbutton.UseVisualStyleBackColor = true;
            this.Nfsbutton.Click += new System.EventHandler(this.Nfsbutton_Click);
            // 
            // Fifabutton
            // 
            this.Fifabutton.Dock = System.Windows.Forms.DockStyle.Top;
            this.Fifabutton.FlatAppearance.BorderSize = 0;
            this.Fifabutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Fifabutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Fifabutton.ForeColor = System.Drawing.Color.Gainsboro;
            this.Fifabutton.Location = new System.Drawing.Point(0, 0);
            this.Fifabutton.Name = "Fifabutton";
            this.Fifabutton.Size = new System.Drawing.Size(200, 23);
            this.Fifabutton.TabIndex = 3;
            this.Fifabutton.Text = "FIFA";
            this.Fifabutton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Fifabutton.UseVisualStyleBackColor = true;
            this.Fifabutton.Click += new System.EventHandler(this.Fifabutton_Click);
            // 
            // Registrationbutton
            // 
            this.Registrationbutton.Dock = System.Windows.Forms.DockStyle.Top;
            this.Registrationbutton.FlatAppearance.BorderSize = 0;
            this.Registrationbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Registrationbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Registrationbutton.ForeColor = System.Drawing.Color.Gainsboro;
            this.Registrationbutton.Location = new System.Drawing.Point(0, 193);
            this.Registrationbutton.Name = "Registrationbutton";
            this.Registrationbutton.Size = new System.Drawing.Size(200, 23);
            this.Registrationbutton.TabIndex = 4;
            this.Registrationbutton.Text = "Registration";
            this.Registrationbutton.UseVisualStyleBackColor = true;
            this.Registrationbutton.Click += new System.EventHandler(this.Registrationbutton_Click);
            // 
            // LogInpanel
            // 
            this.LogInpanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            this.LogInpanel.Controls.Add(this.Userbutton);
            this.LogInpanel.Controls.Add(this.Volunteerbutton);
            this.LogInpanel.Controls.Add(this.Adminbutton);
            this.LogInpanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.LogInpanel.Location = new System.Drawing.Point(0, 115);
            this.LogInpanel.Name = "LogInpanel";
            this.LogInpanel.Size = new System.Drawing.Size(200, 78);
            this.LogInpanel.TabIndex = 3;
            // 
            // Userbutton
            // 
            this.Userbutton.Dock = System.Windows.Forms.DockStyle.Top;
            this.Userbutton.FlatAppearance.BorderSize = 0;
            this.Userbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Userbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Userbutton.ForeColor = System.Drawing.Color.Gainsboro;
            this.Userbutton.Location = new System.Drawing.Point(0, 46);
            this.Userbutton.Name = "Userbutton";
            this.Userbutton.Size = new System.Drawing.Size(200, 23);
            this.Userbutton.TabIndex = 5;
            this.Userbutton.Text = "User";
            this.Userbutton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Userbutton.UseVisualStyleBackColor = true;
            this.Userbutton.Click += new System.EventHandler(this.Userbutton_Click);
            // 
            // Volunteerbutton
            // 
            this.Volunteerbutton.Dock = System.Windows.Forms.DockStyle.Top;
            this.Volunteerbutton.FlatAppearance.BorderSize = 0;
            this.Volunteerbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Volunteerbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Volunteerbutton.ForeColor = System.Drawing.Color.Gainsboro;
            this.Volunteerbutton.Location = new System.Drawing.Point(0, 23);
            this.Volunteerbutton.Name = "Volunteerbutton";
            this.Volunteerbutton.Size = new System.Drawing.Size(200, 23);
            this.Volunteerbutton.TabIndex = 4;
            this.Volunteerbutton.Text = "Volunteer";
            this.Volunteerbutton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Volunteerbutton.UseVisualStyleBackColor = true;
            this.Volunteerbutton.Click += new System.EventHandler(this.Volunteerbutton_Click);
            // 
            // Adminbutton
            // 
            this.Adminbutton.Dock = System.Windows.Forms.DockStyle.Top;
            this.Adminbutton.FlatAppearance.BorderSize = 0;
            this.Adminbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Adminbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Adminbutton.ForeColor = System.Drawing.Color.Gainsboro;
            this.Adminbutton.Location = new System.Drawing.Point(0, 0);
            this.Adminbutton.Name = "Adminbutton";
            this.Adminbutton.Size = new System.Drawing.Size(200, 23);
            this.Adminbutton.TabIndex = 3;
            this.Adminbutton.Text = "Admin";
            this.Adminbutton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Adminbutton.UseVisualStyleBackColor = true;
            this.Adminbutton.Click += new System.EventHandler(this.Adminbutton_Click);
            // 
            // LogInButton
            // 
            this.LogInButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.LogInButton.FlatAppearance.BorderSize = 0;
            this.LogInButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.LogInButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LogInButton.ForeColor = System.Drawing.Color.Gainsboro;
            this.LogInButton.Location = new System.Drawing.Point(0, 92);
            this.LogInButton.Name = "LogInButton";
            this.LogInButton.Size = new System.Drawing.Size(200, 23);
            this.LogInButton.TabIndex = 2;
            this.LogInButton.Text = "Login";
            this.LogInButton.UseVisualStyleBackColor = true;
            this.LogInButton.Click += new System.EventHandler(this.LogInButton_Click);
            // 
            // HomeButton
            // 
            this.HomeButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.HomeButton.FlatAppearance.BorderSize = 0;
            this.HomeButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.HomeButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HomeButton.ForeColor = System.Drawing.Color.Gainsboro;
            this.HomeButton.Location = new System.Drawing.Point(0, 69);
            this.HomeButton.Name = "HomeButton";
            this.HomeButton.Size = new System.Drawing.Size(200, 23);
            this.HomeButton.TabIndex = 1;
            this.HomeButton.Text = "Home";
            this.HomeButton.UseVisualStyleBackColor = true;
            this.HomeButton.Click += new System.EventHandler(this.HomeButton_Click);
            // 
            // panel2
            // 
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(200, 69);
            this.panel2.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(7)))), ((int)(((byte)(17)))));
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(200, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(600, 46);
            this.panel3.TabIndex = 1;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.volunteerPanel1);
            this.panel4.Controls.Add(this.userPanel1);
            this.panel4.Controls.Add(this.adminControl1);
            this.panel4.Controls.Add(this.fifaPannel1);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(200, 46);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(600, 414);
            this.panel4.TabIndex = 2;
            // 
            // volunteerPanel1
            // 
            this.volunteerPanel1.BackColor = System.Drawing.Color.DarkOrchid;
            this.volunteerPanel1.Location = new System.Drawing.Point(0, 0);
            this.volunteerPanel1.Name = "volunteerPanel1";
            this.volunteerPanel1.Size = new System.Drawing.Size(600, 424);
            this.volunteerPanel1.TabIndex = 3;
            this.volunteerPanel1.Load += new System.EventHandler(this.volunteerPanel1_Load);
            // 
            // userPanel1
            // 
            this.userPanel1.BackColor = System.Drawing.Color.DarkOrchid;
            this.userPanel1.Location = new System.Drawing.Point(0, 0);
            this.userPanel1.Name = "userPanel1";
            this.userPanel1.Size = new System.Drawing.Size(600, 443);
            this.userPanel1.TabIndex = 2;
            this.userPanel1.Load += new System.EventHandler(this.userPanel1_Load);
            // 
            // fifaPannel1
            // 
            this.fifaPannel1.AutoScroll = true;
            this.fifaPannel1.BackColor = System.Drawing.Color.Indigo;
            this.fifaPannel1.Location = new System.Drawing.Point(0, 0);
            this.fifaPannel1.Name = "fifaPannel1";
            this.fifaPannel1.Size = new System.Drawing.Size(597, 447);
            this.fifaPannel1.TabIndex = 0;
            this.fifaPannel1.Load += new System.EventHandler(this.fifaPannel1_Load);
            // 
            // adminControl1
            // 
            this.adminControl1.BackColor = System.Drawing.Color.DarkOrchid;
            this.adminControl1.Location = new System.Drawing.Point(0, 0);
            this.adminControl1.Name = "adminControl1";
            this.adminControl1.Size = new System.Drawing.Size(600, 446);
            this.adminControl1.TabIndex = 1;
            this.adminControl1.Load += new System.EventHandler(this.adminControl1_Load);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(800, 460);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.RegPanel.ResumeLayout(false);
            this.LogInpanel.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel RegPanel;
        private System.Windows.Forms.Button Csgobutton;
        private System.Windows.Forms.Button Nfsbutton;
        private System.Windows.Forms.Button Fifabutton;
        private System.Windows.Forms.Button Registrationbutton;
        private System.Windows.Forms.Panel LogInpanel;
        private System.Windows.Forms.Button Userbutton;
        private System.Windows.Forms.Button Volunteerbutton;
        private System.Windows.Forms.Button Adminbutton;
        private System.Windows.Forms.Button LogInButton;
        private System.Windows.Forms.Button HomeButton;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button Aboutbutton;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private FifaPannel fifaPannel1;
        private VolunteerPanel volunteerPanel1;
        private UserPanel userPanel1;
        private AdminControl adminControl1;
    }
}

