﻿namespace EventTest5
{
    partial class AdminControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminControl));
            this.AUserNamelabel = new System.Windows.Forms.Label();
            this.AusertextBox = new System.Windows.Forms.TextBox();
            this.Apasslabel = new System.Windows.Forms.Label();
            this.APasswordText = new System.Windows.Forms.TextBox();
            this.Adminlabel1 = new System.Windows.Forms.Label();
            this.ALogInbutton1 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // AUserNamelabel
            // 
            this.AUserNamelabel.AutoSize = true;
            this.AUserNamelabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AUserNamelabel.Location = new System.Drawing.Point(36, 34);
            this.AUserNamelabel.Name = "AUserNamelabel";
            this.AUserNamelabel.Size = new System.Drawing.Size(93, 17);
            this.AUserNamelabel.TabIndex = 0;
            this.AUserNamelabel.Text = "User Name ";
            this.AUserNamelabel.Click += new System.EventHandler(this.AUserNamelabel_Click);
            // 
            // AusertextBox
            // 
            this.AusertextBox.Location = new System.Drawing.Point(135, 31);
            this.AusertextBox.Name = "AusertextBox";
            this.AusertextBox.Size = new System.Drawing.Size(144, 20);
            this.AusertextBox.TabIndex = 1;
            this.AusertextBox.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // Apasslabel
            // 
            this.Apasslabel.AutoSize = true;
            this.Apasslabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Apasslabel.Location = new System.Drawing.Point(52, 70);
            this.Apasslabel.Name = "Apasslabel";
            this.Apasslabel.Size = new System.Drawing.Size(77, 17);
            this.Apasslabel.TabIndex = 2;
            this.Apasslabel.Text = "Password";
            this.Apasslabel.Click += new System.EventHandler(this.Apasslabel_Click);
            // 
            // APasswordText
            // 
            this.APasswordText.Location = new System.Drawing.Point(135, 70);
            this.APasswordText.Name = "APasswordText";
            this.APasswordText.Size = new System.Drawing.Size(144, 20);
            this.APasswordText.TabIndex = 3;
            // 
            // Adminlabel1
            // 
            this.Adminlabel1.AutoSize = true;
            this.Adminlabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Adminlabel1.ForeColor = System.Drawing.Color.DarkBlue;
            this.Adminlabel1.Location = new System.Drawing.Point(440, 13);
            this.Adminlabel1.Name = "Adminlabel1";
            this.Adminlabel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Adminlabel1.Size = new System.Drawing.Size(47, 17);
            this.Adminlabel1.TabIndex = 4;
            this.Adminlabel1.Text = "Admin";
            this.Adminlabel1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.Adminlabel1.Click += new System.EventHandler(this.Adminlabel1_Click);
            // 
            // ALogInbutton1
            // 
            this.ALogInbutton1.BackColor = System.Drawing.Color.Gold;
            this.ALogInbutton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ALogInbutton1.ForeColor = System.Drawing.Color.DarkGreen;
            this.ALogInbutton1.Location = new System.Drawing.Point(213, 107);
            this.ALogInbutton1.Name = "ALogInbutton1";
            this.ALogInbutton1.Size = new System.Drawing.Size(66, 32);
            this.ALogInbutton1.TabIndex = 5;
            this.ALogInbutton1.Text = "Log In";
            this.ALogInbutton1.UseVisualStyleBackColor = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.AUserNamelabel);
            this.groupBox1.Controls.Add(this.ALogInbutton1);
            this.groupBox1.Controls.Add(this.AusertextBox);
            this.groupBox1.Controls.Add(this.APasswordText);
            this.groupBox1.Controls.Add(this.Apasslabel);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.groupBox1.Location = new System.Drawing.Point(186, 183);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(344, 172);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(25, 48);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(155, 172);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // AdminControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.Adminlabel1);
            this.Name = "AdminControl";
            this.Size = new System.Drawing.Size(576, 424);
            this.Load += new System.EventHandler(this.AdminControl_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label AUserNamelabel;
        private System.Windows.Forms.TextBox AusertextBox;
        private System.Windows.Forms.Label Apasslabel;
        private System.Windows.Forms.TextBox APasswordText;
        private System.Windows.Forms.Label Adminlabel1;
        private System.Windows.Forms.Button ALogInbutton1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}
