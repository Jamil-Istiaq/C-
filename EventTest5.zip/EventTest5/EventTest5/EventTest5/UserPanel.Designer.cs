﻿namespace EventTest5
{
    partial class UserPanel
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserPanel));
            this.ULogInbutton1 = new System.Windows.Forms.Button();
            this.Userlabel1 = new System.Windows.Forms.Label();
            this.UPasswordText = new System.Windows.Forms.TextBox();
            this.Upasslabel = new System.Windows.Forms.Label();
            this.UusertextBox = new System.Windows.Forms.TextBox();
            this.uUserNamelabel = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // ULogInbutton1
            // 
            this.ULogInbutton1.BackColor = System.Drawing.Color.Gold;
            this.ULogInbutton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ULogInbutton1.ForeColor = System.Drawing.Color.DarkGreen;
            this.ULogInbutton1.Location = new System.Drawing.Point(191, 130);
            this.ULogInbutton1.Name = "ULogInbutton1";
            this.ULogInbutton1.Size = new System.Drawing.Size(70, 27);
            this.ULogInbutton1.TabIndex = 11;
            this.ULogInbutton1.Text = "Log In";
            this.ULogInbutton1.UseVisualStyleBackColor = false;
            // 
            // Userlabel1
            // 
            this.Userlabel1.AutoSize = true;
            this.Userlabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Userlabel1.ForeColor = System.Drawing.Color.DarkBlue;
            this.Userlabel1.Location = new System.Drawing.Point(483, 31);
            this.Userlabel1.Name = "Userlabel1";
            this.Userlabel1.Size = new System.Drawing.Size(42, 17);
            this.Userlabel1.TabIndex = 10;
            this.Userlabel1.Text = "User";
            this.Userlabel1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // UPasswordText
            // 
            this.UPasswordText.Location = new System.Drawing.Point(137, 95);
            this.UPasswordText.Name = "UPasswordText";
            this.UPasswordText.Size = new System.Drawing.Size(137, 20);
            this.UPasswordText.TabIndex = 9;
            // 
            // Upasslabel
            // 
            this.Upasslabel.AutoSize = true;
            this.Upasslabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Upasslabel.Location = new System.Drawing.Point(31, 98);
            this.Upasslabel.Name = "Upasslabel";
            this.Upasslabel.Size = new System.Drawing.Size(77, 17);
            this.Upasslabel.TabIndex = 8;
            this.Upasslabel.Text = "Password";
            // 
            // UusertextBox
            // 
            this.UusertextBox.Location = new System.Drawing.Point(137, 45);
            this.UusertextBox.Name = "UusertextBox";
            this.UusertextBox.Size = new System.Drawing.Size(137, 20);
            this.UusertextBox.TabIndex = 7;
            // 
            // uUserNamelabel
            // 
            this.uUserNamelabel.AutoSize = true;
            this.uUserNamelabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uUserNamelabel.Location = new System.Drawing.Point(31, 45);
            this.uUserNamelabel.Name = "uUserNamelabel";
            this.uUserNamelabel.Size = new System.Drawing.Size(88, 17);
            this.uUserNamelabel.TabIndex = 6;
            this.uUserNamelabel.Text = "User Name";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.uUserNamelabel);
            this.groupBox1.Controls.Add(this.Upasslabel);
            this.groupBox1.Controls.Add(this.ULogInbutton1);
            this.groupBox1.Controls.Add(this.UusertextBox);
            this.groupBox1.Controls.Add(this.UPasswordText);
            this.groupBox1.Location = new System.Drawing.Point(250, 167);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(303, 175);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(40, 55);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(188, 174);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            // 
            // UserPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.Userlabel1);
            this.Name = "UserPanel";
            this.Size = new System.Drawing.Size(582, 443);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ULogInbutton1;
        private System.Windows.Forms.Label Userlabel1;
        private System.Windows.Forms.TextBox UPasswordText;
        private System.Windows.Forms.Label Upasslabel;
        private System.Windows.Forms.TextBox UusertextBox;
        private System.Windows.Forms.Label uUserNamelabel;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}
