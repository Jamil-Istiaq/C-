﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EventTest5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent(); customizeDesign();
        }
        private void customizeDesign()
        {
           LogInpanel.Visible = false;
           RegPanel.Visible = false;
        }
        private void hideSubMenu()
        {
            if (LogInpanel.Visible == true)
                LogInpanel.Visible = false;
            if (RegPanel.Visible = true)
                RegPanel.Visible = false;
        }
        private void showSubMenu(Panel submenu)
        {
            if (submenu.Visible == false)
            {
                hideSubMenu();
                submenu.Visible = true;
            }
            else
                submenu.Visible = false;
        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void HomeButton_Click(object sender, EventArgs e)
        {
            hideSubMenu(); fifaPannel1.Hide(); volunteerPanel1.Hide(); userPanel1.Hide(); adminControl1.Hide();
           // Button button = (Button)sender;
            HomeButton.BackColor = Color.Firebrick;
        }
       

        private void LogInButton_Click(object sender, EventArgs e)
        {
            showSubMenu(LogInpanel); fifaPannel1.Hide(); volunteerPanel1.Hide(); userPanel1.Hide(); adminControl1.Hide();
            LogInButton.BackColor = Color.Firebrick;
        }

        private void Adminbutton_Click(object sender, EventArgs e)
        {
            hideSubMenu(); fifaPannel1.Hide(); volunteerPanel1.Hide(); userPanel1.Hide(); adminControl1.Show();
        }

        private void Volunteerbutton_Click(object sender, EventArgs e)
        {
            hideSubMenu(); fifaPannel1.Hide(); volunteerPanel1.Show(); userPanel1.Hide(); adminControl1.Hide();
        }

        private void Userbutton_Click(object sender, EventArgs e)
        {
            hideSubMenu(); fifaPannel1.Hide(); volunteerPanel1.Hide(); userPanel1.Show(); adminControl1.Hide();
        }

        private void Registrationbutton_Click(object sender, EventArgs e)
        {
            showSubMenu(RegPanel); fifaPannel1.Hide(); volunteerPanel1.Hide(); userPanel1.Hide(); adminControl1.Hide();
            Registrationbutton.BackColor = Color.Firebrick;
        }

        private void Fifabutton_Click(object sender, EventArgs e)
        {
            
            hideSubMenu(); fifaPannel1.Show(); volunteerPanel1.Hide(); userPanel1.Hide(); adminControl1.Hide();
        }

        private void Nfsbutton_Click(object sender, EventArgs e)
        {
            hideSubMenu(); fifaPannel1.Show(); volunteerPanel1.Hide(); userPanel1.Hide(); adminControl1.Hide();
        }

        private void Csgobutton_Click(object sender, EventArgs e)
        {
            hideSubMenu(); fifaPannel1.Hide(); volunteerPanel1.Hide(); userPanel1.Hide(); adminControl1.Hide();
        }

        private void Aboutbutton_Click(object sender, EventArgs e)
        {
            hideSubMenu(); fifaPannel1.Hide(); volunteerPanel1.Hide(); userPanel1.Hide(); adminControl1.Hide();
            Aboutbutton.BackColor = Color.Firebrick;
        }

        private void fifaPannel1_Load(object sender, EventArgs e)
        {
            fifaPannel1.Hide(); volunteerPanel1.Hide(); userPanel1.Hide(); adminControl1.Hide();
        }

        private void volunteerPanel1_Load(object sender, EventArgs e)
        {
            volunteerPanel1.Hide(); userPanel1.Hide(); adminControl1.Hide();
        }

        private void userPanel1_Load(object sender, EventArgs e)
        {
            userPanel1.Hide(); adminControl1.Hide(); volunteerPanel1.Hide();
        }

        private void adminControl1_Load(object sender, EventArgs e)
        {
            adminControl1.Hide(); volunteerPanel1.Hide(); userPanel1.Hide();
        }

        private void Button_MouseEnter(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            button.BackColor = Color.Firebrick;
        }

     
    }
}
